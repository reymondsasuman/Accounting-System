﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.AccountingModel
{
    class JournalVoucherDetail
    {
        public Int64 Code { get; set; }
        public String ReferenceNum { get; set; }
        public String JVNo { get; set; }
        public String Month { get; set; }
        public String Year { get; set; }
        public DateTime DateTrans { get; set; }
        public String Particulars { get; set; }
   
        public String AcctCode { get; set; }
        public String AcctDesc { get; set; }
        public Decimal GL_Debit { get; set; }
        public Decimal GL_Credit { get; set; }
        public Decimal SL_Debit { get; set; }
        public Decimal SL_Credit { get; set; }
    }
}
