﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.AccountingModel
{
    class AccountsPayableVoucherRef
    {
        public Int64 Code { get; set; }
        public Int32 RecNo { get; set; }
        public String ReferenceNum { get; set; }
        public String APVNo { get; set; }
        public String RefType { get; set; }
        public String RefNo { get; set; }
    }
}
