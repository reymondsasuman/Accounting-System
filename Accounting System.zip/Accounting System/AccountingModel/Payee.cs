﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.AccountingModel
{
    class Payee
    {
        public Int32 PayeeNo { get; set; }
        public String PayeeName { get; set; }
        public String Address { get; set; }
        public String PayeeType { get; set; }
        public String ZipCode { get; set; }
        public String TIN { get; set; }
    }
}
