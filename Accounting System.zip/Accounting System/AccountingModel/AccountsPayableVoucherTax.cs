﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.AccountingModel
{
    class AccountsPayableVoucherTax
    {
        public Int64 Code { get; set; }
        public DateTime DateTrans { get; set; }
        public String ReferenceNum { get; set; }
        public Int32 PayeeNo { get; set; }
        public String PayeeType { get; set; }
        public String PayeeName { get; set; }
        public String PayTo { get; set; }
        public String PayToAddress { get; set; }
        public String PayToZipCode { get; set; }
        public String TIN { get; set; }
        public String APVNo { get; set; }
        public String APVType { get; set; }
        public String VatableType { get; set; }
        public Decimal NetVAT { get; set; }
        public Decimal EVAT { get; set; }
        public Decimal TotalAmount { get; set; }
        public Decimal AmountPaid { get; set; }
        public Int32 CustCode { get; set; }
        public Decimal Percentage { get; set; }
        public String ATCNo { get; set; }
        public Decimal AmountWithHeld { get; set; }
        public Decimal LocalTax { get; set; }
       
    }
}
