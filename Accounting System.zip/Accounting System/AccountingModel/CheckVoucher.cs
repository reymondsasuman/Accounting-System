﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.AccountingModel
{
    class CheckVoucher
    {
        public Int32 Code { get; set; }
        public String ReferenceNum { get; set; }
        public String CVNo { get; set; }
        public String Month { get; set; }
        public String Year { get; set; }
        public DateTime DateTrans { get; set; }
        public String Particulars { get; set; }
        public Int32 PayeeNo { get; set; }
        public String PayeeType { get; set; }
        public String PayeeName { get; set; }
        public String PayTo { get; set; }
        public String PayToAddress { get; set; }
        public String PayToZipCode { get; set; }
        public String TIN { get; set; }
        public Int32 CustCode { get; set; }
        public String CheckNo { get; set; }
        public DateTime CheckDate { get; set; }
        public Decimal Amount { get; set; }

        public Decimal GL_Debit { get; set; }

        public Decimal GL_Credit { get; set; }

        public Decimal SL_Debit { get; set; }

        public Decimal SL_Credit { get; set; }

        public Int32 TaxCount { get; set; }
        public String IsTaxable { get; set; }
    }
}
