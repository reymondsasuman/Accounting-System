﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.AccountingModel
{
    class Parameters
    {
        public String ParamName { get; set; }
        public String ParamValue { get; set; }
    }
}
