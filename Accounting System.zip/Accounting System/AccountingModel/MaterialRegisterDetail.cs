﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.AccountingModel
{
    class MaterialRegisterDetail
    {
        public Int64 Code { get; set; }
        public String ReferenceNum { get; set; }
        public Int32 BrachID { get; set; }
        public String BranchName { get; set; }
        public String TicketType { get; set; }
        public String TicketNo { get; set; }
        public String Month { get; set; }
        public String Year { get; set; }
        public String AcctCode { get; set; }
        public String AcctDesc { get; set; }
        public Decimal GL_Debit { get; set; }
        public Decimal GL_Credit { get; set; }
        public Decimal SL_Debit { get; set; }
        public Decimal SL_Credit { get; set; }

 
        public String RefNo { get; set; }
        public Int32 BranchID { get; set; }
        public DateTime DateTrans { get; set; }
        public String Remarks { get; set; }
        public String Cancel { get; set; }
    }
}
