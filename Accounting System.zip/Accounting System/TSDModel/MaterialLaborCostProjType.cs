﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.TSDModel
{
    class MaterialLaborCostProjType
    {
        public int TypeCode { get; set; }
        public String TypeName { get; set; }
        public String TypeDesc { get; set; }
        public String PriceBased { get; set; }
    }
}
