﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.TSDModel
{
    class MaterialLaborCostAddOnRegistry
    {
        public int ID { get; set; }
        public String AddOnDesc { get; set; }
        public int UnitID { get; set; }
        public String Unit { get; set; }
        public Decimal ChargeAmount { get; set; }


    }
}
