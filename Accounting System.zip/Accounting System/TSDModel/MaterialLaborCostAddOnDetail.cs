﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.TSDModel
{
    class MaterialLaborCostAddOnDetail:MaterialLaborCostAddOn
    {
        public int MLCAddOnDetailCode { get; set; }
        public String LaborDesc { get; set; }
        public String Unit { get; set; }
        public Decimal Quantity { get; set; }
        public Decimal UnitCost { get; set; }
        public Decimal TotalCost { get; set; }
        public Decimal UnitCostPer { get; set; }
        public Decimal TotalCostPer { get; set; }
        public String UnitSingular { get; set; }
        
    }
}
