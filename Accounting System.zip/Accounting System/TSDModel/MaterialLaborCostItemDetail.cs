﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.TSDModel
{
    class MaterialLaborCostItemDetail:MaterialLaborCostItem
    {
        public int MLCItemDetailCode { get; set; }
        public String LaborDesc { get; set; }
        public Int32 ProductCode { get; set; }
        public String ItemCode { get; set; }
        public String ProductDesc { get; set; }
        public String ProductName { get; set; }
        public String NEAPrice { get; set; }
        public Decimal Quantity { get; set; }
        public String Unit { get; set; }
        public Decimal UnitCost { get; set; }
        public Decimal TotalCost { get; set; }
        public String UnitSingular { get; set; }
        public Int32 SubClassID { get; set; }
        public String ProjectType { get; set; }
        public String ProjectClass { get; set; }
        public String SubClass { get; set; }
        public String SubClassDesc { get; set; }
        public String PriceMonth { get; set; }
        public String PriceYear { get; set; }

        public Decimal Available { get; set; }
        public int SortKey { get; set; }
        public String ExcludeInLabor { get; set; }
    }
}
