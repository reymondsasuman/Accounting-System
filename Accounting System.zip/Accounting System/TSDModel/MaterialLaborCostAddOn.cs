﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.TSDModel
{
    class MaterialLaborCostAddOn
    {
        public int MLCAddOnCode { get; set; }
        public String MLCNum { get; set; }
        public String ReferenceNum { get; set; }
        public String BranchName { get; set; }
        public Decimal VAT { get; set; }
        public Decimal GrandTotalCost { get; set; }
        public Decimal GrandTotalCostPer { get; set; }       
        public String FlagDel { get; set; } 
    }
}
