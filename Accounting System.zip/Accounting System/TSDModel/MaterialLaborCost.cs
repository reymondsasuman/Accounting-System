﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.TSDModel
{
    class MaterialLaborCost
    {
 
        public String MLCNum { get; set; }
        public String ReferenceNum { get; set; }
        public int BranchID { get; set; }
        public String BranchName { get; set; }
        public String Month { get; set; }
        public String Year { get; set; }
        public String DeptCode { get; set; }
        public int CustNo { get; set; }
        public String Owner { get; set; }
        public String ProjType { get; set; }
        public String ProjTitle { get; set; }
        public String Location { get; set; }
        public String PoleNum { get; set; }
        public int ContID { get; set; }
        public String ContName { get; set; }
        public String ContAddress { get; set; }
        public String ContTIN { get; set; }
        public DateTime MLCDate { get; set; }
        public String Status { get; set; }
        public Decimal LaborPer { get; set; }
        public Decimal VAT { get; set; }
        public Decimal MaterialCost { get; set; }
        public Decimal AddOnCost { get; set; }
        public Decimal LaborCost { get; set; }
        public Decimal Evat { get; set; }
        public Decimal CostOfProj { get; set; }

        public String EmpID { get; set; }
        public String EmpType { get; set; }
        public String Requestor { get; set; }
        public String AccountUse { get; set; }
        public String UserAccount { get; set; }
        public String CheckedByID { get; set; }
        public String CheckedByName { get; set; }

        public String Payable { get; set; }
        public String Paid { get; set; }

        public String ToBePaidBy { get; set; }
        public String Type { get; set; }
    }
}
