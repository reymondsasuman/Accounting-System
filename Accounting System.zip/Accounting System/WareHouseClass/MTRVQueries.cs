﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using anecoacct.WareHouseModel;
using System.Data.SqlClient;
using System.Windows.Forms;
using anecoacct.WareHouseClass;

namespace anecoacct.WareHouseClass
{
    class MTRVQueries
    {
        OtherQueries OtherQueries = new OtherQueries();
        frmWareHouseMTRV frmWareHouseMTRV = (frmWareHouseMTRV)Application.OpenForms["frmWareHouseMTRV"];

    


        public String EditMTRV (String ReferenceNum, String MTRVNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_EditMTRV";

                    param = cmd.Parameters.Add("@MTRVNum", SqlDbType.VarChar, 20);
                    param.Value = MTRVNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String SaveMTRVStatus(String MTRVNum,String Status, String Remarks, String Notes )
        {
            try
            {
                //save MRV Status
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveMTRVStatus";

                    param = cmd.Parameters.Add("@MTRVNum", SqlDbType.VarChar, 20);
                    param.Value = MTRVNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@MTRVStatus", SqlDbType.VarChar, 50);
                    param.Value = Status;

                    param = cmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 200);
                    param.Value = Remarks;

                    param = cmd.Parameters.Add("@Notes", SqlDbType.VarChar, 200);
                    param.Value = Notes;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }  

        public String SaveMTRV(MTRV MTRV)
        {
            try
            {
                //save MRV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveMTRV";

                    param = cmd.Parameters.Add("@MTRVNum", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MTRV.RefNum;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 20);
                    param.Value = MTRV.DeptCode;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MTRV.BranchName;

                    param = cmd.Parameters.Add("@BranchName_Source", SqlDbType.VarChar, 100);
                    param.Value = MTRV.BranchName_Source;

                    param = cmd.Parameters.Add("@BranchName_Destination", SqlDbType.VarChar, 100);
                    param.Value = MTRV.BranchName_Destination;

                    param = cmd.Parameters.Add("@GMLevel", SqlDbType.VarChar, 1);
                    param.Value = MTRV.GMLevel;

                    param = cmd.Parameters.Add("@EmpID", SqlDbType.VarChar, 30);
                    param.Value = MTRV.EmpID;

                    param = cmd.Parameters.Add("@EmpType", SqlDbType.VarChar, 50);
                    param.Value = MTRV.EmpType;

                    param = cmd.Parameters.Add("@WONo", SqlDbType.VarChar, 20);
                    param.Value = MTRV.WONo;

                    param = cmd.Parameters.Add("@JONo", SqlDbType.VarChar, 20);
                    param.Value = MTRV.JONo;


                    param = cmd.Parameters.Add("@MTRVDate", SqlDbType.DateTime);
                    param.Value = MTRV.MTRVDate;

                    param = cmd.Parameters.Add("@AwardedTo", SqlDbType.VarChar, 100);
                    param.Value = MTRV.AwardedTo;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar,1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewMTRVNum = Convert.ToString(cmd.Parameters["@MTRVNum"].Value.ToString());
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateMTRV(MTRV MTRV)
        {
            try
            {
                //save MRV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateMTRV";

                    param = cmd.Parameters.Add("@MTRVNum", SqlDbType.VarChar, 20);
                    param.Value = MTRV.MTRVNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MTRV.RefNum;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 20);
                    param.Value = MTRV.DeptCode;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MTRV.BranchName;

                    param = cmd.Parameters.Add("@BranchName_Source", SqlDbType.VarChar, 100);
                    param.Value = MTRV.BranchName_Source;

                    param = cmd.Parameters.Add("@BranchName_Destination", SqlDbType.VarChar, 100);
                    param.Value = MTRV.BranchName_Destination;

                    param = cmd.Parameters.Add("@GMLevel", SqlDbType.VarChar, 1);
                    param.Value = MTRV.GMLevel;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = MTRV.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = MTRV.Year;

                    param = cmd.Parameters.Add("@EmpID", SqlDbType.VarChar, 30);
                    param.Value = MTRV.EmpID;

                    param = cmd.Parameters.Add("@EmpType", SqlDbType.VarChar, 50);
                    param.Value = MTRV.EmpType;

                    param = cmd.Parameters.Add("@WONo", SqlDbType.VarChar, 20);
                    param.Value = MTRV.WONo;

                    param = cmd.Parameters.Add("@JONo", SqlDbType.VarChar, 20);
                    param.Value = MTRV.JONo;

                    param = cmd.Parameters.Add("@MTRVDate", SqlDbType.DateTime);
                    param.Value = MTRV.MTRVDate;

                    param = cmd.Parameters.Add("@AwardedTo", SqlDbType.VarChar, 100);
                    param.Value = MTRV.AwardedTo;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MTRV> GetMTRVList(String Param, String Flag)
        {
            List<MTRV> MTRVList = new List<MTRV>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMTRV";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MTRVList.Add(new MTRV()
                                {
                                    MTRVNum = Convert.ToString(dr["MTRVNum"].ToString())
                                    ,
                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                     ,
                                    GMLevel = String.IsNullOrEmpty(dr["GMLevel"].ToString()) ? "" : dr["GMLevel"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    //Purpose = Convert.ToString(dr["Purpose"].ToString())
                                    //  ,
                                    MTRVDate = Convert.ToDateTime(dr["MTRVDate"].ToString())
                                      ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    ,
                                    MTRVStatus = Convert.ToString(dr["MTRVStatus"].ToString())
                                        ,
                                    UserAccount = Convert.ToString(dr["AccountUse"].ToString())
                                    ,BranchName = Convert.ToString(dr["BranchName"].ToString())
                                });
                            }
                        }
                    }

                }
                return MTRVList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MTRV> GetMTRVList_ByStatus(String Status,String Param, String Flag)
        {
            List<MTRV> MTRVList = new List<MTRV>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMRV_ByStatus";
                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar, 100);
                    param.Value = Status;
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MTRVList.Add(new MTRV()
                                {
                                    MTRVNum = Convert.ToString(dr["MRVNum"].ToString())
                                    ,
                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    //Purpose = Convert.ToString(dr["Purpose"].ToString())
                                    //  ,
                                    MTRVDate = Convert.ToDateTime(dr["MRVDate"].ToString())
                                      ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    ,
                                    MTRVStatus = Convert.ToString(dr["MRVStatus"].ToString())
                                        ,
                                    UserAccount = Convert.ToString(dr["AccountUse"].ToString())
                                });
                            }
                        }
                    }

                }
                return MTRVList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<MTRVDetail> GetMTRVDetailList(String Param, String Flag, String ReferenceNum)
        {
            List<MTRVDetail> MTRVDetailList = new List<MTRVDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMTRVDetail";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MTRVDetailList.Add(new MTRVDetail()
                                {
                                    MTRVNum = Convert.ToString(dr["MTRVNum"].ToString())
                                    ,
                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    GMLevel = String.IsNullOrEmpty(dr["GMLevel"].ToString()) ? "" : dr["GMLevel"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())
                                      ,BranchName = String.IsNullOrEmpty(dr["BranchName"].ToString()) ? "" : dr["BranchName"].ToString()
                                     ,
                                    BranchName_Source = String.IsNullOrEmpty(dr["BranchName_Source"].ToString()) ? "" : dr["BranchName_Source"].ToString()
                                     ,
                                    BranchName_Destination = String.IsNullOrEmpty(dr["BranchName_Destination"].ToString()) ? "" : dr["BranchName_Destination"].ToString()

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                      ,
                                    MTRVDate = Convert.ToDateTime(dr["MTRVDate"].ToString())
                                      ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                  
                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    ,
                                    MTRVStatus = Convert.ToString(dr["MTRVStatus"].ToString())
                                         ,
                                    ItemCode= Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,
                                    UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                        ,
                                    MTRVDetailNum = Convert.ToInt32(dr["MTRVDetailNum"].ToString())
                                       ,
                                    Available = Convert.ToString(dr["Available"].ToString())
                                       ,
                                     
                                    SubClassID = Convert.ToInt32(dr["SubClassID"].ToString())
                                    ,
                                    ProjectType = Convert.ToString(dr["ProjectType"].ToString())
                                                                        ,
                                    ProjectClass = Convert.ToString(dr["ProjectClass"].ToString())
                                                                        ,
                                    SubClass = Convert.ToString(dr["SubClass"].ToString())
                                                                        ,
                                    SubClassDesc = Convert.ToString(dr["SubClassDesc"].ToString())
                                   
                                });
                            }
                        }
                    }

                }
                return MTRVDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
     
        public List<MTRVDetail> GetMTRVDetailList_TempTable(String Param, String Flag)
        {
            List<MTRVDetail> MTRVDetailList = new List<MTRVDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;   
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMTRVDetail_Temp";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MTRVDetailList.Add(new MTRVDetail()
                                {
                                  
                                    MTRVNum = Convert.ToString(dr["MTRVNum"].ToString())
                                    ,
                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                      ,
                                    
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,
                                    MTRVDetailNum = Convert.ToInt32(dr["MTRVDetailNum"].ToString())
                                       ,
                                    Available = Convert.ToString(dr["Available"].ToString())
                                    ,
                                    UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                    ,SubClassID = Convert.ToInt32(dr["SubClassID"].ToString())
                                    ,
                                    ProjectType = Convert.ToString(dr["ProjectType"].ToString())
                                                                        ,
                                    ProjectClass = Convert.ToString(dr["ProjectClass"].ToString())
                                                                        ,
                                    SubClass = Convert.ToString(dr["SubClass"].ToString())
                                                                        ,
                                    SubClassDesc = Convert.ToString(dr["SubClassDesc"].ToString())
                                });
                            }
                        }
                    }

                }
                return MTRVDetailList;
                
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        //public List<CanvassSheetDetail> GetCanvassSheetDetailList(String Param, String Flag)
        //{
        //    List<CanvassSheetDetail> CanvassSheetDetailList = new List<CanvassSheetDetail>();
        //    try
        //    {
        //        using (SqlCommand cmd = new SqlCommand())
        //        {
        //            cmd.Connection = DatabaseConnection.cnn;
        //            DatabaseConnection.Connect();
        //            SqlParameter param = new SqlParameter();
        //            cmd.CommandTimeout = 6000;
        //            cmd.CommandType = CommandType.StoredProcedure;
        //            cmd.CommandText = "warehouse.sp_GetMRVDetail";
        //            param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
        //            param.Value = Param;
        //            param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
        //            param.Value = Flag;
        //            using (SqlDataReader dr = cmd.ExecuteReader())
        //            {
        //                if (dr.HasRows)
        //                {
        //                    while (dr.Read())
        //                    {
        //                        CanvassSheetDetailList.Add(new CanvassSheetDetail()
        //                        {
        //                            MRVNum = Convert.ToString(dr["MRVNum"].ToString())
        //                            ,
        //                            RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
        //                            ,
        //                            DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
        //                            ,
        //                            Month = Convert.ToString(dr["Month"].ToString())
        //                             ,
        //                            Year = Convert.ToString(dr["Year"].ToString())
        //                              ,
        //                            Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
        //                              ,
        //                            EmpID = Convert.ToString(dr["EmpID"].ToString())

        //                           ,
        //                            EmpType = Convert.ToString(dr["EmpType"].ToString())
        //                            ,
        //                            WONo = Convert.ToString(dr["WONo"].ToString())
        //                            ,
        //                            JONo = Convert.ToString(dr["JONo"].ToString())
        //                             ,
        //                            Purpose = Convert.ToString(dr["Purpose"].ToString())
        //                              ,
        //                            MRVDate = Convert.ToDateTime(dr["MRVDate"].ToString())
        //                              ,
        //                            AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
        //                            ,
        //                            IsClosed = Convert.ToString(dr["IsClosed"].ToString())
        //                            ,
        //                            MRVStatus = Convert.ToString(dr["MRVStatus"].ToString())
        //                                 ,
        //                            ItemCode = Convert.ToString(dr["ItemCode"].ToString())
        //                            ,
        //                            ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
        //                                 ,
        //                            ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
        //                                 ,
        //                            ProductName = Convert.ToString(dr["ProductName"].ToString())
        //                                 ,
        //                            Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
        //                                ,
        //                            Unit = Convert.ToString(dr["Unit"].ToString())
        //                                ,
        //                            MRVDetailNum = Convert.ToInt32(dr["MRVDetailNum"].ToString())
        //                               ,
        //                            Available = Convert.ToString(dr["Available"].ToString())
        //                               ,
        //                            BiddingRefNum = Convert.ToString(dr["BiddingRefNum"].ToString())
        //                        });
        //                    }
        //                }
        //            }

        //        }
        //        return CanvassSheetDetailList;
        //    }
        //    catch (Exception ex)
        //    {

        //        return null;
        //    }
        //    finally
        //    {
        //        DatabaseConnection.DBClose();
        //    }
        //}
        public String AddMTRVItem(MTRVDetail MTRVDetail, String Flag)
        {
            try 
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_AddMTRVItem";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MTRVDetail.RefNum;

                    param = cmd.Parameters.Add("@MTRVNum", SqlDbType.VarChar, 20);
                    param.Value = MTRVDetail.MTRVNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MTRVDetail.BranchName;

                    param = cmd.Parameters.Add("@BranchName_Source", SqlDbType.VarChar, 100);
                    param.Value = MTRVDetail.BranchName_Source;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = MTRVDetail.ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = String.IsNullOrEmpty(MTRVDetail.ItemCode)?"": MTRVDetail.ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 1000);
                    param.Value = MTRVDetail.ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar,1000);
                    param.Value = MTRVDetail.ProductDesc;

                    param = cmd.Parameters.Add("@UnitDesc", SqlDbType.VarChar, 20);
                    param.Value = MTRVDetail.Unit;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = MTRVDetail.Quantity;

                    param = cmd.Parameters.Add("@Purpose", SqlDbType.VarChar, 800);
                    param.Value = MTRVDetail.Purpose;

                    param = cmd.Parameters.Add("@Available", SqlDbType.VarChar, 1);
                    param.Value = String.IsNullOrEmpty(MTRVDetail.Available)? "": MTRVDetail.Available;

                    param = cmd.Parameters.Add("@IsReg", SqlDbType.VarChar, 1);
                    param.Value = MTRVDetail.IsReg;

                    param = cmd.Parameters.Add("@SubClassID", SqlDbType.Int);
                    param.Value = MTRVDetail.SubClassID;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemoveMTRVItem(String MTRVDetailNum, String ReferenceNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_RemoveMTRVItem";

                    param = cmd.Parameters.Add("@MTRVDetailNum", SqlDbType.VarChar, 20);
                    param.Value = MTRVDetailNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;                

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String DeleteMTRV(String MRVNum, String MRVStatus, String BranchName )
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_DeleteMTRV";

                    param = cmd.Parameters.Add("@MTRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                    
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String DeleteFullMTRV(String MRVNum, String MRVStatus)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_DeleteFullMRV";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@MRVStatus", SqlDbType.VarChar, 50);
                    param.Value = MRVStatus;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CancelMTRV(String ReferenceNum, String MRVNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CancelMTRV";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@MTRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public void DeleteMTRVDetail(String MRVNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_DeleteMRVDetail";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                return;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

       
        public String UpdateMTRVItem(MTRVDetail MTRVDetail)
        {
            try
            {
                //update MRV item in temp table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateMTRVItem";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = MTRVDetail.RefNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MTRVDetail.BranchName;

                    param = cmd.Parameters.Add("@BranchName_Source", SqlDbType.VarChar, 100);
                    param.Value = MTRVDetail.BranchName_Source;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = MTRVDetail.ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar,50);
                    param.Value = MTRVDetail.ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 1000);
                    param.Value = MTRVDetail.ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar, 1000);
                    param.Value = MTRVDetail.ProductDesc;

                    param = cmd.Parameters.Add("@Unit", SqlDbType.VarChar, 50);
                    param.Value = MTRVDetail.Unit;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = MTRVDetail.Quantity;

                    param = cmd.Parameters.Add("@Purpose", SqlDbType.VarChar, 800);
                    param.Value = MTRVDetail.Purpose;

                    param = cmd.Parameters.Add("@SubClassID", SqlDbType.Int);
                    param.Value = MTRVDetail.SubClassID;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String CheckMTRVStatus(String MTRVNum, String Action, String GMLevel)
        {
            try
            {
                //save MRV Status
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckMTRVStatus";

                    param = cmd.Parameters.Add("@MTRVNum", SqlDbType.VarChar, 20);
                    param.Value = MTRVNum;

                    param = cmd.Parameters.Add("@GMLevel", SqlDbType.VarChar, 1);
                    param.Value = GMLevel;

                    param = cmd.Parameters.Add("@Action", SqlDbType.VarChar, 50);
                    param.Value = Action;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CheckMTRVOwner(String MRVNum, Int32 UserID)
        {
            try
            {
                //save MRV Status
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckMRVOwner";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 200);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<RIVClass> GetRIVClassList(String Param,String DeptCode, String Flag)
        {
            List<RIVClass> MRVClassList = new List<RIVClass>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetRIVClass";

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 100);
                    param.Value = DeptCode;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MRVClassList.Add(new RIVClass()
                                {
                                    SubClassID = Convert.ToInt32(dr["SubClassID"].ToString())
                                    ,
                                    ProjectType = String.IsNullOrEmpty(dr["ProjectType"].ToString()) ? "" : dr["ProjectType"].ToString()
                                    ,
                                    ProjectClass = String.IsNullOrEmpty(dr["ProjectClass"].ToString()) ? "" : dr["ProjectClass"].ToString()
                                    ,
                                    SubClass = String.IsNullOrEmpty(dr["SubClass"].ToString()) ? "" : dr["SubClass"].ToString()
                                     ,
                                    SubClassDesc = String.IsNullOrEmpty(dr["SubClassDesc"].ToString()) ? "" : dr["SubClassDesc"].ToString()

                                });
                            }
                        }
                    }

                }
                return MRVClassList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String GetMTRVCurrentStatus(String MTRVNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMTRVCurrentStatus";

                    param = cmd.Parameters.Add("@MTRVNum", SqlDbType.VarChar, 20);
                    param.Value = MTRVNum;
     
                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar, 50);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Status"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String ImportMTRV(String ReferenceNum, String MRVNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_ImportMRV";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String ReAlignMTRVItem(String MRVNum, Int32 MRVDetailNum, Int32 ProductCode, String ItemCode, String ProductName, String ProductDesc
            , Int32 OldProductCode, String OldItemCode, String OldProductName, String OldProductDesc, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_ReAlignMRVItem";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@MRVDetailNum", SqlDbType.Int);
                    param.Value = MRVDetailNum;

                    param = cmd.Parameters.Add("@OldProductCode", SqlDbType.Int);
                    param.Value = OldProductCode;

                    param = cmd.Parameters.Add("@OldItemCode", SqlDbType.VarChar);
                    param.Value = OldItemCode;

                    param = cmd.Parameters.Add("@OldProductName", SqlDbType.VarChar);
                    param.Value = OldProductName;

                    param = cmd.Parameters.Add("@OldProductDesc", SqlDbType.VarChar);
                    param.Value = OldProductDesc;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar);
                    param.Value = ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar);
                    param.Value = ProductDesc;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
    }
}
