﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Data;
using anecoacct.WareHouseModel;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;

namespace anecoacct.WareHouseClass
{
    class OtherQueries
    {
        
        public List<Employee> GetEmployeeInfo(String Param, String Flag, String ServType, String DeptID)
        {
            List<Employee> EmployeeList = new List<Employee>();
            try
            {          
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetEmployeeInfo";
                    param = cmd.Parameters.Add("@param", SqlDbType.VarChar, 50);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    param = cmd.Parameters.Add("@ServType", SqlDbType.VarChar, 50);
                    param.Value = ServType;
                    param = cmd.Parameters.Add("@DeptID", SqlDbType.VarChar, 20);
                    param.Value = DeptID;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                              
                                EmployeeList.Add(new Employee()
                                {

                                    EmpID = String.IsNullOrEmpty(dr["EmpID"].ToString()) ? "" : dr["EmpID"].ToString()
                                    ,
                                    EmpName = String.IsNullOrEmpty(dr["EmpName"].ToString()) ? "" : dr["EmpName"].ToString()
                                    ,
                                    //DeptID = String.IsNullOrEmpty(dr["DeptID"].ToString()) ? "" : dr["DeptID"].ToString()
                                    // ,
                                    DeptDesc = String.IsNullOrEmpty(dr["DeptDesc"].ToString()) ? "" : dr["DeptDesc"].ToString()
                                   ,
                                    JobDesc = String.IsNullOrEmpty(dr["JobDesc"].ToString()) ? "" : dr["JobDesc"].ToString()
                                    ,
                                    EmpType = String.IsNullOrEmpty(dr["EmpType"].ToString()) ? "" : dr["EmpType"].ToString()

                                });

                            }
                        }
                    }

                }
                return EmployeeList;
            }
            catch (Exception ex)
            {
               // MessageBox.Show(ex.Message, "opps", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }


        public List<Department> GetDepartmentInfo(String Param, String Flag)
        {
            List<Department> DepartmentList = new List<Department>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetDepartment";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 50);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
               
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                DepartmentList.Add(new Department()
                                {
                                    DeptID = String.IsNullOrEmpty(dr["DeptID"].ToString()) ? "" : dr["DeptID"].ToString()
                                    ,
                                    Gendept = String.IsNullOrEmpty(dr["Gendept"].ToString()) ? "" : dr["Gendept"].ToString()
                                    ,
                               
                                    DeptDesc = String.IsNullOrEmpty(dr["DeptDesc"].ToString()) ? "" : dr["DeptDesc"].ToString()
                                   ,
                                    BranchID =Convert.ToInt32(dr["BranchID"].ToString())

                                });
                            }
                        }
                    }

                }
                return DepartmentList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public IPAddress LocalIPAddress()
        {
            if (!System.Net.NetworkInformation.NetworkInterface.GetIsNetworkAvailable())
            {
                return null;
            }

            IPHostEntry host = Dns.GetHostEntry(Dns.GetHostName());

            return host
                .AddressList
                .FirstOrDefault(ip => ip.AddressFamily == AddressFamily.InterNetwork);
        }

        public string GetReferenceNum()
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetReferenceNumber";
                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;
                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;
                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@ReferenceNum"].Value);
                }
            }
            catch (Exception ex)
            {

                return "";
            }
          finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<TransactionStatus> GetTransactionStatus(String Param, String Flag)
        {
            List<TransactionStatus> TransactionStatusList = new List<TransactionStatus>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetTransactionStatus";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 50);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                TransactionStatusList.Add(new TransactionStatus()
                                {
                                    Entry = String.IsNullOrEmpty(dr["Entry"].ToString()) ? 0 : Convert.ToInt32(dr["Entry"].ToString())
                                    ,
                                    TransStatus = String.IsNullOrEmpty(dr["TransStatus"].ToString()) ? "" : dr["TransStatus"].ToString()
                                    ,

                                    SortKey = String.IsNullOrEmpty(dr["SortKey"].ToString()) ? 0 : Convert.ToInt32(dr["SortKey"].ToString())
                                    

                                });
                            }
                        }
                    }

                }
                return TransactionStatusList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String GetlocationByDeptCode(String DeptCode, String Param, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetLocationByDeptCode";

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 50);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 50);
                    param.Value = DeptCode;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    cmd.ExecuteNonQuery();

                    return Convert.ToString(cmd.Parameters["@BranchName"].Value);
                }
            }
            catch (Exception ex)
            {

                return "";
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<Branch> Getlocation(String Param, String Flag)
        {
            try
            {
                List<Branch> BranchList = new List<Branch>();
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetLocation";

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 50);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                BranchList.Add(new Branch()
                                {
                                    BranchID = Convert.ToInt32(dr["BranchID"].ToString())
                                    ,
                                    BranchName = String.IsNullOrEmpty(dr["BranchName"].ToString()) ? "" : dr["BranchName"].ToString()
                                   

                                });
                            }
                       
                        }
                    }
                    return BranchList;
                }
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public string CheckWareHouseDateTransValidity( DateTime DateTrans)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetWareHouseTransDateValidity";
                    
                    param = cmd.Parameters.Add("@DateTrans", SqlDbType.DateTime);
                    param.Value = DateTrans;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar,1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public void RecountDGNumbering(DataGridView dg)
        {
            int x = 0;
            foreach (DataGridViewRow row in dg.Rows)
            {
                dg.Rows[x].Cells[0].Value = (x + 1).ToString();
                x++;
            }
        }
    }
}
