﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using anecoacct.WareHouseModel;
using System.Data.SqlClient;
using System.Windows.Forms;
using anecoacct.WareHouseClass;

namespace anecoacct.WareHouseClass
{
    class MTCTQueries
    {
        OtherQueries OtherQueries = new OtherQueries();
        modFunctions GlobalFunc = new modFunctions();
        public String UpdateMTCTDetailItem(String ReferenceNum, Int32 MRVDetailNum, String AcctCode)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateMCTDetailItemAcctCode";

                    param = cmd.Parameters.Add("@MCTReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = AcctCode;

                    param = cmd.Parameters.Add("@MRVDetailNum", SqlDbType.Int);
                    param.Value = MRVDetailNum;

                    param = cmd.Parameters.Add("@AcctCode", SqlDbType.VarChar, 20);
                    param.Value = AcctCode;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }


        public String GetGatePassDetailIntoMTCTDetailTemp(String GatePassNum, String ReferenceNum,String BranchName, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetGatePassDetailIntoMTCTDetailTemp";

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Value = GatePassNum;

                    param = cmd.Parameters.Add("@MTCTReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 800);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String SaveMTCT(MTCT MTCT)
        {
            try
            {
                //save MRV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveMTCT";

                    param = cmd.Parameters.Add("@MTCTNum", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MTCT.RefNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar,100);
                    param.Value = MTCT.BranchName;

                    param = cmd.Parameters.Add("@BranchName_Source", SqlDbType.VarChar, 100);
                    param.Value = MTCT.BranchName_Source;

                    param = cmd.Parameters.Add("@BranchName_Destination", SqlDbType.VarChar, 100);
                    param.Value = MTCT.BranchName_Destination;

                    param = cmd.Parameters.Add("@MTRVNum", SqlDbType.VarChar, 20);
                    param.Value = MTCT.MTRVNum;

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Value = MTCT.GatePassNum;

                    param = cmd.Parameters.Add("@MTCTDate", SqlDbType.DateTime);
                    param.Value = MTCT.MTCTDate;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 20);
                    param.Value = MTCT.DeptCode;

                    param = cmd.Parameters.Add("@WONo", SqlDbType.VarChar, 20);
                    param.Value = MTCT.WONo;

                    param = cmd.Parameters.Add("@JONo", SqlDbType.VarChar, 20);
                    param.Value = MTCT.JONo;

                    param = cmd.Parameters.Add("@AwardedTo", SqlDbType.VarChar, 100);
                    param.Value = MTCT.AwardedTo;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewMTCTNum = Convert.ToString(cmd.Parameters["@MTCTNum"].Value.ToString());
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CancelMTCT(String ReferenceNum, String MTRVNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CancelMTCT";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@MTRVNum", SqlDbType.VarChar, 20);
                    param.Value = MTRVNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String EditMTCT(String ReferenceNum, String MCTNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_EditMCT";

                    param = cmd.Parameters.Add("@MCTNum", SqlDbType.VarChar, 20);
                    param.Value = MCTNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateMTCT(MTCT MTCT)
        {
            try
            {
                //update MRV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateMCT";

                    param = cmd.Parameters.Add("@MCTNum", SqlDbType.VarChar, 20);
                    param.Value = MTCT.MTCTNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = MTCT.RefNum;

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MTCT.MTRVNum;

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Value = MTCT.GatePassNum;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 20);
                    param.Value = MTCT.DeptCode;

                    param = cmd.Parameters.Add("@WONo", SqlDbType.VarChar, 20);
                    param.Value = MTCT.WONo;


                    param = cmd.Parameters.Add("@JONo", SqlDbType.VarChar, 20);
                    param.Value = MTCT.JONo;

                    param = cmd.Parameters.Add("@AwardedTo", SqlDbType.VarChar, 100);
                    param.Value = MTCT.AwardedTo;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MTCT> GetMTCTList(String Param, String Flag)
        {
            List<MTCT> MTCTList = new List<MTCT>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMTCT";

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MTCTList.Add(new MTCT()
                                {
                                    MTCTNum = Convert.ToString(dr["MTCTNum"].ToString())
                                    ,MTCTDate = Convert.ToDateTime(dr["MTCTDate"].ToString())
                                    
                                    ,GatePassNum = Convert.ToString(dr["GatePassNum"].ToString())
                                    ,
                                  
                                    MTRVNum = Convert.ToString(dr["MTRVNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                     ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                       ,
                                    UserAccount = String.IsNullOrEmpty(dr["AccountUse"].ToString()) ? "" : dr["AccountUse"].ToString()
                                        ,
                                    BranchName_Destination = String.IsNullOrEmpty(dr["BranchLocation"].ToString()) ? "" : dr["BranchLocation"].ToString()
                                        ,
                                    BranchName_Source = String.IsNullOrEmpty(dr["SourceLocation"].ToString()) ? "" : dr["SourceLocation"].ToString()

                                });
                            }
                        }
                    }

                }
                return MTCTList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MTCTDetail> GetMTCTDetailList(String Param, String Flag)
        {
            List<MTCTDetail> MTCTDetailList = new List<MTCTDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMTCTDetail";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MTCTDetailList.Add(new MTCTDetail()
                                {
                                    MTCTDate = Convert.ToString(dr["MTCTDate"].ToString())
                                    ,
                                    MTCTNum = Convert.ToString(dr["MTCTNum"].ToString())
                                    ,
                                    MTCTDetailNum = Convert.ToInt32(dr["MTCTDetailNum"].ToString())
                                    ,
                                    AcctCode = Convert.ToString(dr["AcctCode"].ToString())
                                    ,
                                    AcctDesc = Convert.ToString(dr["AcctDesc"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    MTRVNum = Convert.ToString(dr["MTRVNum"].ToString())
                                    ,
                                    GatePassNum = Convert.ToString(dr["GatePassNum"].ToString())
                                    ,
                                    MTRVDate = Convert.ToString(dr["MTRVDate"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                      ,

                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    GatePassDetailNum = Convert.ToInt32(dr["GatePassDetailNum"].ToString())
                                    ,
                                  
                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                   
                                    //GMLevel = String.IsNullOrEmpty(dr["GMLevel"].ToString()) ? "" : dr["GMLevel"].ToString()
                                    //,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                  
                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    
                                     ,
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,
                                    UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                        ,
                                    MTRVDetailNum = Convert.ToInt32(dr["MTRVDetailNum"].ToString())
                                       ,
                                    Available = Convert.ToString(dr["Available"].ToString())
                                       ,

                                    SubClassID = Convert.ToInt32(dr["SubClassID"].ToString())
                                    ,
                                    ProjectType = Convert.ToString(dr["ProjectType"].ToString())
                                                                        ,
                                    ProjectClass = Convert.ToString(dr["ProjectClass"].ToString())
                                                                        ,
                                    SubClass = Convert.ToString(dr["SubClass"].ToString())
                                                                        ,
                                    SubClassDesc = Convert.ToString(dr["SubClassDesc"].ToString())
                                    ,
                                    ReceivedBy = Convert.ToString(dr["ReceivedBy"].ToString())
                                });
                            }
                        }
                    }

                }
                return MTCTDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CheckMaterialTransferChargeTicketItemHasDetail(String ReferenceNum, Int32 ProductCode, String ItemCode, String ProductName, Decimal Quantity)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckMTCTItemHasDetail";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 1000);
                    param.Value = ProductName;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = Quantity;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 200);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<ProductView> GetMTCTItemThatHasDetail(String ReferenceNum, String Flag)
        {
            List<ProductView> ProductViewList = new List<ProductView>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMaterialTransferChargeTicketItemThatHasDetail";
                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ProductViewList.Add(new ProductView()
                                {
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                    ,
                                    ItemCode = String.IsNullOrEmpty(dr["ItemCode"].ToString()) ? "" : dr["ItemCode"].ToString()
                                    ,

                                    ProductName = String.IsNullOrEmpty(dr["ProductName"].ToString()) ? "" : dr["ProductName"].ToString()
                                      ,

                                    Unit = String.IsNullOrEmpty(dr["Unit"].ToString()) ? "" : dr["Unit"].ToString()
                                       ,

                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                });
                            }
                        }
                    }

                }
                return ProductViewList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String CheckMTCTCheckedMark(String Month, string Year, String BranchName)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckMTCTCheckedMark";

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String SetMTCTCheckedStatus(String Action, String MTCTNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SetMTCTCheckedStatus";

                    param = cmd.Parameters.Add("@Action", SqlDbType.VarChar, 20);
                    param.Value = Action;

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 20);
                    param.Value = MTCTNum;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = "Status";

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<MTCT> GetMTCTPerPeriodList(String Month, String Year, String BranchName, String Flag, String Param)
        {
            List<MTCT> MTCTList = new List<MTCT>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMTCTPerPeriod";

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = GlobalFunc.GetMonthNum(Month);

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 50);
                    param.Value = Param;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MTCTList.Add(new MTCT()
                                {
                                    MTCTNum = Convert.ToString(dr["MTCTNum"].ToString())
                                    ,
                                    MTCTDate = Convert.ToDateTime(dr["MTCTDate"].ToString())

                                    ,
                                    GatePassNum = Convert.ToString(dr["GatePassNum"].ToString())
                                    ,

                                    MTRVNum = Convert.ToString(dr["MTRVNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                     ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                       ,
                                    UserAccount = String.IsNullOrEmpty(dr["AccountUse"].ToString()) ? "" : dr["AccountUse"].ToString()
                                    ,
                                    BranchName = String.IsNullOrEmpty(dr["BranchName"].ToString()) ? "" : dr["BranchName"].ToString()
                                    ,
                                    TotalCost = Convert.ToDecimal(dr["TotalCost"].ToString())
                                    ,
                                    Checked = Convert.ToString(dr["Checked"].ToString())
                                });
                            }
                        }
                    }


                }
                return MTCTList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<MTCTDetail> GetMTCTDetailListPerPeriod(String Param, String Month, String Year, String Flag)
        {
            List<MTCTDetail> MTCTDetailList = new List<MTCTDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMTCTDetailPerPeriod";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = GlobalFunc.GetMonthNum(Month);

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MTCTDetailList.Add(new MTCTDetail()
                                {
                                    MTCTDate = Convert.ToString(dr["MTCTDate"].ToString())
                                    ,
                                    MTCTNum = Convert.ToString(dr["MTCTNum"].ToString())
                                    ,
                                    MTCTDetailNum = Convert.ToInt32(dr["MTCTDetailNum"].ToString())
                                    ,
                                    AcctCode = Convert.ToString(dr["AcctCode"].ToString())
                                    ,
                                    AcctDesc = Convert.ToString(dr["AcctDesc"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    MTRVNum = Convert.ToString(dr["MTRVNum"].ToString())
                                    ,
                                    GatePassNum = Convert.ToString(dr["GatePassNum"].ToString())
                                    ,
                                    MTRVDate = Convert.ToString(dr["MTRVDate"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                      ,

                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    GatePassDetailNum = Convert.ToInt32(dr["GatePassDetailNum"].ToString())
                                    ,

                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,

                                    GMLevel = String.IsNullOrEmpty(dr["GMLevel"].ToString()) ? "" : dr["GMLevel"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,

                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())

                                     ,
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,
                                    UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                        ,
                                    MTRVDetailNum = Convert.ToInt32(dr["MTRVDetailNum"].ToString())
                                       ,
                                    Available = Convert.ToString(dr["Available"].ToString())
                                       ,

                                    SubClassID = Convert.ToInt32(dr["SubClassID"].ToString())
                                    ,
                                    ProjectType = Convert.ToString(dr["ProjectType"].ToString())
                                                                        ,
                                    ProjectClass = Convert.ToString(dr["ProjectClass"].ToString())
                                                                        ,
                                    SubClass = Convert.ToString(dr["SubClass"].ToString())
                                                                        ,
                                    SubClassDesc = Convert.ToString(dr["SubClassDesc"].ToString())
                                    ,
                                    ReceivedBy = Convert.ToString(dr["ReceivedBy"].ToString())
                                    ,
                                    BranchName = Convert.ToString(dr["BranchName"].ToString())
                                       ,
                                    UnitCost = Convert.ToDecimal(dr["UnitCost"].ToString())

                                });
                            }
                        }
                    }

                }
                return MTCTDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }

        }

        public String SavedTransactionClose(String TransType, String Month, String Year)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveTransactionClose";

                    param = cmd.Parameters.Add("@TransType", SqlDbType.VarChar, 50);
                    param.Value = TransType;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
    }
}
