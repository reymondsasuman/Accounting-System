﻿using anecoacct.WareHouseModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseClass
{
    class ReceivingReportQueries
    {
        OtherQueries OtherQueries = new OtherQueries();
        modFunctions GlobalFunc = new modFunctions();
        public String UpdatePurchaseOrder(PurchaseOrder PurchaseOrder)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdatePurchaseOrder";

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrder.PurchaseOrderNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = PurchaseOrder.ReferenceNum;

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrder.RIVNum;

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrder.CanvassSheetNum;

                    param = cmd.Parameters.Add("@Vatable", SqlDbType.VarChar, 1);
                    param.Value = PurchaseOrder.Vatable;

                    param = cmd.Parameters.Add("@Vat", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = PurchaseOrder.Vat;

                    param = cmd.Parameters.Add("@TotalCost", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = PurchaseOrder.TotalCost;

                    param = cmd.Parameters.Add("@Terms", SqlDbType.VarChar, 200);
                    param.Value = PurchaseOrder.Terms;

                    param = cmd.Parameters.Add("@DeliveryPeriod", SqlDbType.VarChar, 200);
                    param.Value = PurchaseOrder.DeliveryPeriod;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String EditPurchaseOrder(String PurchaseOrderNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_EditPurchaseOrder";

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrderNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String SavePurchaseOrderDetail_TempBatch(String CanvassSheetNum, String ReferenceNumber, String SupplierName)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SavePurchaseOrderDetail_TempBatch";

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheetNum.Trim();

                    param = cmd.Parameters.Add("@ReferenceNumber", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNumber.Trim();

                    param = cmd.Parameters.Add("@SupplierName", SqlDbType.VarChar, 500);
                    param.Value = SupplierName.Trim();

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;
                    cmd.ExecuteNonQuery();

                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }


        public List<PurchaseOrderTermsOfPayments> GetTermsOfPaymentList (String Param, String Flag)
        {
            try
            {
                List<PurchaseOrderTermsOfPayments> PurchaseOrderTermsOfPaymentsList = new List<PurchaseOrderTermsOfPayments>();
                using (SqlCommand cmd= new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetPurchaseOrderTermsOfPayments";

                    param = cmd.Parameters.Add("@param", SqlDbType.VarChar, 20);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;
                    using (SqlDataReader dr =cmd.ExecuteReader())
                    {
                        if(dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                PurchaseOrderTermsOfPaymentsList.Add(new PurchaseOrderTermsOfPayments()
                                {
                                    ID = Convert.ToInt32(dr["PurchaseOrderTermsOfPaymentsID"].ToString())
                                    ,Code = Convert.ToString(dr["Code"].ToString())
                                });
                            }
                        }
                    }
                    return PurchaseOrderTermsOfPaymentsList;
                }
            }
            catch (Exception )
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<ReceivingReportType> GetRRTypeList(String Param, String Flag)
        {
            try
            {
                List<ReceivingReportType> ReceivingReportTypeList = new List<ReceivingReportType>();
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetReceivingReportType";

                    param = cmd.Parameters.Add("@param", SqlDbType.VarChar, 20);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ReceivingReportTypeList.Add(new ReceivingReportType()
                                {
                                    TypeID = Convert.ToInt32(dr["TypeID"].ToString())
                                    ,
                                    RRType = Convert.ToString(dr["RRType"].ToString())
                                });
                            }
                        }
                    }
                    return ReceivingReportTypeList;
                }
            }
            catch (Exception)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String SaveReceivingReport(ReceivingReport ReceivingReport)
        {
            try
            {
                //save RIV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveReceivingReport";

                    param = cmd.Parameters.Add("@RRNum", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReceivingReport.ReferenceNum;

                    param = cmd.Parameters.Add("@RRType", SqlDbType.VarChar, 100);
                    param.Value = ReceivingReport.RRType;

                    param = cmd.Parameters.Add("@DateProcess", SqlDbType.DateTime);
                    param.Value = ReceivingReport.DateProcess;

                    param = cmd.Parameters.Add("@ReceivedBy", SqlDbType.VarChar, 500);
                    param.Value = ReceivingReport.ReceivedBy;

                    param = cmd.Parameters.Add("@EmpID", SqlDbType.VarChar,10);
                    param.Value = ReceivingReport.EmpID;

                    param = cmd.Parameters.Add("@EmpType", SqlDbType.VarChar, 50);
                    param.Value = ReceivingReport.EmpType;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = ReceivingReport.BranchName;

                    param = cmd.Parameters.Add("@DeliveryStatus", SqlDbType.VarChar, 50);
                    param.Value = ReceivingReport.DeliveryStatus;

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = ReceivingReport.PurchaseOrderNum;

                    param = cmd.Parameters.Add("@PurchaseOrderDate", SqlDbType.DateTime);
                    param.Value = ReceivingReport.PurchaseOrderDate;

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = ReceivingReport.RIVNum;

                    param = cmd.Parameters.Add("@InvoiceNum", SqlDbType.VarChar, 20);
                    param.Value = ReceivingReport.InvoiceNum;

                    param = cmd.Parameters.Add("@InvoiceDate", SqlDbType.DateTime);
                    param.Value = ReceivingReport.InvoiceDate;

                    param = cmd.Parameters.Add("@DRNum", SqlDbType.VarChar,50);
                    param.Value = ReceivingReport.DRNum;

                    param = cmd.Parameters.Add("@DRDate", SqlDbType.DateTime);
                    param.Value = ReceivingReport.DRDate;

                    param = cmd.Parameters.Add("@CVNum", SqlDbType.VarChar,20);
                    param.Value = ReceivingReport.CVNum;

                    param = cmd.Parameters.Add("@SupplierName", SqlDbType.VarChar);
                    param.Value = ReceivingReport.SupplierName;

                    param = cmd.Parameters.Add("@TotalCost", SqlDbType.Decimal);
                    param.Scale = 8;
                    param.Precision = 18;
                    param.Value = ReceivingReport.TotalCost;

                    param = cmd.Parameters.Add("@TotalCostPer", SqlDbType.Decimal);
                    param.Scale = 8;
                    param.Precision = 18;
                    param.Value = ReceivingReport.TotalCostPer;

                    param = cmd.Parameters.Add("@Terms", SqlDbType.VarChar, 200);
                    param.Value = ReceivingReport.Terms;

                    param = cmd.Parameters.Add("@DeliveryPeriod", SqlDbType.VarChar, 200);
                    param.Value = ReceivingReport.DeliveryPeriod;
                    
                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar,50);
                    param.Value = ReceivingReport.DeliveryStatus;
                    
                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewRRNum = Convert.ToString(cmd.Parameters["@RRNum"].Value.ToString());
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<ReceivingReport> GetReceivingReportList(String Param, String Flag)
        {
            List<ReceivingReport> ReceivingReportList = new List<ReceivingReport>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetReceivingReport";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ReceivingReportList.Add(new ReceivingReport()
                                {
                                    PurchaseOrderNum = Convert.ToString(dr["PurchaseOrderNum"].ToString())
                                    ,
                                    RRNum = Convert.ToString(dr["RRNum"].ToString())
                                    ,
                                    DateProcess = Convert.ToDateTime(dr["DateProcess"].ToString())
                                    ,
                                    DeliveryStatus = Convert.ToString(dr["DeliveryStatus"].ToString())
                                    ,
                                    RIVNum = Convert.ToString(dr["RIVNum"].ToString())                                    
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    SupplierName = Convert.ToString(dr["SupplierName"].ToString())
                                   ,
                                    TotalCost = Convert.ToDecimal(dr["TotalCost"].ToString())
                                    ,
                                    Status = Convert.ToString(dr["Status"].ToString())
                                    ,
                                    DeptCode = Convert.ToString(dr["DeptCode"].ToString())
                                      ,
                                    DRNum = Convert.ToString(dr["DRNum"].ToString())
                                      ,
                                    InvoiceNum = Convert.ToString(dr["InvoiceNum"].ToString())
                                          ,
                                    RRType = Convert.ToString(dr["RRType"].ToString())
                                });
                            }
                        }
                    }

                }
                return ReceivingReportList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<ReceivingReport> GetReceivingReportList_ByType(String Param, String Type, String Flag)
        {
            List<ReceivingReport> ReceivingReportList = new List<ReceivingReport>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetReceivingReport_ByType";
                    
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@RRType", SqlDbType.VarChar, 100);
                    param.Value = Type;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ReceivingReportList.Add(new ReceivingReport()
                                {
                                    PurchaseOrderNum = Convert.ToString(dr["PurchaseOrderNum"].ToString())
                                    ,
                                    RRNum = Convert.ToString(dr["RRNum"].ToString())
                                    ,
                                    DateProcess = Convert.ToDateTime(dr["DateProcess"].ToString())
                                    ,
                                    DeliveryStatus = Convert.ToString(dr["DeliveryStatus"].ToString())
                                    ,
                                    RIVNum = Convert.ToString(dr["RIVNum"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    SupplierName = Convert.ToString(dr["SupplierName"].ToString())
                                   ,
                                    TotalCost = Convert.ToDecimal(dr["TotalCost"].ToString())
                                    ,
                                    Status = Convert.ToString(dr["Status"].ToString())
                                    ,
                                    DeptCode = Convert.ToString(dr["DeptCode"].ToString())
                                      ,
                                    DRNum = Convert.ToString(dr["DRNum"].ToString())
                                      ,
                                    InvoiceNum = Convert.ToString(dr["InvoiceNum"].ToString())
                                          ,
                                    RRType = Convert.ToString(dr["RRType"].ToString())
                                });
                            }
                        }
                    }

                }
                return ReceivingReportList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CheckReceivingReportCheckedMark (String Month, string Year)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckReceivingReportCheckedMark";

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;
                
                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<ReceivingReport> GetReceivingReportPerPeriodList(String Month,String Year, String Flag)
        {
            List<ReceivingReport> ReceivingReportList = new List<ReceivingReport>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetReceivingReportPerPeriod";
                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = GlobalFunc.GetMonthNum(Month);
                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ReceivingReportList.Add(new ReceivingReport()
                                {
                                    PurchaseOrderNum = Convert.ToString(dr["PurchaseOrderNum"].ToString())
                                    ,
                                    RRNum = Convert.ToString(dr["RRNum"].ToString())
                                    ,
                                    DateProcess = Convert.ToDateTime(dr["DateProcess"].ToString())
                                    ,
                                    DeliveryStatus = Convert.ToString(dr["DeliveryStatus"].ToString())
                                    ,
                                    RIVNum = Convert.ToString(dr["RIVNum"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    SupplierName = Convert.ToString(dr["SupplierName"].ToString())
                                   ,
                                    TotalCost = Convert.ToDecimal(dr["TotalCost"].ToString())
                                    ,
                                    Status = Convert.ToString(dr["Status"].ToString())
                                    ,
                                    DeptCode = Convert.ToString(dr["DeptCode"].ToString())
                                      ,
                                    DRNum = Convert.ToString(dr["DRNum"].ToString())
                                      ,
                                    InvoiceNum = Convert.ToString(dr["InvoiceNum"].ToString())
                                        ,
                                    Checked = Convert.ToString(dr["Checked"].ToString())
                                });
                            }
                        }
                    }

                }
                return ReceivingReportList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<PurchaseOrderDetail> GetPurchaseOrderDetailList(String Param, String Flag)
        {
            List<PurchaseOrderDetail> PurchaseOrderDetailList = new List<PurchaseOrderDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetPurchaseOrderDetail";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                PurchaseOrderDetailList.Add(new PurchaseOrderDetail()
                                {

                                        DateProcess = Convert.ToDateTime(dr["DateProcess"].ToString())
                                        ,
                                    PurchaseOrderNum = Convert.ToString(dr["PurchaseOrderNum"].ToString())
                                        ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                        ,
                                    RIVNum = Convert.ToString(dr["RIVNum"].ToString())
                                        ,
                                    RIVDate = Convert.ToDateTime(dr["RIVDate"].ToString())
                                        ,
                                    CanvassSheetNum = Convert.ToString(dr["CanvassSheetNum"].ToString())
                                        ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                        ,
                                    WONo = Convert.ToString(dr["wONo"].ToString())
                                        ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                        ,
                                    DeptCode = Convert.ToString(dr["DeptCode"].ToString())
                                        ,
                                    Requestor = Convert.ToString(dr["Requestor"].ToString())
                                        ,
                                    Vatable = Convert.ToString(dr["Vatable"].ToString())
                                        ,
                                    Vat = Convert.ToDecimal(dr["Vat"].ToString())
                                        ,
                                    Terms = Convert.ToString(dr["Terms"].ToString())
                                        ,
                                    DeliveryPeriod = Convert.ToString(dr["DeliveryPeriod"].ToString())
                                        ,
                                    SupplierName = Convert.ToString(dr["SupplierName"].ToString())

                                        ,
                                    //CanvassMatrixNum = Convert.ToInt32(dr["CanvassMatrixNum"].ToString())
                                    //    ,
                                    SupplierNo = Convert.ToInt32(dr["SupplierNo"].ToString())
                                        ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                        ,
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                        ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                        ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Unit"].ToString())
                                        ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    UnitCost = Convert.ToDecimal(dr["UnitCost"].ToString())
                                        ,
                                    TotalCost = Convert.ToDecimal(dr["TotalCost"].ToString())

                                    ,Purpose = Convert.ToString(dr["Purpose"].ToString())
                                      ,
                                    Units = Convert.ToString(dr["Units"].ToString())
                                       ,
                                    RIVDetailNum = Convert.ToInt32(dr["RIVDetailNum"].ToString())
                                });
                            }
                        }
                    }

                }
                return PurchaseOrderDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CancelReceivingReport(String PurchaseOrderNum, String ReferenceNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CancelReceivingReport";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrderNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String DeletePurchaseOrder(String PurchaseOrderNum,String RIVNum, String Status,String Remarks, String Notes)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_DeletePurchaseOrder";

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrderNum;

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = RIVNum;

                    param = cmd.Parameters.Add("@RIVStatus", SqlDbType.VarChar, 50);
                    param.Value = Status;

                    param = cmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 200);
                    param.Value = Remarks;

                    param = cmd.Parameters.Add("@Notes", SqlDbType.VarChar, 200);
                    param.Value = Notes;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String SavePurchaseOrderStatus(String PurchaseOrderNum, String RIVNum, String Status, String Remarks, String Notes)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SavePurchaseOrderStatus";

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrderNum;

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = RIVNum;

                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar, 50);
                    param.Value = Status;

                    param = cmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 200);
                    param.Value = Remarks;

                    param = cmd.Parameters.Add("@Notes", SqlDbType.VarChar, 200);
                    param.Value = Notes;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String GetPurchaseOrderCurrentStatus(String PurchaseOrderNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetPurchaseOrderCurrentStatus";

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrderNum;

                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Status"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemoveReceivingReportItem(String ProductCode, String ReferenceNum, String PurchaseOrderNum, String RIVNum, Int64 RIVDetailNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_RemoveReceivingReportItem";

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = ProductCode;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrderNum;

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = RIVNum;

                    param = cmd.Parameters.Add("@RIVDetailNum", SqlDbType.Int);
                    param.Value = RIVDetailNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<PurchaseOrderPrintType> GetPurchaseOrderPrintTypeList(String Param, String Flag)
        {
            try
            {
                List<PurchaseOrderPrintType> PurchaseOrderPrintTypeList = new List<PurchaseOrderPrintType>();
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetPurchaseOrderPrintType";

                    param = cmd.Parameters.Add("@param", SqlDbType.VarChar, 20);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                PurchaseOrderPrintTypeList.Add(new PurchaseOrderPrintType()
                                {
                                    PurchaseOrderPrintTypeNum = Convert.ToInt32(dr["PurchaseOrderPrintTypeNum"].ToString())
                                    ,
                                    PrintType = Convert.ToString(dr["PrintType"].ToString())
                                    ,Selected = Convert.ToString(dr["Selected"].ToString())
                                });
                            }
                        }
                    }
                    return PurchaseOrderPrintTypeList;
                }
            }
            catch (Exception)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String ChangePurchaseOrderPrintTypeSelected(String PrintType, String Selected)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_ChangePurchaseOrderPrintTypeSelected";

                    param = cmd.Parameters.Add("@PrintType", SqlDbType.VarChar,50);
                    param.Value = PrintType;

                    param = cmd.Parameters.Add("@Selected", SqlDbType.VarChar,1);
                    param.Value = Selected;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String AddPurchaseOrderItem(String ReferenceNumber,String PurchaseOrderNum,Int32 RIVDetailNum,String CanvassSheetNum, String SupplierName)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_AddPurchaseOrderItem";

                    param = cmd.Parameters.Add("@ReferenceNumber", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNumber.Trim();

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrderNum.Trim();

                    param = cmd.Parameters.Add("@RIVDetailNum", SqlDbType.Int);
                    param.Value = RIVDetailNum;

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheetNum.Trim();

                    param = cmd.Parameters.Add("@SupplierName", SqlDbType.VarChar, 500);
                    param.Value = SupplierName.Trim();

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();

                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String ReAlignRRItem(String PurchaseOrderNum, Int32 RIVDetailNum, Int32 ProductCode, String ItemCode, String ProductName, String ProductDesc
          , Int32 OldProductCode, String OldItemCode, String OldProductName, String OldProductDesc, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_ReAlignRRItem";

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrderNum;

                    param = cmd.Parameters.Add("@RIVDetailNum", SqlDbType.Int);
                    param.Value = RIVDetailNum;

                    param = cmd.Parameters.Add("@OldProductCode", SqlDbType.Int);
                    param.Value = OldProductCode;

                    param = cmd.Parameters.Add("@OldItemCode", SqlDbType.VarChar);
                    param.Value = OldItemCode;

                    param = cmd.Parameters.Add("@OldProductName", SqlDbType.VarChar);
                    param.Value = OldProductName;

                    param = cmd.Parameters.Add("@OldProductDesc", SqlDbType.VarChar);
                    param.Value = OldProductDesc;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar);
                    param.Value = ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar);
                    param.Value = ProductDesc;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public string CheckRRQuantityinTemp(String ReferenceNum, String PurchaseOrderNum, String RRNum, Int32 RIVDetailNum,String ItemType, Int32 ProductCode
                       , String ItemCode, String ProductName, String ProductDesc, Decimal Quantity, String Unit, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckRRQuantity_Temp";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrderNum;

                    param = cmd.Parameters.Add("@RRNum", SqlDbType.VarChar, 20);
                    param.Value = RRNum;

                    param = cmd.Parameters.Add("@RIVDetailNum", SqlDbType.Int);
                    param.Value = RIVDetailNum;

                    param = cmd.Parameters.Add("@ItemType", SqlDbType.VarChar, 20);
                    param.Value = ItemType;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar);
                    param.Value = ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar);
                    param.Value = ProductDesc;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = Quantity;

                    param = cmd.Parameters.Add("@Unit", SqlDbType.VarChar);
                    param.Value = Unit;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String AddReceivingReportItem(String ReferenceNum, String RRNum, String PurchaseOrderNum, String RIVNum,Int32 RIVDetailNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_AddReceivingReportItem";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@RRNum", SqlDbType.VarChar, 20);
                    param.Value = RRNum;

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrderNum;

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = RIVNum;

                    param = cmd.Parameters.Add("@RIVDetailNum", SqlDbType.Int);
                    param.Value = RIVDetailNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<ReceivingReportDetail> GetReceivingReportDetailList_Temp(String Param, String Flag)
        {
            List<ReceivingReportDetail> ReceivingReportDetailList = new List<ReceivingReportDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetReceivingReportDetail_Temp";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ReceivingReportDetailList.Add(new ReceivingReportDetail()
                                {
                                    SupplierNo = Convert.ToInt32(dr["SupplierNo"].ToString())
                                    ,

                                    RRNum = Convert.ToString(dr["RRNum"].ToString())
                                    ,
                                    PurchaseOrderNum = Convert.ToString(dr["PurchaseOrderNum"].ToString())
                                    ,
                                    RIVNum = Convert.ToString(dr["RIVNum"].ToString())
                                    ,
                                    RIVDetailNum = Convert.ToInt32(dr["RIVDetailNum"].ToString())
                                    ,

                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Unit"].ToString())
                                    ,UnitCost = Convert.ToDecimal(dr["UnitCost"].ToString())
                                    ,TotalCost = Convert.ToDecimal(dr["TotalCost"].ToString())
                                    ,
                                    UnitCostPer = Convert.ToDecimal(dr["UnitCostPer"].ToString())
                                    ,
                                    TotalCostPer = Convert.ToDecimal(dr["TotalCostPer"].ToString())
                                                 ,
                                    Vat = Convert.ToDecimal(dr["VAT"].ToString())
                                });
                            }
                        }
                    }

                }
                return ReceivingReportDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String SetRRCheckedStatus(String Action, String RRNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SetRRCheckedStatus";

                    param = cmd.Parameters.Add("@Action", SqlDbType.VarChar, 20);
                    param.Value = Action;

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 20);
                    param.Value = RRNum;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = "Status";
                  
                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<ReceivingReportDetail> GetReceivingReportDetailList(String Param, String Flag)
        {
            List<ReceivingReportDetail> ReceivingReportDetailList = new List<ReceivingReportDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetReceivingReportDetail";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ReceivingReportDetailList.Add(new ReceivingReportDetail()
                                {
                                   

                                    RRNum = Convert.ToString(dr["RRNum"].ToString())
                                    ,
                                    PurchaseOrderNum = Convert.ToString(dr["PurchaseOrderNum"].ToString())
                                    ,
                                    RIVNum = Convert.ToString(dr["RIVNum"].ToString())
                                    ,
                                   
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Unit"].ToString())
                                    ,
                                    UnitCost = Convert.ToDecimal(dr["UnitCost"].ToString())
                                    ,
                                    TotalCost = Convert.ToDecimal(dr["TotalCost"].ToString())
                                    ,
                                    UnitCostPer = Convert.ToDecimal(dr["UnitCostPer"].ToString())
                                    ,
                                    TotalCostPer = Convert.ToDecimal(dr["TotalCostPer"].ToString())
                                             ,
                                    Vat = Convert.ToDecimal(dr["VAT"].ToString())
                                           ,
                                    GrandTotal = Convert.ToDecimal(dr["GrandTotal"].ToString())
                                    ,
                                    GrandTotalPer = Convert.ToDecimal(dr["GrandTotalPer"].ToString())
                                });
                            }
                        }
                    }

                }
                return ReceivingReportDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String GetReceivingReportPosting_IntoTemp(String Month, String Year,DateTime DateFrom, DateTime DateTo,String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetReceivingReportPosting_IntoTemp";

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar,2);
                    param.Value = GlobalFunc.GetMonthNum(Month);

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar,4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@DateFrom", SqlDbType.DateTime);
                    param.Value = DateFrom;

                    param = cmd.Parameters.Add("@DateTo", SqlDbType.DateTime);
                    param.Value = DateTo;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<RRPosting> GetReceivingReportPosting_FromTemp(String Month, String Year,String Flag)
        {
            List<RRPosting> RRPostingDetailList = new List<RRPosting>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetReceivingReportPosting_FromTemp";
                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = GlobalFunc.GetMonthNum(Month);

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                RRPostingDetailList.Add(new RRPosting()
                                {
                                    PriceID = Convert.ToInt32(dr["PriceID"].ToString())
                                    ,

                                    Month = Convert.ToString(dr["Month"].ToString())
                                    ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                    ,
                                  
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                    ,

                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["ReceivedQuantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Unit"].ToString())
                                    ,
                                    UnitPrice = Convert.ToDecimal(dr["UnitPrice"].ToString())
                                   
                                });
                            }
                        }
                    }

                }
                return RRPostingDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String SaveReceivingReportPosting(String Month, String Year,DateTime DateFrom, DateTime DateTo, String ReferenceNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveReceivingReportPosting";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = GlobalFunc.GetMonthNum(Month);

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@DateFrom", SqlDbType.DateTime);
                    param.Value = DateFrom;

                    param = cmd.Parameters.Add("@DateTo", SqlDbType.DateTime);
                    param.Value = DateTo;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<RRPosting> GetReceivingReportPostingSummary(String Month, String Year, String Flag)
        {
            List<RRPosting> RRPostingDetailList = new List<RRPosting>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetReceivingReportPosting";
                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                RRPostingDetailList.Add(new RRPosting()
                                {
                                  

                                    Month = Convert.ToString(dr["Month"].ToString())
                                    ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                   

                                });
                            }
                        }
                    }

                }
                return RRPostingDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
                                                                             
        public List<RRPosting> GetReceivingReportPosting(String Month, String Year, String Flag)
        {
            List<RRPosting> RRPostingDetailList = new List<RRPosting>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetReceivingReportPosting";
                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                RRPostingDetailList.Add(new RRPosting()
                                {

                                    PriceID= Convert.ToInt32(dr["PriceID"].ToString())
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                    ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                    ,
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                    ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                    ,
                                    Unit = Convert.ToString(dr["Unit"].ToString())
                                    ,
                                    UnitPrice = Convert.ToDecimal(dr["UnitPrice"].ToString())


                                });
                            }
                        }
                    }

                }
                return RRPostingDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String EditRRPosting(String Month, String Year)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_EditRRPosting";

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CancelRRPosting(String Month, String Year)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CancelRRPosting";

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateRRPostingItem(String Month, String Year,Int32 ProductCode, String ItemCode, Decimal UnitPrice)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateRRPostingItem_InTemp";

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar,50);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@UnitPrice", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = UnitPrice;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateRRPosting(String Month, String Year)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateReceivingReportPosting";

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CheckReceivingReportPosting_Validity(String Month, String Year, String TransType)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckReceivingReportPosting";

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@TransType", SqlDbType.VarChar, 10);
                    param.Value = TransType;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CheckTransMonthValidityRRClosing (DateTime TransDate)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckTransMonthValidityRRClosing";

                    param = cmd.Parameters.Add("@TransDate", SqlDbType.DateTime);
                    param.Value = TransDate;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CheckReceivingReportItemInNEATable(Int32 ProductCode, String ItemCode, String ProductName)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckReceivingReportItemInNEATable";

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar,50);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 1000);
                    param.Value = ProductName;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 200);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String CheckReceivingReportItemHasDetail(String ReferenceNum, Int32 ProductCode, String ItemCode, String ProductName, Decimal Quantity)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckReceivingReportItemHasDetail";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 1000);
                    param.Value = ProductName;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = Quantity;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 200);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<ProductView> GetRRItemThatHasDetail(String ReferenceNum, String Flag)
        {
            List<ProductView> ProductViewList = new List<ProductView>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetReceivingReportItemThatHasDetail";
                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ProductViewList.Add(new ProductView()
                                {
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                    ,
                                    ItemCode = String.IsNullOrEmpty(dr["ItemCode"].ToString()) ? "" : dr["ItemCode"].ToString()
                                    ,
                                  
                                    ProductName = String.IsNullOrEmpty(dr["ProductName"].ToString()) ? "" : dr["ProductName"].ToString()
                                      ,

                                    Unit = String.IsNullOrEmpty(dr["Unit"].ToString()) ? "" : dr["Unit"].ToString()
                                       ,

                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                });
                            }
                        }
                    }

                }
                return ProductViewList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<ReceivingReport> GetRRPostingReportPerPeriodList(String Month, String Year, String RRType, String Flag, String Param)
        {
            List<ReceivingReport> ReceivingReportList = new List<ReceivingReport>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetRRPerPeriod";

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = GlobalFunc.GetMonthNum(Month);

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@RRType", SqlDbType.VarChar, 100);
                    param.Value = RRType;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 50);
                    param.Value = Param;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ReceivingReportList.Add(new ReceivingReport()
                                {
                                    RRNum = Convert.ToString(dr["RRNum"].ToString())
                                    ,
                                    DateProcess = Convert.ToDateTime(dr["DateProcess"].ToString())

                                    ,
                                    
                                    DeptCode = ""
                                     ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                       ,
                                    UserAccount = String.IsNullOrEmpty(dr["AccountUse"].ToString()) ? "" : dr["AccountUse"].ToString()
                                    ,
                                    RRType = String.IsNullOrEmpty(dr["RRType"].ToString()) ? "" : dr["RRType"].ToString()
                                    ,
                                    BranchName = ""
                                    ,
                                    TotalCost = Convert.ToDecimal(dr["TotalCost"].ToString())
                                    ,
                                    Checked = ""
                                    ,
                                     Month = String.IsNullOrEmpty(dr["Month"].ToString()) ? "" : dr["Month"].ToString()
                                       ,
                                    Year = String.IsNullOrEmpty(dr["Year"].ToString()) ? "" : dr["Year"].ToString()
                                       
                                });
                            }
                        }
                    }


                }
                return ReceivingReportList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<ReceivingReportDetail> GetRRDetailListPerPeriod(String Param, String Month, String Year, String Flag)
        {
            List<ReceivingReportDetail> ReceivingReportDetailList = new List<ReceivingReportDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetRRDetailPerPeriod";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = GlobalFunc.GetMonthNum(Month);

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ReceivingReportDetailList.Add(new ReceivingReportDetail()
                                {
                                    DateProcess = Convert.ToDateTime(dr["DateProcess"].ToString())
                                    ,
                                    RRNum = Convert.ToString(dr["RRNum"].ToString())
                                    ,
                                    RRDetailNum = Convert.ToInt32(dr["RRDetailNum"].ToString())
                                    ,
                                    //AcctCode = Convert.ToString(dr["AcctCode"].ToString())
                                    //,
                                    //AcctDesc = Convert.ToString(dr["AcctDesc"].ToString())
                                    //,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                   
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                      ,

                                    
                                    
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,
                                    UnitCost = Convert.ToDecimal(dr["UnitCost"].ToString())

                                });
                            }
                        }
                    }

                }
                return ReceivingReportDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }

        }

    }
}
