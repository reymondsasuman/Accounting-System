﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using anecoacct.WareHouseModel;
using System.Data.SqlClient;
using System.Windows.Forms;
using anecoacct.WareHouseClass;

namespace anecoacct.WareHouseClass
{
    class JORQueries
    {
  
        OtherQueries OtherQueries = new OtherQueries();
        frmWareHouseJOR frmWareHouseJOR = (frmWareHouseJOR)Application.OpenForms["frmWareHouseJOR"];


        public List<JORDetail> GetJobOrderDescList(String Param, String Flag)
        {
            List<JORDetail> JORViewList = new List<JORDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetJORProduct";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                JORViewList.Add(new JORDetail()
                                {
                                    JobOrderDesc = Convert.ToString(dr["JobOrderDesc"].ToString())
                                    
                                });
                            }
                        }
                    }

                }
                return JORViewList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String EditJOR (String ReferenceNum, String JORNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                { 
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_EditJOR";

                    param = cmd.Parameters.Add("@JORNum", SqlDbType.VarChar, 20);
                    param.Value = JORNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String SaveJORStatus(String JORNum,String Status, String Remarks, String Notes )
        {
            try
            {
                //save RIV Status
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveJORStatus";

                    param = cmd.Parameters.Add("@JORNum", SqlDbType.VarChar, 20);
                    param.Value = JORNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@JORStatus", SqlDbType.VarChar, 50);
                    param.Value = Status;

                    param = cmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 200);
                    param.Value = Remarks;

                    param = cmd.Parameters.Add("@Notes", SqlDbType.VarChar, 200);
                    param.Value = Notes;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }  

        public String SaveJOR(JOR JOR)
        {
            try
            {
                //save RIV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveJOR";

                    param = cmd.Parameters.Add("@JORNum", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = JOR.ReferenceNum;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 20);
                    param.Value = JOR.DeptCode;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = JOR.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = JOR.Year;

                    param = cmd.Parameters.Add("@EmpID", SqlDbType.VarChar, 30);
                    param.Value = JOR.EmpID;

                    param = cmd.Parameters.Add("@EmpType", SqlDbType.VarChar, 50);
                    param.Value = JOR.EmpType;

                    param = cmd.Parameters.Add("@CheckedByID", SqlDbType.VarChar, 30);
                    param.Value = JOR.CheckedByID;

                    param = cmd.Parameters.Add("@WONo", SqlDbType.VarChar, 20);
                    param.Value = JOR.WONo;

                    param = cmd.Parameters.Add("@JONo", SqlDbType.VarChar, 20);
                    param.Value = JOR.JONo;

                    param = cmd.Parameters.Add("@JORDate", SqlDbType.DateTime);
                    param.Value = JOR.JORDate;

                    param = cmd.Parameters.Add("@AwardedTo", SqlDbType.VarChar, 100);
                    param.Value = JOR.AwardedTo;

                    param = cmd.Parameters.Add("@SourceOfFund", SqlDbType.VarChar, 50);
                    param.Value = JOR.SourceOfFund;

                    param = cmd.Parameters.Add("@BiddingRefNum", SqlDbType.VarChar, 50);
                    param.Value = JOR.BiddingRefNum;

                    param = cmd.Parameters.Add("@JOType", SqlDbType.VarChar, 2);
                    param.Value = JOR.JOType;

                    param = cmd.Parameters.Add("@JobLocation", SqlDbType.VarChar, 500);
                    param.Value = JOR.JobLocation;

                    param = cmd.Parameters.Add("@PoleNum", SqlDbType.VarChar, 50);
                    param.Value = JOR.PoleNum;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar,1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewJORNum = Convert.ToString(cmd.Parameters["@JORNum"].Value.ToString());
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String SaveJOR_v2(JOR JOR)
        {
            try
            {
                //save RIV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveJOR";

                    param = cmd.Parameters.Add("@JORNum", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = JOR.ReferenceNum;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 20);
                    param.Value = JOR.DeptCode;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = JOR.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = JOR.Year;

                    param = cmd.Parameters.Add("@EmpID", SqlDbType.VarChar, 30);
                    param.Value = JOR.EmpID;

                    param = cmd.Parameters.Add("@EmpType", SqlDbType.VarChar, 50);
                    param.Value = JOR.EmpType;

                    param = cmd.Parameters.Add("@WONo", SqlDbType.VarChar, 20);
                    param.Value = JOR.WONo;

                    param = cmd.Parameters.Add("@JONo", SqlDbType.VarChar, 20);
                    param.Value = JOR.JONo;


                    param = cmd.Parameters.Add("@JORDate", SqlDbType.DateTime);
                    param.Value = JOR.JORDate;

                    param = cmd.Parameters.Add("@AwardedTo", SqlDbType.VarChar, 100);
                    param.Value = JOR.AwardedTo;

                    param = cmd.Parameters.Add("@SourceOfFund", SqlDbType.VarChar, 50);
                    param.Value = JOR.SourceOfFund;

                    param = cmd.Parameters.Add("@BiddingRefNum", SqlDbType.VarChar, 50);
                    param.Value = JOR.BiddingRefNum;

                    param = cmd.Parameters.Add("@ForWareHouse", SqlDbType.VarChar, 1);
                    param.Value = JOR.ForWareHouse;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewJORNum = Convert.ToString(cmd.Parameters["@JORNum"].Value.ToString());
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateJOR(JOR JOR)
        {
            try
            {
                //save RIV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateJOR";

                    param = cmd.Parameters.Add("@JORNum", SqlDbType.VarChar, 20);
                    param.Value = JOR.JORNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = JOR.ReferenceNum;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 20);
                    param.Value = JOR.DeptCode;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = JOR.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = JOR.Year;

                    param = cmd.Parameters.Add("@EmpID", SqlDbType.VarChar, 30);
                    param.Value = JOR.EmpID;

                    param = cmd.Parameters.Add("@EmpType", SqlDbType.VarChar, 50);
                    param.Value = JOR.EmpType;


                    param = cmd.Parameters.Add("@CheckedByID", SqlDbType.VarChar, 30);
                    param.Value = JOR.CheckedByID;

                    param = cmd.Parameters.Add("@WONo", SqlDbType.VarChar, 20);
                    param.Value = JOR.WONo;

                    param = cmd.Parameters.Add("@JONo", SqlDbType.VarChar, 20);
                    param.Value = JOR.JONo;

                    param = cmd.Parameters.Add("@JORDate", SqlDbType.DateTime);
                    param.Value = JOR.JORDate;

                    param = cmd.Parameters.Add("@AwardedTo", SqlDbType.VarChar, 100);
                    param.Value = JOR.AwardedTo;

                    param = cmd.Parameters.Add("@SourceOfFund", SqlDbType.VarChar, 50);
                    param.Value = JOR.SourceOfFund;

                    param = cmd.Parameters.Add("@BiddingRefNum", SqlDbType.VarChar, 50);
                    param.Value = JOR.BiddingRefNum;

                    param = cmd.Parameters.Add("@JOType", SqlDbType.VarChar, 2);
                    param.Value = JOR.JOType;

                    param = cmd.Parameters.Add("@JobLocation", SqlDbType.VarChar, 500);
                    param.Value = JOR.JobLocation;

                    param = cmd.Parameters.Add("@PoleNum", SqlDbType.VarChar, 50);
                    param.Value = JOR.PoleNum;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<JOR> GetJORList(String Param, String Flag)
        {
            List<JOR> JORList = new List<JOR>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetJOR";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                JORList.Add(new JOR()
                                {
                                    JORNum = Convert.ToString(dr["JORNum"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())
                                      ,
                                   
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    BranchName = Convert.ToString(dr["BranchName"].ToString())
                                      ,
                                    JORDate = Convert.ToDateTime(dr["JORDate"].ToString())
                                      ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    ,
                                    JORStatus = Convert.ToString(dr["JORStatus"].ToString())
                                        ,
                                    UserAccount = Convert.ToString(dr["AccountUse"].ToString())
                                     ,
                                    JOType = Convert.ToString(dr["JOType"].ToString())
                                    ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                });
                            }
                        }
                    }

                }
                return JORList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<JOR> GetJORList_v2(String Param, String Flag, String ForWareHouse)
        {
            List<JOR> JORList = new List<JOR>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetJOR_v2";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    param = cmd.Parameters.Add("@ForWareHouse", SqlDbType.VarChar, 50);
                    param.Value = ForWareHouse;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                JORList.Add(new JOR()
                                {
                                    JORNum = Convert.ToString(dr["JORNum"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    //Purpose = Convert.ToString(dr["Purpose"].ToString())
                                    //  ,
                                    JORDate = Convert.ToDateTime(dr["JORDate"].ToString())
                                      ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    ,
                                    JORStatus = Convert.ToString(dr["JORStatus"].ToString())
                                        ,
                                    UserAccount = Convert.ToString(dr["AccountUse"].ToString())
                                });
                            }
                        }
                    }

                }
                return JORList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<JOR> GetJORList_ByStatus(String Status,String Param, String Flag)
        {
            List<JOR> JORList = new List<JOR>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetJOR_ByStatus";
                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar, 100);
                    param.Value = Status;
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                JORList.Add(new JOR()
                                {
                                    JORNum = Convert.ToString(dr["JORNum"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    //Purpose = Convert.ToString(dr["Purpose"].ToString())
                                    //  ,
                                    JORDate = Convert.ToDateTime(dr["JORDate"].ToString())
                                      ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    ,
                                    JORStatus = Convert.ToString(dr["JORStatus"].ToString())
                                        ,
                                    UserAccount = Convert.ToString(dr["AccountUse"].ToString())
                                });
                            }
                        }
                    }

                }
                return JORList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<JOR> GetJORList_ByStatus_v2(String Status, String Param, String Flag, String ForWareHouse)
        {
            List<JOR> JORList = new List<JOR>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetJOR_ByStatus";
                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar, 100);
                    param.Value = Status;
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    param = cmd.Parameters.Add("@ForWareHouse", SqlDbType.VarChar, 1);
                    param.Value = ForWareHouse;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                JORList.Add(new JOR()
                                {
                                    JORNum = Convert.ToString(dr["JORNum"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    //Purpose = Convert.ToString(dr["Purpose"].ToString())
                                    //  ,
                                    JORDate = Convert.ToDateTime(dr["JORDate"].ToString())
                                      ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    ,
                                    JORStatus = Convert.ToString(dr["JORStatus"].ToString())
                                        ,
                                    UserAccount = Convert.ToString(dr["AccountUse"].ToString())
                                });
                            }
                        }
                    }

                }
                return JORList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<JORDetail> GetJORDetailList(String Param, String Flag)
        {
            List<JORDetail> JORDetailList = new List<JORDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetJORDetail";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                JORDetailList.Add(new JORDetail()
                                {
                                    JORNum = Convert.ToString(dr["JORNum"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                      ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                       ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                       ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                    ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                     ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                     ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                      ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                      ,
                                    JORDate = Convert.ToDateTime(dr["JORDate"].ToString())
                                      ,
                                   
                                    SourceOfFund = Convert.ToString(dr["SourceOfFund"].ToString())
                                    ,
                                    BiddingRefNum = Convert.ToString(dr["BiddingRefNum"].ToString())
                                    ,
                                   
                                    JORStatus = Convert.ToString(dr["JORStatus"].ToString())                                                                           
                                       ,
                                    JobOrderDesc = Convert.ToString(dr["JobOrderDesc"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,
                                    UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                        ,
                                    JORDetailNum = Convert.ToInt32(dr["JORDetailNum"].ToString())
                                       ,
                                    Available = Convert.ToString(dr["Available"].ToString())
                                       ,

                                    SubClassID = Convert.ToInt32(dr["SubClassID"].ToString())
                                    ,
                                    ProjectType = Convert.ToString(dr["ProjectType"].ToString())
                                                                        ,
                                    ProjectClass = Convert.ToString(dr["ProjectClass"].ToString())
                                                                        ,
                                    SubClass = Convert.ToString(dr["SubClass"].ToString())
                                                                        ,
                                    SubClassDesc = Convert.ToString(dr["SubClassDesc"].ToString())
                                     ,
                                    JOType = Convert.ToString(dr["JOType"].ToString())
                                    ,
                                    JobLocation = Convert.ToString(dr["JobLocation"].ToString())
                                        ,
                                    PoleNum = Convert.ToString(dr["PoleNum"].ToString())
                                       ,
                                    Scope = Convert.ToString(dr["Scope"].ToString())
                                       ,
                                    CheckedByID = Convert.ToString(dr["CheckedByID"].ToString())
                                       ,
                                    CheckedByName = Convert.ToString(dr["CheckedByName"].ToString())
                                });
                            }
                        }
                    }

                }
                return JORDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<JORDetail> GetJORDetailList_v2(String Param, String Flag, String ForWareHouse)
        {
            List<JORDetail> JORDetailList = new List<JORDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetJORDetail_v2";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    param = cmd.Parameters.Add("@ForWarehouse", SqlDbType.VarChar, 1);
                    param.Value = ForWareHouse;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                JORDetailList.Add(new JORDetail()
                                {
                                    JORNum = Convert.ToString(dr["JORNum"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    //,
                                   // Month = Convert.ToString(dr["Month"].ToString())
                                   //  ,
                                   // Year = Convert.ToString(dr["Year"].ToString())
                                   //   ,
                                   // Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                   //   ,
                                   // EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   //,
                                   // EmpType = Convert.ToString(dr["EmpType"].ToString())
                                   // ,
                                   // WONo = Convert.ToString(dr["WONo"].ToString())
                                   // ,
                                   // JONo = Convert.ToString(dr["JONo"].ToString())
                                   //  ,
                                   // Purpose = Convert.ToString(dr["Purpose"].ToString())
                                   //   ,
                                   // RIVDate = Convert.ToDateTime(dr["RIVDate"].ToString())
                                   //   ,
                                   // AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                   // ,
                                   // SourceOfFund = Convert.ToString(dr["SourceOfFund"].ToString())
                                   // ,
                                   // BiddingRefNum = Convert.ToString(dr["BiddingRefNum"].ToString())
                                   // ,
                                   // IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                   // ,
                                   // RIVStatus = Convert.ToString(dr["RIVStatus"].ToString())
                                   //      ,
                                   // ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                   // ,
                                   // ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                   //      ,
                                   // ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                   //      ,
                                   // ProductName = Convert.ToString(dr["ProductName"].ToString())
                                   //      ,
                                   // Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                   //     ,
                                   // Unit = Convert.ToString(dr["Units"].ToString())
                                   //     ,
                                   // UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                   //     ,
                                   // RIVDetailNum = Convert.ToInt32(dr["RIVDetailNum"].ToString())
                                   //    ,
                                   // Available = Convert.ToString(dr["Available"].ToString())
                                   //    ,

                                   // SubClassID = Convert.ToInt32(dr["SubClassID"].ToString())
                                   // ,
                                   // ProjectType = Convert.ToString(dr["ProjectType"].ToString())
                                   //                                     ,
                                   // ProjectClass = Convert.ToString(dr["ProjectClass"].ToString())
                                   //                                     ,
                                   // SubClass = Convert.ToString(dr["SubClass"].ToString())
                                   //                                     ,
                                   // SubClassDesc = Convert.ToString(dr["SubClassDesc"].ToString())

                                });
                            }
                        }
                    }

                }
                return JORDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<JORDetail> GetJORDetailList_TempTable(String Param, String Flag)
        {
            List<JORDetail> JORDetailList = new List<JORDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetJORDetail_Temp";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                JORDetailList.Add(new JORDetail()
                                {
                                  
                                    JORNum = Convert.ToString(dr["JORNum"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    Scope = Convert.ToString(dr["Scope"].ToString())
                                       ,
                                    JobOrderDesc = Convert.ToString(dr["JobOrderDesc"].ToString())
                                       ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                       ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                       ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                       ,
                                    JORDetailNum = Convert.ToInt32(dr["JORDetailNum"].ToString())
                                       ,
                                    Available = Convert.ToString(dr["Available"].ToString())
                                    ,
                                    UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                    ,
                                    SubClassID = Convert.ToInt32(dr["SubClassID"].ToString())
                                    ,
                                    ProjectType = Convert.ToString(dr["ProjectType"].ToString())
                                                                        ,
                                    ProjectClass = Convert.ToString(dr["ProjectClass"].ToString())
                                                                        ,
                                    SubClass = Convert.ToString(dr["SubClass"].ToString())
                                                                        ,
                                    SubClassDesc = Convert.ToString(dr["SubClassDesc"].ToString())
                                });
                            }
                        }
                    }

                }
                return JORDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<JORCanvassSheetDetail> GetCanvassSheetDetailList(String Param, String Flag)
        {
            List<JORCanvassSheetDetail> JORCanvassSheetDetailList = new List<JORCanvassSheetDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetJORDetail";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                JORCanvassSheetDetailList.Add(new JORCanvassSheetDetail()
                                {
                                    JORNum = Convert.ToString(dr["JORNum"].ToString())
                                    ,
                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                      ,
                                    JORDate = Convert.ToDateTime(dr["JORDate"].ToString())
                                      ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    ,
                                    JORStatus = Convert.ToString(dr["JORStatus"].ToString())
                                         ,
                                    
                                    JobOrderDesc = Convert.ToString(dr["JobOrderDesc"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Unit"].ToString())
                                        ,
                                    JORDetailNum = Convert.ToInt32(dr["JORDetailNum"].ToString())
                                       ,
                                    Available = Convert.ToString(dr["Available"].ToString())
                                       ,
                                    BiddingRefNum = Convert.ToString(dr["BiddingRefNum"].ToString())
                                        ,
                                    Scope = Convert.ToString(dr["Scope"].ToString())
                                          ,
                                    BranchName = Convert.ToString(dr["BranchName"].ToString())
                                });
                            }
                        }
                    }

                }
                return JORCanvassSheetDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String AddJORItem(JORDetail JORDetail, String Flag)
        {
            try 
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_AddJORItem";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = JORDetail.ReferenceNum;

                    param = cmd.Parameters.Add("@JORNum", SqlDbType.VarChar, 20);
                    param.Value = JORDetail.JORNum;

                    param = cmd.Parameters.Add("@Scope", SqlDbType.VarChar, 1000);
                    param.Value = JORDetail.Scope;

                    param = cmd.Parameters.Add("@JobOrderDesc", SqlDbType.VarChar,1000);
                    param.Value = JORDetail.JobOrderDesc;

                    param = cmd.Parameters.Add("@UnitDesc", SqlDbType.VarChar, 20);
                    param.Value = JORDetail.Unit;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = JORDetail.Quantity;

                    param = cmd.Parameters.Add("@Purpose", SqlDbType.VarChar, 800);
                    param.Value = JORDetail.Purpose;

                    param = cmd.Parameters.Add("@Available", SqlDbType.VarChar, 1);
                    param.Value = String.IsNullOrEmpty(JORDetail.Available)? "": JORDetail.Available;

                    param = cmd.Parameters.Add("@IsReg", SqlDbType.VarChar, 1);
                    param.Value = "";

                    param = cmd.Parameters.Add("@SubClassID", SqlDbType.Int);
                    param.Value = JORDetail.SubClassID;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemoveJORItem(String JORDetailNum, String ReferenceNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_RemoveJORItem";

                    param = cmd.Parameters.Add("@JORDetailNum", SqlDbType.VarChar, 20);
                    param.Value = JORDetailNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;                

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String DeleteJOR(String JORNum, String JORStatus)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_DeleteJOR";

                    param = cmd.Parameters.Add("@JORNum", SqlDbType.VarChar, 20);
                    param.Value = JORNum;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                    
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String DeleteFullJOR(String JORNum, String JORStatus)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_DeleteFullJOR";

                    param = cmd.Parameters.Add("@JORNum", SqlDbType.VarChar, 20);
                    param.Value = JORNum;

                    param = cmd.Parameters.Add("@JORStatus", SqlDbType.VarChar, 50);
                    param.Value = JORStatus;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CancelJOR(String ReferenceNum, String JORNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CancelJOR";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@JORNum", SqlDbType.VarChar, 20);
                    param.Value = JORNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public void DeleteJORDetail(String JORNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_DeleteJORDetail";

                    param = cmd.Parameters.Add("@JORNum", SqlDbType.VarChar, 20);
                    param.Value = JORNum;

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                return;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<JORSourceOfFunds> GetJORSourceOfFundsList(String Param, String Flag)
        {
            List<JORSourceOfFunds> JORSourceOfFundsList = new List<JORSourceOfFunds>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetRIVSourceOfFunds";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                JORSourceOfFundsList.Add(new JORSourceOfFunds()
                                {
                                    ID = Convert.ToInt32(dr["FundID"].ToString())
                                    ,
                                    FundSource = String.IsNullOrEmpty(dr["FundSource"].ToString()) ? "" : dr["FundSource"].ToString()
                                   ,SetDefault= String.IsNullOrEmpty(dr["SetDefault"].ToString()) ? "" : dr["SetDefault"].ToString()
                                });
                            }
                        }
                    }

                }
                return JORSourceOfFundsList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateJORItem(JORDetail JORDetail)
        {
            try
            {
                //update RIV item in temp table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateJORItem";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = JORDetail.ReferenceNum;

                    param = cmd.Parameters.Add("@JORNum", SqlDbType.VarChar, 20);
                    param.Value = JORDetail.JORNum;

                    param = cmd.Parameters.Add("@JORDetailNum", SqlDbType.Int);
                    param.Value = JORDetail.JORDetailNum;

                    param = cmd.Parameters.Add("@Scope", SqlDbType.VarChar, 1000);
                    param.Value = JORDetail.Scope;

                    param = cmd.Parameters.Add("@JobOrderDesc", SqlDbType.VarChar, 1000);
                    param.Value = JORDetail.JobOrderDesc;

                    param = cmd.Parameters.Add("@Unit", SqlDbType.VarChar, 50);
                    param.Value = JORDetail.Unit;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = JORDetail.Quantity;

                    param = cmd.Parameters.Add("@Purpose", SqlDbType.VarChar, 800);
                    param.Value = JORDetail.Purpose;

                    param = cmd.Parameters.Add("@SubClassID", SqlDbType.Int);
                    param.Value = JORDetail.SubClassID;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String CheckJORStatus(String JORNum, String Action)
        {
            try
            {
                //save RIV Status
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckJORStatus";

                    param = cmd.Parameters.Add("@JORNum", SqlDbType.VarChar, 20);
                    param.Value = JORNum;

                    param = cmd.Parameters.Add("@Action", SqlDbType.VarChar, 50);
                    param.Value = Action;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CheckJOROwner(String JORNum, Int32 UserID)
        {
            try
            {
                //save RIV Status
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckJOROwner";

                    param = cmd.Parameters.Add("@JORNum", SqlDbType.VarChar, 20);
                    param.Value = JORNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 200);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<RIVClass> GetJORClassList(String Param,String DeptCode, String Flag)
        {
            List<RIVClass> RIVClassList = new List<RIVClass>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetRIVClass";

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 100);
                    param.Value = DeptCode;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                RIVClassList.Add(new RIVClass()
                                {
                                    SubClassID = Convert.ToInt32(dr["SubClassID"].ToString())
                                    ,
                                    ProjectType = String.IsNullOrEmpty(dr["ProjectType"].ToString()) ? "" : dr["ProjectType"].ToString()
                                    ,
                                    ProjectClass = String.IsNullOrEmpty(dr["ProjectClass"].ToString()) ? "" : dr["ProjectClass"].ToString()
                                    ,
                                    SubClass = String.IsNullOrEmpty(dr["SubClass"].ToString()) ? "" : dr["SubClass"].ToString()
                                     ,
                                    SubClassDesc = String.IsNullOrEmpty(dr["SubClassDesc"].ToString()) ? "" : dr["SubClassDesc"].ToString()

                                });
                            }
                        }
                    }

                }
                return RIVClassList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String GetJORCurrentStatus(String JORNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetJORCurrentStatus";

                    param = cmd.Parameters.Add("@JORNum", SqlDbType.VarChar, 20);
                    param.Value = JORNum;
     
                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar, 50);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Status"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String ImportRIV(String ReferenceNum, String RIVNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_ImportRIV";

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = RIVNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String CheckRIVCanvassAndPurchaseOrder( String RIVNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckRIVCanvassAndPurchaseOrder";

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = RIVNum;

                    param = cmd.Parameters.Add("@HasCanvass", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@HasPurchaseOrder", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.RIVHasCanvass = Convert.ToString(cmd.Parameters["@HasCanvass"].Value);
                    GlobalVariable.RIVHasPurchaseOrder = Convert.ToString(cmd.Parameters["@HasPurchaseOrder"].Value);
                    return "";
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateRIVItemDirectInMainTable(RIVDetail RIVDetail)
        {
            try
            {
                //update RIV item in temp table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateRIVItemDirectInMainTable";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = RIVDetail.RefNum;

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 30);
                    param.Value = RIVDetail.RIVNum;

                    param = cmd.Parameters.Add("@RIVDetailNum", SqlDbType.Int);
                    param.Value = RIVDetail.RIVDetailNum;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = RIVDetail.ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = RIVDetail.ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 1000);
                    param.Value = RIVDetail.ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar, 1000);
                    param.Value = RIVDetail.ProductDesc;

                    param = cmd.Parameters.Add("@Unit", SqlDbType.VarChar, 50);
                    param.Value = RIVDetail.Unit;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = RIVDetail.Quantity;

                    param = cmd.Parameters.Add("@Purpose", SqlDbType.VarChar, 800);
                    param.Value = RIVDetail.Purpose;

                    param = cmd.Parameters.Add("@SubClassID", SqlDbType.Int);
                    param.Value = RIVDetail.SubClassID;

                    param = cmd.Parameters.Add("@UpdateAllPurpose", SqlDbType.VarChar, 1);
                    param.Value = RIVDetail.UpdatePurposeAll;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String AddRIVItemDirectInMainTable(RIVDetail RIVDetail)
        {
            try
            {
                //update RIV item in temp table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_AddRIVItemDirectInMainTable";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = RIVDetail.RefNum;

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 30);
                    param.Value = RIVDetail.RIVNum;

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 30);
                    param.Value = RIVDetail.CanvassSheetNum;

                    param = cmd.Parameters.Add("@PONum", SqlDbType.VarChar, 30);
                    param.Value = RIVDetail.PONum;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = RIVDetail.ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = RIVDetail.ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 1000);
                    param.Value = RIVDetail.ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar, 1000);
                    param.Value = RIVDetail.ProductDesc;

                    param = cmd.Parameters.Add("@UnitDesc", SqlDbType.VarChar, 50);
                    param.Value = RIVDetail.Unit;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = RIVDetail.Quantity;

                    param = cmd.Parameters.Add("@Purpose", SqlDbType.VarChar, 800);
                    param.Value = RIVDetail.Purpose;

                    param = cmd.Parameters.Add("@Available", SqlDbType.VarChar, 1);
                    param.Value = String.IsNullOrEmpty(RIVDetail.Available) ? "" : RIVDetail.Available;

                    param = cmd.Parameters.Add("@IsReg", SqlDbType.VarChar, 1);
                    param.Value = RIVDetail.IsReg;

                    param = cmd.Parameters.Add("@SubClassID", SqlDbType.Int);
                    param.Value = RIVDetail.SubClassID;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String DeleteRIVItemDirectInMainTable(Int32 RIVDetailNum)
        {
            try
            {
                //update RIV item in temp table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_DeleteRIVItemDirectInMainTable";

                    param = cmd.Parameters.Add("@RIVDetailNum", SqlDbType.Int);
                    param.Value = RIVDetailNum;
 
                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
    }
}
