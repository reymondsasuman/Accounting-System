﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using anecoacct.WareHouseClass;
using anecoacct.WareHouseModel;
namespace anecoacct.WareHouseClass
{
    public static class WareHouseGlobalVar
    {
        
        public static Employee frmWareHouseEmpListSelected { get; set; }
    }
}
