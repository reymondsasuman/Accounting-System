﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using anecoacct.WareHouseModel;
using System.Data.SqlClient;
using System.Windows.Forms;
using anecoacct.WareHouseClass;

namespace anecoacct.WareHouseClass
{
    class MRVQueries
    {
        OtherQueries OtherQueries = new OtherQueries();
        frmWareHouseMRV frmWareHouseMRV = (frmWareHouseMRV)Application.OpenForms["frmWareHouseMRV"];

    


        public String EditMRV (String ReferenceNum, String MRVNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_EditMRV";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String SaveMRVStatus(String MRVNum,String Status, String Remarks, String Notes )
        {
            try
            {
                //save MRV Status
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveMRVStatus";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@MRVStatus", SqlDbType.VarChar, 50);
                    param.Value = Status;

                    param = cmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 200);
                    param.Value = Remarks;

                    param = cmd.Parameters.Add("@Notes", SqlDbType.VarChar, 200);
                    param.Value = Notes;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }  

        public String SaveMRV(MRV MRV)
        {
            try
            {
                //save MRV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveMRV";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MRV.RefNum;

                    param = cmd.Parameters.Add("@JobOrderNum", SqlDbType.VarChar, 20);
                    param.Value = MRV.JobOrderNum;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 20);
                    param.Value = MRV.DeptCode;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MRV.BranchName;

                    param = cmd.Parameters.Add("@GMLevel", SqlDbType.VarChar, 1);
                    param.Value = MRV.GMLevel;

                    param = cmd.Parameters.Add("@EmpID", SqlDbType.VarChar, 30);
                    param.Value = MRV.EmpID;

                    param = cmd.Parameters.Add("@EmpType", SqlDbType.VarChar, 50);
                    param.Value = MRV.EmpType;

                    param = cmd.Parameters.Add("@WONo", SqlDbType.VarChar, 20);
                    param.Value = MRV.WONo;

                    param = cmd.Parameters.Add("@JONo", SqlDbType.VarChar, 20);
                    param.Value = MRV.JONo;


                    param = cmd.Parameters.Add("@MRVDate", SqlDbType.DateTime);
                    param.Value = MRV.MRVDate;

                    param = cmd.Parameters.Add("@AwardedTo", SqlDbType.VarChar, 100);
                    param.Value = MRV.AwardedTo;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar,1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewMRVNum = Convert.ToString(cmd.Parameters["@MRVNum"].Value.ToString());
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateMRV(MRV MRV)
        {
            try
            {
                //save MRV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateMRV";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRV.MRVNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MRV.RefNum;

                    param = cmd.Parameters.Add("@JobOrderNum", SqlDbType.VarChar, 20);
                    param.Value = MRV.JobOrderNum;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 20);
                    param.Value = MRV.DeptCode;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MRV.BranchName;

                    param = cmd.Parameters.Add("@GMLevel", SqlDbType.VarChar, 1);
                    param.Value = MRV.GMLevel;

                    param = cmd.Parameters.Add("@EmpID", SqlDbType.VarChar, 30);
                    param.Value = MRV.EmpID;

                    param = cmd.Parameters.Add("@EmpType", SqlDbType.VarChar, 50);
                    param.Value = MRV.EmpType;

                    param = cmd.Parameters.Add("@WONo", SqlDbType.VarChar, 20);
                    param.Value = MRV.WONo;

                    param = cmd.Parameters.Add("@JONo", SqlDbType.VarChar, 20);
                    param.Value = MRV.JONo;


                    param = cmd.Parameters.Add("@MRVDate", SqlDbType.DateTime);
                    param.Value = MRV.MRVDate;

                    param = cmd.Parameters.Add("@AwardedTo", SqlDbType.VarChar, 100);
                    param.Value = MRV.AwardedTo;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MRV> GetMRVList(String Param, String Flag)
        {
            List<MRV> MRVList = new List<MRV>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMRV";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MRVList.Add(new MRV()
                                {
                                    MRVNum = Convert.ToString(dr["MRVNum"].ToString())
                                    ,
                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                     ,
                                    GMLevel = String.IsNullOrEmpty(dr["GMLevel"].ToString()) ? "" : dr["GMLevel"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JobOrderNum = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    //Purpose = Convert.ToString(dr["Purpose"].ToString())
                                    //  ,
                                    MRVDate = Convert.ToDateTime(dr["MRVDate"].ToString())
                                      ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    ,
                                    MRVStatus = Convert.ToString(dr["MRVStatus"].ToString())
                                        ,
                                    UserAccount = Convert.ToString(dr["AccountUse"].ToString())
                                    ,BranchName = Convert.ToString(dr["BranchName"].ToString())
                                });
                            }
                        }
                    }

                }
                return MRVList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MRV> GetMRVList_ByStatus(String Status,String Param, String Flag)
        {
            List<MRV> MRVList = new List<MRV>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMRV_ByStatus";
                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar, 100);
                    param.Value = Status;
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MRVList.Add(new MRV()
                                {
                                    MRVNum = Convert.ToString(dr["MRVNum"].ToString())
                                    ,
                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    //Purpose = Convert.ToString(dr["Purpose"].ToString())
                                    //  ,
                                    MRVDate = Convert.ToDateTime(dr["MRVDate"].ToString())
                                      ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    ,
                                    MRVStatus = Convert.ToString(dr["MRVStatus"].ToString())
                                        ,
                                    UserAccount = Convert.ToString(dr["AccountUse"].ToString())
                                         ,
                                 
                                    BranchName = Convert.ToString(dr["BranchName"].ToString())
                                });
                            }
                        }
                    }

                }
                return MRVList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MRV> GetMRVList_ByDepartment(String DeptCode, String Param, String Flag)
        {
            List<MRV> MRVList = new List<MRV>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMRV_ByDepartment";
                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 100);
                    param.Value = DeptCode;

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MRVList.Add(new MRV()
                                {
                                    MRVNum = Convert.ToString(dr["MRVNum"].ToString())
                                    ,
                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    //Purpose = Convert.ToString(dr["Purpose"].ToString())
                                    //  ,
                                    MRVDate = Convert.ToDateTime(dr["MRVDate"].ToString())
                                      ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    ,
                                    MRVStatus = Convert.ToString(dr["MRVStatus"].ToString())
                                        ,
                                    UserAccount = Convert.ToString(dr["AccountUse"].ToString())
                                         ,

                                    BranchName = Convert.ToString(dr["BranchName"].ToString())
                                });
                            }
                        }
                    }

                }
                return MRVList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MRV> GetMRVList_ByDepartmentAndStatus(String Status, String DeptCode, String Param, String Flag)
        {
            List<MRV> MRVList = new List<MRV>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMRV_ByDepartmentAndStatus";
                    
                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar, 100);
                    param.Value = Status;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 100);
                    param.Value = DeptCode;

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MRVList.Add(new MRV()
                                {
                                    MRVNum = Convert.ToString(dr["MRVNum"].ToString())
                                    ,
                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    //Purpose = Convert.ToString(dr["Purpose"].ToString())
                                    //  ,
                                    MRVDate = Convert.ToDateTime(dr["MRVDate"].ToString())
                                      ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    ,
                                    MRVStatus = Convert.ToString(dr["MRVStatus"].ToString())
                                        ,
                                    UserAccount = Convert.ToString(dr["AccountUse"].ToString())
                                         ,

                                    BranchName = Convert.ToString(dr["BranchName"].ToString())
                                });
                            }
                        }
                    }

                }
                return MRVList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MRVDetail> GetMRVDetailList(String Param, String Flag, String ReferenceNum)
        {
            List<MRVDetail> MRVDetailList = new List<MRVDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMRVDetail";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                     param.Value = Flag;
                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MRVDetailList.Add(new MRVDetail()
                                {
                                    MRVNum = Convert.ToString(dr["MRVNum"].ToString())
                                    , BranchName = Convert.ToString(dr["BranchName"].ToString())
                                    ,
                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    GMLevel = String.IsNullOrEmpty(dr["GMLevel"].ToString()) ? "" : dr["GMLevel"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JobOrderNum"].ToString())
                                     ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                      ,
                                    MRVDate = Convert.ToDateTime(dr["MRVDate"].ToString())
                                      ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                  
                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    ,
                                    MRVStatus = Convert.ToString(dr["MRVStatus"].ToString())
                                         ,
                                    ItemCode= Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,
                                    UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                        ,
                                    MRVDetailNum = Convert.ToInt32(dr["MRVDetailNum"].ToString())
                                       ,
                                    Available = Convert.ToString(dr["Available"].ToString())
                                       ,
                                     
                                    SubClassID = Convert.ToInt32(dr["SubClassID"].ToString())
                                    ,
                                    ProjectType = Convert.ToString(dr["ProjectType"].ToString())
                                                                        ,
                                    ProjectClass = Convert.ToString(dr["ProjectClass"].ToString())
                                                                        ,
                                    SubClass = Convert.ToString(dr["SubClass"].ToString())
                                                                        ,
                                    SubClassDesc = Convert.ToString(dr["SubClassDesc"].ToString())

                                });
                            }
                        }
                    }

                }
                return MRVDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
     
        public List<MRVDetail> GetMRVDetailList_TempTable(String Param, String Flag)
        {
            List<MRVDetail> MRVDetailList = new List<MRVDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;   
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMRVDetail_Temp";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MRVDetailList.Add(new MRVDetail()
                                {
                                  
                                    MRVNum = Convert.ToString(dr["MRVNum"].ToString())
                                    ,
                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    //,
                                    //DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                   // Month = Convert.ToString(dr["Month"].ToString())
                                   //  ,
                                   // Year = Convert.ToString(dr["Year"].ToString())
                                   //   ,
                                   // Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                   //   ,
                                   // EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   //,
                                   // EmpType = Convert.ToString(dr["EmpType"].ToString())
                                   // ,
                                   // WONo = Convert.ToString(dr["WONo"].ToString())
                                   // ,
                                   // JONo = Convert.ToString(dr["JONo"].ToString())
                                   //  ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                      ,
                                    //MRVDate = Convert.ToDateTime(dr["MRVDate"].ToString())
                                    //  ,
                                    //AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    //,
                                    //IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    //,
                                    //MRVStatus = Convert.ToString(dr["MRVStatus"].ToString())
                                     //    ,
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,
                                    MRVDetailNum = Convert.ToInt32(dr["MRVDetailNum"].ToString())
                                       ,
                                    Available = Convert.ToString(dr["Available"].ToString())
                                    ,
                                    UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                    ,SubClassID = Convert.ToInt32(dr["SubClassID"].ToString())
                                    ,
                                    ProjectType = Convert.ToString(dr["ProjectType"].ToString())
                                                                        ,
                                    ProjectClass = Convert.ToString(dr["ProjectClass"].ToString())
                                                                        ,
                                    SubClass = Convert.ToString(dr["SubClass"].ToString())
                                                                        ,
                                    SubClassDesc = Convert.ToString(dr["SubClassDesc"].ToString())
                                });
                            }
                        }
                    }

                }
                return MRVDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        //public List<CanvassSheetDetail> GetCanvassSheetDetailList(String Param, String Flag)
        //{
        //    List<CanvassSheetDetail> CanvassSheetDetailList = new List<CanvassSheetDetail>();
        //    try
        //    {
        //        using (SqlCommand cmd = new SqlCommand())
        //        {
        //            cmd.Connection = DatabaseConnection.cnn;
        //            DatabaseConnection.Connect();
        //            SqlParameter param = new SqlParameter();
        //            cmd.CommandTimeout = 6000;
        //            cmd.CommandType = CommandType.StoredProcedure;
        //            cmd.CommandText = "warehouse.sp_GetMRVDetail";
        //            param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
        //            param.Value = Param;
        //            param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
        //            param.Value = Flag;
        //            using (SqlDataReader dr = cmd.ExecuteReader())
        //            {
        //                if (dr.HasRows)
        //                {
        //                    while (dr.Read())
        //                    {
        //                        CanvassSheetDetailList.Add(new CanvassSheetDetail()
        //                        {
        //                            MRVNum = Convert.ToString(dr["MRVNum"].ToString())
        //                            ,
        //                            RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
        //                            ,
        //                            DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
        //                            ,
        //                            Month = Convert.ToString(dr["Month"].ToString())
        //                             ,
        //                            Year = Convert.ToString(dr["Year"].ToString())
        //                              ,
        //                            Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
        //                              ,
        //                            EmpID = Convert.ToString(dr["EmpID"].ToString())

        //                           ,
        //                            EmpType = Convert.ToString(dr["EmpType"].ToString())
        //                            ,
        //                            WONo = Convert.ToString(dr["WONo"].ToString())
        //                            ,
        //                            JONo = Convert.ToString(dr["JONo"].ToString())
        //                             ,
        //                            Purpose = Convert.ToString(dr["Purpose"].ToString())
        //                              ,
        //                            MRVDate = Convert.ToDateTime(dr["MRVDate"].ToString())
        //                              ,
        //                            AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
        //                            ,
        //                            IsClosed = Convert.ToString(dr["IsClosed"].ToString())
        //                            ,
        //                            MRVStatus = Convert.ToString(dr["MRVStatus"].ToString())
        //                                 ,
        //                            ItemCode = Convert.ToString(dr["ItemCode"].ToString())
        //                            ,
        //                            ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
        //                                 ,
        //                            ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
        //                                 ,
        //                            ProductName = Convert.ToString(dr["ProductName"].ToString())
        //                                 ,
        //                            Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
        //                                ,
        //                            Unit = Convert.ToString(dr["Unit"].ToString())
        //                                ,
        //                            MRVDetailNum = Convert.ToInt32(dr["MRVDetailNum"].ToString())
        //                               ,
        //                            Available = Convert.ToString(dr["Available"].ToString())
        //                               ,
        //                            BiddingRefNum = Convert.ToString(dr["BiddingRefNum"].ToString())
        //                        });
        //                    }
        //                }
        //            }

        //        }
        //        return CanvassSheetDetailList;
        //    }
        //    catch (Exception ex)
        //    {

        //        return null;
        //    }
        //    finally
        //    {
        //        DatabaseConnection.DBClose();
        //    }
        //}
        public String AddMRVItem(MRVDetail MRVDetail, String Flag)
        {
            try 
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_AddMRVItem";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MRVDetail.RefNum;

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVDetail.MRVNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MRVDetail.BranchName;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = MRVDetail.ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = String.IsNullOrEmpty(MRVDetail.ItemCode)?"":MRVDetail.ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 1000);
                    param.Value = MRVDetail.ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar,1000);
                    param.Value = MRVDetail.ProductDesc;

                    param = cmd.Parameters.Add("@UnitDesc", SqlDbType.VarChar, 20);
                    param.Value = MRVDetail.Unit;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = MRVDetail.Quantity;

                    param = cmd.Parameters.Add("@Purpose", SqlDbType.VarChar, 800);
                    param.Value = MRVDetail.Purpose;

                    param = cmd.Parameters.Add("@Available", SqlDbType.VarChar, 1);
                    param.Value = String.IsNullOrEmpty(MRVDetail.Available)? "": MRVDetail.Available;

                    param = cmd.Parameters.Add("@IsReg", SqlDbType.VarChar, 1);
                    param.Value = MRVDetail.IsReg;

                    param = cmd.Parameters.Add("@SubClassID", SqlDbType.Int);
                    param.Value = MRVDetail.SubClassID;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemoveMRVItem( String MRVNum, String ItemCode, String ReferenceNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_RemoveMRVItem";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;                

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String DeleteMRV(String MRVNum, String MRVStatus, String BranchName)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_DeleteMRV";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                    
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String DeleteFullMRV(String MRVNum, String MRVStatus)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_DeleteFullMRV";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@MRVStatus", SqlDbType.VarChar, 50);
                    param.Value = MRVStatus;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CancelMRV(String ReferenceNum, String MRVNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CancelMRV";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public void DeleteMRVDetail(String MRVNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_DeleteMRVDetail";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                return;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

       
        public String UpdateMRVItem(MRVDetail MRVDetail)
        {
            try
            {
                //update MRV item in temp table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateMRVItem";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = MRVDetail.RefNum;

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVDetail.MRVNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MRVDetail.BranchName;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = MRVDetail.ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar,50);
                    param.Value = MRVDetail.ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 1000);
                    param.Value = MRVDetail.ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar, 1000);
                    param.Value = MRVDetail.ProductDesc;

                    param = cmd.Parameters.Add("@Unit", SqlDbType.VarChar, 50);
                    param.Value = MRVDetail.Unit;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = MRVDetail.Quantity;

                    param = cmd.Parameters.Add("@Purpose", SqlDbType.VarChar, 800);
                    param.Value = MRVDetail.Purpose;

                    param = cmd.Parameters.Add("@SubClassID", SqlDbType.Int);
                    param.Value = MRVDetail.SubClassID;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String CheckMRVStatus(String MRVNum, String Action, String GMLevel)
        {
            try
            {
                //save MRV Status
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckMRVStatus";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@GMLevel", SqlDbType.VarChar, 1);
                    param.Value = GMLevel;

                    param = cmd.Parameters.Add("@Action", SqlDbType.VarChar, 50);
                    param.Value = Action;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CheckMRVOwner(String MRVNum, Int32 UserID)
        {
            try
            {
                //save MRV Status
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckMRVOwner";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 200);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<RIVClass> GetRIVClassList(String Param,String DeptCode, String Flag)
        {
            List<RIVClass> MRVClassList = new List<RIVClass>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetRIVClass";

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 100);
                    param.Value = DeptCode;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MRVClassList.Add(new RIVClass()
                                {
                                    SubClassID = Convert.ToInt32(dr["SubClassID"].ToString())
                                    ,
                                    ProjectType = String.IsNullOrEmpty(dr["ProjectType"].ToString()) ? "" : dr["ProjectType"].ToString()
                                    ,
                                    ProjectClass = String.IsNullOrEmpty(dr["ProjectClass"].ToString()) ? "" : dr["ProjectClass"].ToString()
                                    ,
                                    SubClass = String.IsNullOrEmpty(dr["SubClass"].ToString()) ? "" : dr["SubClass"].ToString()
                                     ,
                                    SubClassDesc = String.IsNullOrEmpty(dr["SubClassDesc"].ToString()) ? "" : dr["SubClassDesc"].ToString()

                                });
                            }
                        }
                    }

                }
                return MRVClassList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String GetMRVCurrentStatus(String MRVNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMRVCurrentStatus";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;
     
                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar, 50);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Status"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String ImportMRV(String ReferenceNum, String MRVNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_ImportMRV";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String ReAlignMRVItem(String MRVNum, Int32 MRVDetailNum, Int32 ProductCode, String ItemCode, String ProductName, String ProductDesc
            , Int32 OldProductCode, String OldItemCode, String OldProductName, String OldProductDesc, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_ReAlignMRVItem";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@MRVDetailNum", SqlDbType.Int);
                    param.Value = MRVDetailNum;

                    param = cmd.Parameters.Add("@OldProductCode", SqlDbType.Int);
                    param.Value = OldProductCode;

                    param = cmd.Parameters.Add("@OldItemCode", SqlDbType.VarChar);
                    param.Value = OldItemCode;

                    param = cmd.Parameters.Add("@OldProductName", SqlDbType.VarChar);
                    param.Value = OldProductName;

                    param = cmd.Parameters.Add("@OldProductDesc", SqlDbType.VarChar);
                    param.Value = OldProductDesc;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar);
                    param.Value = ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar);
                    param.Value = ProductDesc;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MRVDetail> GetMRVReserveItemList(String ItemCode, String BranchName, String Flag)
        {
            List<MRVDetail> MRVDetailList = new List<MRVDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMRVReserveItem";

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = ItemCode;
                    
                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 200);
                    param.Value = BranchName;
                    
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MRVDetailList.Add(new MRVDetail()
                                {
                                    MRVNum = Convert.ToString(dr["MRVNum"].ToString())
                                    ,
                                    BranchName = Convert.ToString(dr["BranchName"].ToString())
                                    ,
                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    GMLevel = String.IsNullOrEmpty(dr["GMLevel"].ToString()) ? "" : dr["GMLevel"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                      ,
                                    MRVDate = Convert.ToDateTime(dr["MRVDate"].ToString())
                                      ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,

                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    ,
                                    MRVStatus = Convert.ToString(dr["MRVStatus"].ToString())
                                         ,
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,
                                    UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                        ,
                                    MRVDetailNum = Convert.ToInt32(dr["MRVDetailNum"].ToString())
                                       ,
                                    Available = Convert.ToString(dr["Available"].ToString())
                                       ,

                                    SubClassID = Convert.ToInt32(dr["SubClassID"].ToString())
                                    ,
                                    ProjectType = Convert.ToString(dr["ProjectType"].ToString())
                                                                        ,
                                    ProjectClass = Convert.ToString(dr["ProjectClass"].ToString())
                                                                        ,
                                    SubClass = Convert.ToString(dr["SubClass"].ToString())
                                                                        ,
                                    SubClassDesc = Convert.ToString(dr["SubClassDesc"].ToString())

                                });
                            }
                        }
                    }

                }
                return MRVDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String CheckMRVGatePassAndMCT(String MRVNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckMRVGatePassAndMCT";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@HasGatePass", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@HasMCT", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.MRVHasGatePass = Convert.ToString(cmd.Parameters["@HasGatePass"].Value);
                    GlobalVariable.MRVHasMCT = Convert.ToString(cmd.Parameters["@HasMCT"].Value);
                    return "";
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }


        public String AddMRVDetailItemHistory(MRVDetail MRVDetail,  String ModType, String Reason)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_AddMRVDetailItemHistory_Temp";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MRVDetail.RefNum;

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVDetail.MRVNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MRVDetail.BranchName;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = MRVDetail.ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = String.IsNullOrEmpty(MRVDetail.ItemCode) ? "" : MRVDetail.ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 1000);
                    param.Value = MRVDetail.ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar, 1000);
                    param.Value = MRVDetail.ProductDesc;

                    param = cmd.Parameters.Add("@UnitDesc", SqlDbType.VarChar, 20);
                    param.Value = MRVDetail.Unit;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = MRVDetail.Quantity;

                    param = cmd.Parameters.Add("@Purpose", SqlDbType.VarChar, 800);
                    param.Value = MRVDetail.Purpose;

                    param = cmd.Parameters.Add("@Available", SqlDbType.VarChar, 1);
                    param.Value = String.IsNullOrEmpty(MRVDetail.Available) ? "" : MRVDetail.Available;

                    param = cmd.Parameters.Add("@IsReg", SqlDbType.VarChar, 1);
                    param.Value = "";

                    param = cmd.Parameters.Add("@SubClassID", SqlDbType.Int);
                    param.Value = MRVDetail.SubClassID;

                    param = cmd.Parameters.Add("@ModType", SqlDbType.VarChar, 50);
                    param.Value = ModType;

                    param = cmd.Parameters.Add("@Reason", SqlDbType.VarChar, 500);
                    param.Value = Reason;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = "";

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String CheckMRV_JobOrderExist(String MLCNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckMRV_JobOrderExist";

                    param = cmd.Parameters.Add("@MLCNum", SqlDbType.VarChar, 20);
                    param.Value = MLCNum;


                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<ProductDetail> GetMRVDetailItemProductStockDetailList(String RefNum, String BranchName,String Param,String Flag)
        {
            List<ProductDetail> ProductDetailList = new List<ProductDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMRVDetailItemProductStockDetail";

    
                    param = cmd.Parameters.Add("@RefNum", SqlDbType.VarChar, 100);
                    param.Value = RefNum;


                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 50);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ProductDetailList.Add(new ProductDetail()
                                {

                                    StockDetailID = Convert.ToInt32(dr["StockDetailID"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                   ,
                                    BranchID = Convert.ToInt32(dr["BranchID"].ToString())
                                   ,
                                    StockType = Convert.ToString(dr["StockType"].ToString())
                                   ,
                                    TransNum = Convert.ToString(dr["TransNum"].ToString())
                                   ,

                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,

                                    UnitDesc = Convert.ToString(dr["Unit"].ToString())
                                        ,
                                    Status = Convert.ToString(dr["Status"].ToString())
                                       ,
                                    Withdrawn = Convert.ToString(dr["Withdrawn"].ToString())
                                    ,
                                    Brand = Convert.ToString(dr["Brand"].ToString())
                                    ,
                                    KVA = Convert.ToString(dr["KVA"].ToString())

                                    ,
                                    SerialNo = Convert.ToString(dr["SerialNo"].ToString())
                                    ,
                                    TagNo = Convert.ToString(dr["TagNo"].ToString())

                                    ,
                                    Primary = Convert.ToString(dr["Primary"].ToString())

                                    ,
                                    Secondary = Convert.ToString(dr["Secondary"].ToString())

                                    ,
                                    Polarity = Convert.ToString(dr["Polarity"].ToString())
                                    ,
                                    Bushing = Convert.ToString(dr["Bushing"].ToString())
                                    ,
                                    Impedance = Convert.ToString(dr["Impedance"].ToString())
                                    ,
                                    DateManufacture = Convert.ToDateTime(dr["DateManufacture"].ToString())

                                });

                            }
                        }

                    }
                    return ProductDetailList;
                }
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<ProductInventoryView> GetMRVDetailItemProductStockList(String RefNum, String BranchName, String Param, String Flag)
        {
            List<ProductInventoryView> ProductList = new List<ProductInventoryView>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMRVDetailItemProductStock";


                    param = cmd.Parameters.Add("@RefNum", SqlDbType.VarChar, 100);
                    param.Value = RefNum;


                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 50);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ProductList.Add(new ProductInventoryView()
                                {

                                     
                                    

                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,

                                    Unit = Convert.ToString(dr["Unit"].ToString())
                                        ,
                                    Units = Convert.ToString(dr["Units"].ToString())
                                        ,
                                   Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                });

                            }
                        }

                    }
                    return ProductList;
                }
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
    }
}
