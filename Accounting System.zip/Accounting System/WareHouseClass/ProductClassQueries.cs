﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Data;
using anecoacct.WareHouseModel;

namespace anecoacct.WareHouseClass
{
    class ProductClassQueries
    {
        public List<ProductClass> GetProductClassInfo(String Param, String Flag)
        {
            List<ProductClass> ProductClassList = new List<ProductClass>();
            try
            {
                using ( SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetProductClass";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ProductClassList.Add(new ProductClass()
                                {
                                    ClassCode = Convert.ToInt32(dr["ClassCode"].ToString())
                                    ,
                                    AccountCode = String.IsNullOrEmpty(dr["AccountCode"].ToString()) ? "" : dr["AccountCode"].ToString()
                                    ,                                    
                                    AccountDesc = String.IsNullOrEmpty(dr["AccountDesc"].ToString()) ? "" : dr["AccountDesc"].ToString()
                                     ,                                    
                                    Address = String.IsNullOrEmpty(dr["Address"].ToString()) ? "" : dr["Address"].ToString()
                                   ,
                                    FlagDel = String.IsNullOrEmpty(dr["FlagDel"].ToString()) ? "" : dr["FlagDel"].ToString()
                                   ,
                                    CreatedBy = Convert.ToInt32(dr["CreatedBy"].ToString())
                                     ,
                                    DateCreated = Convert.ToDateTime(dr["DateCreated"].ToString())
                                      ,
                                    ModifiedBy = Convert.ToInt32(dr["ModifiedBy"].ToString())
                                      ,
                                    DateModified = Convert.ToDateTime(dr["DateModified"].ToString())
                                });
                            }
                        }
                    }

                }
                return ProductClassList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }


    
    }
}
