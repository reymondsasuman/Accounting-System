﻿using anecoacct.WareHouseModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseClass
{
    
    class MCTGraphQueries
    {
        modFunctions modFunctions = new modFunctions();
        public List<MCTGraph> GetMCTGraph(String ItemCode, String Year, String DeptCode, String Flag)
        {
            try
            {
                List<MCTGraph> MCTGraphList = new List<MCTGraph>();
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_MCTGraphPerItem";

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 100);
                    param.Value = DeptCode;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MCTGraphList.Add(new MCTGraph()
                                {
                                    Month = Convert.ToString(modFunctions.GetMonthString(dr["Month"].ToString()))
                                  ,

                                    Year = Convert.ToString(dr["Year"].ToString())
                                    ,
                                    DeptCode = Convert.ToString(dr["DeptCode"].ToString())
                                    ,
                                    ItemCode = String.IsNullOrEmpty(dr["ItemCode"].ToString()) ? "" : dr["ItemCode"].ToString()
                                     ,
                                    ProductName = String.IsNullOrEmpty(dr["ProductName"].ToString()) ? "" : dr["ProductName"].ToString()
                                       ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                  
                                });
                            }
                        }
                    }
                    return MCTGraphList;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
    }
}
