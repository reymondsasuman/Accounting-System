﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using anecoacct.WareHouseModel;
using System.Data.SqlClient;
using System.Windows.Forms;
using anecoacct.WareHouseClass;

namespace anecoacct.WareHouseClass
{
    class MCTQueries
    {
        OtherQueries OtherQueries = new OtherQueries();
        modFunctions GlobalFunc = new modFunctions();
        public String UpdateMCTDetailItem(String ReferenceNum, Int32 MRVDetailNum, String AcctCode)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateMCTDetailItemAcctCode";

                    param = cmd.Parameters.Add("@MCTReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = AcctCode;

                    param = cmd.Parameters.Add("@MRVDetailNum", SqlDbType.Int);
                    param.Value = MRVDetailNum;

                    param = cmd.Parameters.Add("@AcctCode", SqlDbType.VarChar, 20);
                    param.Value = AcctCode;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }


        public String GetGatePassDetailIntoMCTDetailTemp(String GatePassNum, String ReferenceNum, String BranchName, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetGatePassDetailIntoMCTDetailTemp";

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Value = GatePassNum;

                    param = cmd.Parameters.Add("@MCTReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 800);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String SaveMCT(MCT MCT)
        {
            try
            {
                //save MRV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveMCT";

                    param = cmd.Parameters.Add("@MCTNum", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MCT.RefNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MCT.BranchName;

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MCT.MRVNum;

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Value = MCT.GatePassNum;

                    param = cmd.Parameters.Add("@MCTDate", SqlDbType.DateTime);
                    param.Value = MCT.MCTDate;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 20);
                    param.Value = MCT.DeptCode;

                    param = cmd.Parameters.Add("@WONo", SqlDbType.VarChar, 20);
                    param.Value = MCT.WONo;

                    param = cmd.Parameters.Add("@JONo", SqlDbType.VarChar, 20);
                    param.Value = MCT.JONo;

                    param = cmd.Parameters.Add("@AwardedTo", SqlDbType.VarChar, 100);
                    param.Value = MCT.AwardedTo;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewMCTNum = Convert.ToString(cmd.Parameters["@MCTNum"].Value.ToString());
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CancelMCT(String ReferenceNum, String MRVNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CancelMCT";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String DeleteMCT(String ReferenceNum, String MRVNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_DeleteMCT";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@MCTNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String EditMCT(String ReferenceNum, String MCTNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_EditMCT";

                    param = cmd.Parameters.Add("@MCTNum", SqlDbType.VarChar, 20);
                    param.Value = MCTNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateMCT(MCT MCT)
        {
            try
            {
                //update MRV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateMCT";

                    param = cmd.Parameters.Add("@MCTNum", SqlDbType.VarChar, 20);
                    param.Value = MCT.MCTNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = MCT.RefNum;

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MCT.MRVNum;

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Value = MCT.GatePassNum;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 20);
                    param.Value = MCT.DeptCode;

                    param = cmd.Parameters.Add("@WONo", SqlDbType.VarChar, 20);
                    param.Value = MCT.WONo;


                    param = cmd.Parameters.Add("@JONo", SqlDbType.VarChar, 20);
                    param.Value = MCT.JONo;

                    param = cmd.Parameters.Add("@AwardedTo", SqlDbType.VarChar, 100);
                    param.Value = MCT.AwardedTo;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MCT> GetMCTPerPeriodList(String Month, String Year, String BranchName, String Flag, String Param)
        {
            List<MCT> MCTList = new List<MCT>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMCTPerPeriod";

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = GlobalFunc.GetMonthNum(Month);

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 50);
                    param.Value = Param;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MCTList.Add(new MCT()
                                {
                                    MCTNum = Convert.ToString(dr["MCTNum"].ToString())
                                    ,
                                    MCTDate = Convert.ToDateTime(dr["MCTDate"].ToString())

                                    ,
                                    GatePassNum = Convert.ToString(dr["GatePassNum"].ToString())
                                    ,

                                    MRVNum = Convert.ToString(dr["MRVNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                     ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                       ,
                                    UserAccount = String.IsNullOrEmpty(dr["AccountUse"].ToString()) ? "" : dr["AccountUse"].ToString()
                                    ,
                                    BranchName = String.IsNullOrEmpty(dr["BranchName"].ToString()) ? "" : dr["BranchName"].ToString()
                                    ,
                                    TotalCost = Convert.ToDecimal(dr["TotalCost"].ToString())
                                    ,Checked = Convert.ToString(dr["Checked"].ToString())
                                });
                            }
                        }
                    }


                }
                return MCTList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MCT> GetMCTPerPeriodWithParamList(String Month, String Year, String BranchName, String Param, String Flag)
        {
            List<MCT> MCTList = new List<MCT>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMCTPerPeriodWithParam";

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = GlobalFunc.GetMonthNum(Month);

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 50);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MCTList.Add(new MCT()
                                {
                                    MCTNum = Convert.ToString(dr["MCTNum"].ToString())
                                    ,
                                    MCTDate = Convert.ToDateTime(dr["MCTDate"].ToString())

                                    ,
                                    GatePassNum = Convert.ToString(dr["GatePassNum"].ToString())
                                    ,

                                    MRVNum = Convert.ToString(dr["MRVNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                     ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                       ,
                                    UserAccount = String.IsNullOrEmpty(dr["AccountUse"].ToString()) ? "" : dr["AccountUse"].ToString()
                                    ,
                                    BranchName = String.IsNullOrEmpty(dr["BranchName"].ToString()) ? "" : dr["BranchName"].ToString()
                                    ,
                                    TotalCost = Convert.ToDecimal(dr["TotalCost"].ToString())
                                    ,
                                    Checked = Convert.ToString(dr["Checked"].ToString())
                                });
                            }
                        }
                    }


                }
                return MCTList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MCT> GetMCTList(String Param, String Flag)
        {
            List<MCT> MCTList = new List<MCT>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMCT";

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MCTList.Add(new MCT()
                                {
                                    MCTNum = Convert.ToString(dr["MCTNum"].ToString())
                                    ,
                                    MCTDate = Convert.ToDateTime(dr["MCTDate"].ToString())

                                    ,
                                    GatePassNum = Convert.ToString(dr["GatePassNum"].ToString())
                                    ,

                                    MRVNum = Convert.ToString(dr["MRVNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                     ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                       ,
                                    UserAccount = String.IsNullOrEmpty(dr["AccountUse"].ToString()) ? "" : dr["AccountUse"].ToString()
                                    ,
                                    BranchName = String.IsNullOrEmpty(dr["BranchName"].ToString()) ? "" : dr["BranchName"].ToString()

                                       ,
                                    RefNum = String.IsNullOrEmpty(dr["MCTReferenceNum"].ToString()) ? "" : dr["MCTReferenceNum"].ToString()
                                
                            });
                            }
                        }
                    }

                }
                return MCTList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MCT> GetMCTList_ByDepartment(String DeptCode, String Param, String Flag)
        {
            List<MCT> MCTList = new List<MCT>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMCT_ByDepartment";


                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 100);
                    param.Value = DeptCode;

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MCTList.Add(new MCT()
                                {
                                    MCTNum = Convert.ToString(dr["MCTNum"].ToString())
                                    ,
                                    MCTDate = Convert.ToDateTime(dr["MCTDate"].ToString())

                                    ,
                                    GatePassNum = Convert.ToString(dr["GatePassNum"].ToString())
                                    ,

                                    MRVNum = Convert.ToString(dr["MRVNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                     ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                       ,
                                    UserAccount = String.IsNullOrEmpty(dr["AccountUse"].ToString()) ? "" : dr["AccountUse"].ToString()
                                    ,
                                    BranchName = String.IsNullOrEmpty(dr["BranchName"].ToString()) ? "" : dr["BranchName"].ToString()

                                       ,
                                    RefNum = String.IsNullOrEmpty(dr["MCTReferenceNum"].ToString()) ? "" : dr["MCTReferenceNum"].ToString()

                                });
                            }
                        }
                    }

                }
                return MCTList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MCTDetail> GetMCTDetailListPerPeriod(String Param, String Month, String Year, String Flag)
        {
            List<MCTDetail> MCTDetailList = new List<MCTDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMCTDetailPerPeriod";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = GlobalFunc.GetMonthNum(Month);

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MCTDetailList.Add(new MCTDetail()
                                {
                                    MCTDate = Convert.ToString(dr["MCTDate"].ToString())
                                    ,
                                    MCTNum = Convert.ToString(dr["MCTNum"].ToString())
                                    ,
                                    MCTDetailNum = Convert.ToInt32(dr["MCTDetailNum"].ToString())
                                    ,
                                    AcctCode = Convert.ToString(dr["AcctCode"].ToString())
                                    ,
                                    AcctDesc = Convert.ToString(dr["AcctDesc"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    MRVNum = Convert.ToString(dr["MRVNum"].ToString())
                                    ,
                                    GatePassNum = Convert.ToString(dr["GatePassNum"].ToString())
                                    ,
                                    MRVDate = Convert.ToString(dr["MRVDate"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                      ,

                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    GatePassDetailNum = Convert.ToInt32(dr["GatePassDetailNum"].ToString())
                                    ,

                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,

                                    GMLevel = String.IsNullOrEmpty(dr["GMLevel"].ToString()) ? "" : dr["GMLevel"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,

                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())

                                     ,
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,
                                    UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                        ,
                                    MRVDetailNum = Convert.ToInt32(dr["MRVDetailNum"].ToString())
                                       ,
                                    Available = Convert.ToString(dr["Available"].ToString())
                                       ,

                                    SubClassID = Convert.ToInt32(dr["SubClassID"].ToString())
                                    ,
                                    ProjectType = Convert.ToString(dr["ProjectType"].ToString())
                                                                        ,
                                    ProjectClass = Convert.ToString(dr["ProjectClass"].ToString())
                                                                        ,
                                    SubClass = Convert.ToString(dr["SubClass"].ToString())
                                                                        ,
                                    SubClassDesc = Convert.ToString(dr["SubClassDesc"].ToString())
                                    ,
                                    ReceivedBy = Convert.ToString(dr["ReceivedBy"].ToString())
                                    ,
                                    BranchName = Convert.ToString(dr["BranchName"].ToString())
                                       ,
                                    UnitCost = Convert.ToDecimal(dr["UnitCost"].ToString())

                                });
                            }
                        }
                    }

                }
                return MCTDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }

        }

        public List<MCTDetail> GetMCTDetailList(String Param, String Flag)
        {
            List<MCTDetail> MCTDetailList = new List<MCTDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMCTDetail";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MCTDetailList.Add(new MCTDetail()
                                {
                                    MCTDate = Convert.ToString(dr["MCTDate"].ToString())
                                    ,
                                    MCTNum = Convert.ToString(dr["MCTNum"].ToString())
                                    ,
                                    MCTDetailNum = Convert.ToInt32(dr["MCTDetailNum"].ToString())
                                    ,
                                    AcctCode = Convert.ToString(dr["AcctCode"].ToString())
                                    ,
                                    AcctDesc = Convert.ToString(dr["AcctDesc"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    MRVNum = Convert.ToString(dr["MRVNum"].ToString())
                                    ,
                                    GatePassNum = Convert.ToString(dr["GatePassNum"].ToString())
                                    ,
                                    MRVDate = Convert.ToString(dr["MRVDate"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                      ,

                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    GatePassDetailNum = Convert.ToInt32(dr["GatePassDetailNum"].ToString())
                                    ,

                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,

                                    GMLevel = String.IsNullOrEmpty(dr["GMLevel"].ToString()) ? "" : dr["GMLevel"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,

                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())

                                     ,
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,
                                    UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                        ,
                                    MRVDetailNum = Convert.ToInt32(dr["MRVDetailNum"].ToString())
                                       ,
                                    Available = Convert.ToString(dr["Available"].ToString())
                                       ,

                                    SubClassID = Convert.ToInt32(dr["SubClassID"].ToString())
                                    ,
                                    ProjectType = Convert.ToString(dr["ProjectType"].ToString())
                                                                        ,
                                    ProjectClass = Convert.ToString(dr["ProjectClass"].ToString())
                                                                        ,
                                    SubClass = Convert.ToString(dr["SubClass"].ToString())
                                                                        ,
                                    SubClassDesc = Convert.ToString(dr["SubClassDesc"].ToString())
                                    ,
                                    ReceivedBy = Convert.ToString(dr["ReceivedBy"].ToString())
                                    ,
                                    BranchName = Convert.ToString(dr["BranchName"].ToString())
                                });
                            }
                        }
                    }

                }
                return MCTDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String SetMCTCheckedStatus(String Action, String RRNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SetMCTCheckedStatus";

                    param = cmd.Parameters.Add("@Action", SqlDbType.VarChar, 20);
                    param.Value = Action;

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 20);
                    param.Value = RRNum;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = "Status";

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String SavedTransactionClose( String TransType, String Month, String Year)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveTransactionClose";

                    param = cmd.Parameters.Add("@TransType", SqlDbType.VarChar, 50);
                    param.Value = TransType;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CheckMCTCheckedMark(String Month, string Year, String BranchName)//
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckMCTCheckedMark";

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CheckMCTEditMode (String MCTNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckMCTEditMode";

                   
                    param = cmd.Parameters.Add("@MCTNum", SqlDbType.VarChar, 20);
                    param.Value = MCTNum;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CheckMaterialChargeTicketItemHasDetail(String ReferenceNum, Int32 ProductCode, String ItemCode, String ProductName, Decimal Quantity)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckMCTItemHasDetail";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 1000);
                    param.Value = ProductName;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = Quantity;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 200);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<ProductView> GetMCTItemThatHasDetail(String ReferenceNum, String Flag)
        {
            List<ProductView> ProductViewList = new List<ProductView>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMaterialChargeTicketItemThatHasDetail";
                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ProductViewList.Add(new ProductView()
                                {
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                    ,
                                    ItemCode = String.IsNullOrEmpty(dr["ItemCode"].ToString()) ? "" : dr["ItemCode"].ToString()
                                    ,

                                    ProductName = String.IsNullOrEmpty(dr["ProductName"].ToString()) ? "" : dr["ProductName"].ToString()
                                      ,

                                    Unit = String.IsNullOrEmpty(dr["Unit"].ToString()) ? "" : dr["Unit"].ToString()
                                       ,

                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                });
                            }
                        }
                    }

                }
                return ProductViewList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
    }
}