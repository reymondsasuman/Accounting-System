﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using anecoacct.WareHouseClass;
using anecoacct.WareHouseModel;
using System.Data;
using System.Data.SqlClient;
namespace anecoacct.WareHouseClass
{
    class BeginningBalanceQueries
    {
        modFunctions GlobalFunction = new modFunctions();
        public List<ProductView> GetProducInfo(String Param, String Flag)
        {
            List<ProductView> ProductViewList = new List<ProductView>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetProductNEA";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ProductViewList.Add(new ProductView()
                                {
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                    ,
                                    ItemCode = String.IsNullOrEmpty(dr["ItemCode"].ToString()) ? "" : dr["ItemCode"].ToString()
                                    ,
                                  
                                    ProductName = String.IsNullOrEmpty(dr["ProductName"].ToString()) ? "" : dr["ProductName"].ToString()
                                      ,
                                    ProductDesc = String.IsNullOrEmpty(dr["ProductDesc"].ToString()) ? "" : dr["ProductDesc"].ToString()
                                      ,
                                    UnitID = Convert.ToInt32(dr["UnitID"].ToString())
                                    ,
                                    IsReg = String.IsNullOrEmpty(dr["IsReg"].ToString()) ? "" : dr["IsReg"].ToString()
                                   ,
                                    FlagDel = String.IsNullOrEmpty(dr["FlagDel"].ToString()) ? "" : dr["FlagDel"].ToString()
                                   ,
                                    CreatedBy = Convert.ToInt32(dr["CreatedBy"].ToString())
                                     ,
                                    DateCreated = Convert.ToDateTime(dr["DateCreated"].ToString())
                                      ,
                                    ModifiedBy = Convert.ToInt32(dr["ModifiedBy"].ToString())
                                      ,
                                    DateModified = Convert.ToDateTime(dr["DateModified"].ToString())

                                      ,
                                    AccountCode = String.IsNullOrEmpty(dr["AcctCode"].ToString()) ? "" : dr["AcctCode"].ToString()

  ,
                                    AccountDesc = String.IsNullOrEmpty(dr["AcctDesc"].ToString()) ? "" : dr["AcctDesc"].ToString()

                                      ,
                                    Address = String.IsNullOrEmpty(dr["Address"].ToString()) ? "" : dr["Address"].ToString()

  ,
                                    Unit = String.IsNullOrEmpty(dr["Unit"].ToString()) ? "" : dr["Unit"].ToString()
                                      ,
                                    Units = String.IsNullOrEmpty(dr["Units"].ToString()) ? "" : dr["Units"].ToString()
                                      ,
                                    Quantity =Convert.ToDecimal(dr["Quantity"].ToString())
                                                                         ,
                                    UnitCost = Convert.ToDecimal(dr["UnitCost"].ToString())
                                                                         ,
                                    TotalCost = Convert.ToDecimal(dr["TotalCost"].ToString())
                                });
                            }
                        }
                    }

                }
                return ProductViewList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String SaveProductNEA_inBeginningBalanceTemp(String ReferenceNum,String BranchName,String Month,String Year, String Flag)
        {
           
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveProductNEA_inBeginningBalanceTemp";
                    
                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 200);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = GlobalFunction.GetMonthNum(Month);

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    cmd.ExecuteNonQuery();

                }
                return "";
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String SaveBeginningBalance(String Sourcetable, String ReferenceNum, String Month, String Year, String BranchName)
        {

            try
            {
                
                using (SqlCommand cmd = new SqlCommand())
                {

                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveBeginningBalance";

                    param = cmd.Parameters.Add("@SourceTable", SqlDbType.VarChar, 100);
                    param.Value = Sourcetable;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar,50);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = GlobalFunction.GetMonthNum(Month);

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }

                
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateRefNumBranchNameInBBDraft(String ReferenceNum, String BranchName)
        {

            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {

                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateRefNumBranchName_inBeginningBalanceDraft";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }


            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CheckBeginningBalance( String Month, String Year, String BranchName)
        {

            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {

                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckBeginningBalance";

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = GlobalFunction.GetMonthNum(Month);

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }


            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateProductNEA_inBeginningBalanceTemp(String ReferenceNum, String ItemCode, Decimal Quantity, Decimal UnitCost, String Flag)
        {

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateProductNEA_inBeginningBalanceTemp";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = Quantity;

                    param = cmd.Parameters.Add("@UnitCost", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = UnitCost;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    cmd.ExecuteNonQuery();

                }
                return "";
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<BegginingBalanceDraft> GetBeginningBalanceDraft(String Param, String Flag)
        {
            List<BegginingBalanceDraft> ProductList = new List<BegginingBalanceDraft>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetBeginningBalanceDraft";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ProductList.Add(new BegginingBalanceDraft()
                                {
                                    
                                    BranchID = Convert.ToInt32(dr["BranchID"].ToString())
                                    ,
                                    BranchName = String.IsNullOrEmpty(dr["BranchName"].ToString()) ? "" : dr["BranchName"].ToString()
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                    ,
                                    ItemCode = String.IsNullOrEmpty(dr["ItemCode"].ToString()) ? "" : dr["ItemCode"].ToString()
                                    ,
                                    
                                    ProductName = String.IsNullOrEmpty(dr["ProductName"].ToString()) ? "" : dr["ProductName"].ToString()
                                      ,
                                    ProductDesc = String.IsNullOrEmpty(dr["ProductDesc"].ToString()) ? "" : dr["ProductDesc"].ToString()
                                      ,
                                    UnitID = Convert.ToInt32(dr["UnitID"].ToString())
                                    ,
                                  
                                    FlagDel = String.IsNullOrEmpty(dr["FlagDel"].ToString()) ? "" : dr["FlagDel"].ToString()
                                   ,
                                    //CreatedBy = Convert.ToInt32(dr["CreatedBy"].ToString())
                                    // ,
                                    //DateCreated = Convert.ToDateTime(dr["DateCreated"].ToString())
                                    //  ,
                                    //ModifiedBy = Convert.ToInt32(dr["ModifiedBy"].ToString())
                                    //  ,
                                    //DateModified = Convert.ToDateTime(dr["DateModified"].ToString())

                                    //  ,
                                    AccountCode = String.IsNullOrEmpty(dr["AcctCode"].ToString()) ? "" : dr["AcctCode"].ToString()

  ,
                                    AccountDesc = String.IsNullOrEmpty(dr["AcctDesc"].ToString()) ? "" : dr["AcctDesc"].ToString()

                                      ,
                                    Address = String.IsNullOrEmpty(dr["Address"].ToString()) ? "" : dr["Address"].ToString()

  ,
                                    Unit = String.IsNullOrEmpty(dr["Unit"].ToString()) ? "" : dr["Unit"].ToString()
                                      ,
                                    Units = String.IsNullOrEmpty(dr["Units"].ToString()) ? "" : dr["Units"].ToString()
                                      ,
                                    Quantity =  String.IsNullOrEmpty(dr["Quantity"].ToString())? 0: Convert.ToDecimal(dr["Quantity"].ToString())   
                                                                         ,
                                    UnitCost = String.IsNullOrEmpty(dr["UnitCost"].ToString()) ? 0 : Convert.ToDecimal(dr["UnitCost"].ToString())
                                                                         ,
                                    TotalCost = String.IsNullOrEmpty(dr["TotalCost"].ToString()) ? 0 : Convert.ToDecimal(dr["TotalCost"].ToString()) 
                                });
                            }
                        }
                    }

                }
                return ProductList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateProductDraft_inBeginningBalanceDraft(String ReferenceNum, String ItemCode, Decimal Quantity, Decimal UnitCost, String Flag)
        {

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateProductDraft_inBeginningBalanceDraft";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = Quantity;

                    param = cmd.Parameters.Add("@UnitCost", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = UnitCost;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    cmd.ExecuteNonQuery();

                }
                return "";
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CheckProductNEAExistence(String ItemCode, String ProductName, String ProductDesc)
        {

            try
            {
                String IsExist;
                using (SqlCommand cmd = new SqlCommand())
                {
                   
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckProductNEAExistence";

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar);
                    param.Value = ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar);
                    param.Value = ProductDesc;

                    param = cmd.Parameters.Add("@IsExist", SqlDbType.Bit);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                     IsExist = Convert.ToString(cmd.Parameters["@IsExist"].Value);
                }

                return IsExist;
            }
            catch (Exception ex)
            {
                
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CheckBBItemHasDetail(String ReferenceNum, Int32 ProductCode, String ItemCode, String ProductName, Decimal Quantity)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckReceivingReportItemHasDetail";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 1000);
                    param.Value = ProductName;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = Quantity;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 200);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<ProductView> GetBBItemThatHasDetail(String ReferenceNum, String Flag)
        {
            List<ProductView> ProductViewList = new List<ProductView>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetBeginningBalanceItemThatHasDetail";
                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ProductViewList.Add(new ProductView()
                                {
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                    ,
                                    ItemCode = String.IsNullOrEmpty(dr["ItemCode"].ToString()) ? "" : dr["ItemCode"].ToString()
                                    ,

                                    ProductName = String.IsNullOrEmpty(dr["ProductName"].ToString()) ? "" : dr["ProductName"].ToString()
                                      ,

                                    Unit = String.IsNullOrEmpty(dr["Unit"].ToString()) ? "" : dr["Unit"].ToString()
                                       ,

                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                });
                            }
                        }
                    }

                }
                return ProductViewList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CancelBegBal(String ReferenceNum )
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CancelBegBal";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
    }
}
