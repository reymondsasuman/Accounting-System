﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using anecoacct.WareHouseModel;
using System.Data.SqlClient;
using System.Windows.Forms;
using anecoacct.WareHouseClass;

namespace anecoacct.WareHouseClass
{
    class MCRTQueries
    {
 
        OtherQueries OtherQueries = new OtherQueries();
        modFunctions GlobalFunc = new modFunctions();
        public String UpdateMCRTDetailItem(String ReferenceNum, Int32 MRVDetailNum, String AcctCode)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateMCTDetailItemAcctCode";

                    param = cmd.Parameters.Add("@MCTReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = AcctCode;

                    param = cmd.Parameters.Add("@MRVDetailNum", SqlDbType.Int);
                    param.Value = MRVDetailNum;

                    param = cmd.Parameters.Add("@AcctCode", SqlDbType.VarChar, 20);
                    param.Value = AcctCode;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }


        public String GetGatePassDetailIntoMCTDetailTemp(String GatePassNum, String ReferenceNum,String BranchName, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetGatePassDetailIntoMCTDetailTemp";

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Value = GatePassNum;

                    param = cmd.Parameters.Add("@MCTReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 800);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String SaveMCRT(MCRT MCRT)
        {
            try
            {
                //save MCRT table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveMCRT";

                    param = cmd.Parameters.Add("@MCRTNum", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MCRT.RefNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MCRT.BranchName;

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MCRT.MRVNum;

                    param = cmd.Parameters.Add("@MRSNum", SqlDbType.VarChar, 20);
                    param.Value = MCRT.MRSNum;

                    param = cmd.Parameters.Add("@MCRTDate", SqlDbType.DateTime);
                    param.Value = MCRT.MCRTDate;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 20);
                    param.Value = MCRT.DeptCode;

                    param = cmd.Parameters.Add("@WONo", SqlDbType.VarChar, 20);
                    param.Value = MCRT.WONo;

                    param = cmd.Parameters.Add("@JONo", SqlDbType.VarChar, 20);
                    param.Value = MCRT.JONo;

                    param = cmd.Parameters.Add("@AwardedTo", SqlDbType.VarChar, 100);
                    param.Value = MCRT.AwardedTo;

                    param = cmd.Parameters.Add("@EmpID", SqlDbType.VarChar, 30);
                    param.Value = MCRT.EmpID;

                    param = cmd.Parameters.Add("@EmpType", SqlDbType.VarChar, 50);
                    param.Value = MCRT.EmpType;

                    param = cmd.Parameters.Add("@ReturnedBy", SqlDbType.VarChar, 500);
                    param.Value = MCRT.ReturnedBy;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewMCRTNum = Convert.ToString(cmd.Parameters["@MCRTNum"].Value.ToString());
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CancelMCRT(String ReferenceNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CancelMCRT";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String DeleteMCRT(String ReferenceNum, String MCRTNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_DeleteMCT";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@MCTNum", SqlDbType.VarChar, 20);
                    param.Value = MCRTNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String EditMCRT(String ReferenceNum, String MCRTNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_EditMCRT";

                    param = cmd.Parameters.Add("@MCRTNum", SqlDbType.VarChar, 20);
                    param.Value = MCRTNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateMCRT(MCRT MCRT)
        {
            try
            {
                //update MRV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateMCRT";

                    param = cmd.Parameters.Add("@MCRTNum", SqlDbType.VarChar, 20);
                    param.Value = MCRT.MCRTNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MCRT.RefNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MCRT.BranchName;

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MCRT.MRVNum;

                    param = cmd.Parameters.Add("@MRSNum", SqlDbType.VarChar, 20);
                    param.Value = MCRT.MRSNum;

                    param = cmd.Parameters.Add("@MCRTDate", SqlDbType.DateTime);
                    param.Value = MCRT.MCRTDate;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 20);
                    param.Value = MCRT.DeptCode;

                    param = cmd.Parameters.Add("@WONo", SqlDbType.VarChar, 20);
                    param.Value = MCRT.WONo;

                    param = cmd.Parameters.Add("@JONo", SqlDbType.VarChar, 20);
                    param.Value = MCRT.JONo;

                    param = cmd.Parameters.Add("@AwardedTo", SqlDbType.VarChar, 100);
                    param.Value = MCRT.AwardedTo;

                    param = cmd.Parameters.Add("@EmpID", SqlDbType.VarChar, 30);
                    param.Value = MCRT.EmpID;

                    param = cmd.Parameters.Add("@EmpType", SqlDbType.VarChar, 50);
                    param.Value = MCRT.EmpType;

                    param = cmd.Parameters.Add("@ReturnedBy", SqlDbType.VarChar, 500);
                    param.Value = MCRT.ReturnedBy;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;


                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MCRT> GetMCRTList(String Param, String Flag)
        {
            List<MCRT> MCRTList = new List<MCRT>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMCRT";

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MCRTList.Add(new MCRT()
                                {
                                    MCRTNum = Convert.ToString(dr["MCRTNum"].ToString())
                                    ,MCRTDate = Convert.ToDateTime(dr["MCRTDate"].ToString())
                                    
                                   
                                    ,
                                    MCRTStatus = Convert.ToString(dr["Status"].ToString())

                                    ,
                                    MRVNum = Convert.ToString(dr["MRVNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                     ,
                                    PreparedBy = String.IsNullOrEmpty(dr["PreparedBy"].ToString()) ? "" : dr["PreparedBy"].ToString()
                                       ,
                                    UserAccount = String.IsNullOrEmpty(dr["AccountUse"].ToString()) ? "" : dr["AccountUse"].ToString()
                                    ,BranchName = String.IsNullOrEmpty(dr["BranchName"].ToString()) ? "" : dr["BranchName"].ToString()
                                       ,
                                    ReturnedBy = String.IsNullOrEmpty(dr["ReturnedBy"].ToString()) ? "" : dr["ReturnedBy"].ToString()
                                });
                            }
                        }
                    }

                }
                return MCRTList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MCRT> GetMCRTList_ByDepartment(String DeptCode, String Param, String Flag)
        {
            List<MCRT> MCRTList = new List<MCRT>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMCRT_ByDepartment";

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MCRTList.Add(new MCRT()
                                {
                                    MCRTNum = Convert.ToString(dr["MCRTNum"].ToString())
                                    ,
                                    MCRTDate = Convert.ToDateTime(dr["MCRTDate"].ToString())


                                    ,
                                    MCRTStatus = Convert.ToString(dr["Status"].ToString())

                                    ,
                                    MRVNum = Convert.ToString(dr["MRVNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                     ,
                                    PreparedBy = String.IsNullOrEmpty(dr["PreparedBy"].ToString()) ? "" : dr["PreparedBy"].ToString()
                                       ,
                                    UserAccount = String.IsNullOrEmpty(dr["AccountUse"].ToString()) ? "" : dr["AccountUse"].ToString()
                                    ,
                                    BranchName = String.IsNullOrEmpty(dr["BranchName"].ToString()) ? "" : dr["BranchName"].ToString()
                                    ,
                                    ReturnedBy = String.IsNullOrEmpty(dr["ReturnedBy"].ToString()) ? "" : dr["ReturnedBy"].ToString()

                                });
                            }
                        }
                    }

                }
                return MCRTList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MCRTDetail> GetMCRTDetailList(String Param, String Flag)
        {
            List<MCRTDetail> MCRTDetailList = new List<MCRTDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMCRTDetail";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MCRTDetailList.Add(new MCRTDetail()
                                {
                                   
                                    MCRTNum = Convert.ToString(dr["MCRTNum"].ToString())
                                    ,
                                    MCRTDetailNum = Convert.ToInt32(dr["MCRTDetailNum"].ToString())
                                    ,   
                                    MCRTDate = Convert.ToDateTime(dr["MCRTDate"].ToString())
                                    ,


                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                  
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                   

                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                   
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                  
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                  
                                  
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,
                                    UnitSingular = Convert.ToString(dr["Unit"].ToString())
                            
                                    ,BranchName = Convert.ToString(dr["BranchName"].ToString())
                                    ,ReturnedBy = Convert.ToString(dr["ReturnedBy"].ToString())
                                });
                            }
                        }
                    }

                }
                return MCRTDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MCRTDetail> GetMCRTDetailList_TempTable(String Param, String Flag)
        {
            List<MCRTDetail> MCRTDetailList = new List<MCRTDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMCRTDetail_Temp";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MCRTDetailList.Add(new MCRTDetail()
                                {

                                    
                                    RefNum = Convert.ToString(dr["RefNum"].ToString())
                                    //,
                                    //DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    // Month = Convert.ToString(dr["Month"].ToString())
                                    //  ,
                                    // Year = Convert.ToString(dr["Year"].ToString())
                                    //   ,
                                    // Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                    //   ,
                                    // EmpID = Convert.ToString(dr["EmpID"].ToString())

                                    //,
                                    // EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    // ,
                                    // WONo = Convert.ToString(dr["WONo"].ToString())
                                    // ,
                                    // JONo = Convert.ToString(dr["JONo"].ToString())
                                    //  ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                      ,
                                    //MRVDate = Convert.ToDateTime(dr["MRVDate"].ToString())
                                    //  ,
                                    //AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    //,
                                    //IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    //,
                                    //MRVStatus = Convert.ToString(dr["MRVStatus"].ToString())
                                    //    ,
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,
                                    MCRTDetailNum = Convert.ToInt32(dr["MCRTDetailNum"].ToString())
                                       ,
                                    Available = Convert.ToString(dr["Available"].ToString())
                                    ,
                                    UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                
                                });
                            }
                        }
                    }

                }
                return MCRTDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String AddMCRTItem(MCRTDetail MCRTDetail, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_AddMCRTItem";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MCRTDetail.RefNum;

                    param = cmd.Parameters.Add("@MCRTNum", SqlDbType.VarChar, 20);
                    param.Value = MCRTDetail.MCRTNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MCRTDetail.BranchName;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = MCRTDetail.ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = String.IsNullOrEmpty(MCRTDetail.ItemCode) ? "" : MCRTDetail.ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 1000);
                    param.Value = MCRTDetail.ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar, 1000);
                    param.Value = MCRTDetail.ProductDesc;

                    param = cmd.Parameters.Add("@UnitDesc", SqlDbType.VarChar, 20);
                    param.Value = MCRTDetail.Unit;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = MCRTDetail.Quantity;

                    param = cmd.Parameters.Add("@Purpose", SqlDbType.VarChar, 800);
                    param.Value = MCRTDetail.Purpose;

                    param = cmd.Parameters.Add("@Available", SqlDbType.VarChar, 1);
                    param.Value = String.IsNullOrEmpty(MCRTDetail.Available) ? "" : MCRTDetail.Available;

                    param = cmd.Parameters.Add("@IsReg", SqlDbType.VarChar, 1);
                    param.Value = MCRTDetail.IsReg;

                 
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateMCRTItem(MCRTDetail MCRTDetail)
        {
            try
            {
                //update MRV item in temp table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateMCRTItem";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = MCRTDetail.RefNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MCRTDetail.BranchName;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = MCRTDetail.ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = MCRTDetail.ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 1000);
                    param.Value = MCRTDetail.ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar, 1000);
                    param.Value = MCRTDetail.ProductDesc;

                    param = cmd.Parameters.Add("@Unit", SqlDbType.VarChar, 50);
                    param.Value = MCRTDetail.Unit;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = MCRTDetail.Quantity;

                    param = cmd.Parameters.Add("@Purpose", SqlDbType.VarChar, 800);
                    param.Value = MCRTDetail.Purpose;

                 

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CheckMCRTItemHasDetail(String ReferenceNum, Int32 ProductCode, String ItemCode, String ProductName, Decimal Quantity)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckMCRTItemHasDetail";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 1000);
                    param.Value = ProductName;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = Quantity;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 200);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<ProductView> GetMCRTItemThatHasDetail(String ReferenceNum, String Flag)
        {
            List<ProductView> ProductViewList = new List<ProductView>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMCRTItemThatHasDetail";
                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ProductViewList.Add(new ProductView()
                                {
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                    ,
                                    ItemCode = String.IsNullOrEmpty(dr["ItemCode"].ToString()) ? "" : dr["ItemCode"].ToString()
                                    ,

                                    ProductName = String.IsNullOrEmpty(dr["ProductName"].ToString()) ? "" : dr["ProductName"].ToString()
                                      ,

                                    Unit = String.IsNullOrEmpty(dr["Unit"].ToString()) ? "" : dr["Unit"].ToString()
                                       ,

                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                });
                            }
                        }
                    }

                }
                return ProductViewList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemoveMCRTItem(String MCRTNum, String ItemCode, String ReferenceNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_RemoveMCRTItem";

                    param = cmd.Parameters.Add("@MCRTNum", SqlDbType.VarChar, 20);
                    param.Value = MCRTNum;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String CheckMCRTOwner(String MCRTNum, Int32 UserID)
        {
            try
            {
                //save MRV Status
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckMCRTOwner";

                    param = cmd.Parameters.Add("@MCRTNum", SqlDbType.VarChar, 20);
                    param.Value = MCRTNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 200);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String SetMCRTCheckedStatus(String Action, String MCRTNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SetMCRTCheckedStatus";

                    param = cmd.Parameters.Add("@Action", SqlDbType.VarChar, 20);
                    param.Value = Action;

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 20);
                    param.Value = MCRTNum;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = "Status";

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MCRT> GetMCRTPerPeriodList(String Month, String Year, String BranchName, String Flag, String Param)
        {
            List<MCRT> MCRTList = new List<MCRT>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMCRTPerPeriod";

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = GlobalFunc.GetMonthNum(Month);

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 50);
                    param.Value = Param;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MCRTList.Add(new MCRT()
                                {
                                    MCRTNum = Convert.ToString(dr["MCRTNum"].ToString())
                                    ,
                                    MCRTDate = Convert.ToDateTime(dr["MCRTDate"].ToString())

                                    ,
                                   

                                 
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                     ,
                                    //Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                    //   ,
                                    UserAccount = String.IsNullOrEmpty(dr["AccountUse"].ToString()) ? "" : dr["AccountUse"].ToString()
                                    ,
                                    BranchName = String.IsNullOrEmpty(dr["BranchName"].ToString()) ? "" : dr["BranchName"].ToString()
                                    ,
                                    TotalCost = Convert.ToDecimal(dr["TotalCost"].ToString())
                                    ,
                                    Checked = Convert.ToString(dr["Checked"].ToString())
                                });
                            }
                        }
                    }


                }
                return MCRTList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<MCRTDetail> GetMCRTDetailListPerPeriod(String Param, String Month, String Year, String Flag)
        {
            List<MCRTDetail> MCRTDetailList = new List<MCRTDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMCRTDetailPerPeriod";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = GlobalFunc.GetMonthNum(Month);

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MCRTDetailList.Add(new MCRTDetail()
                                {
                                    MCRTDate = Convert.ToDateTime(dr["MCRTDate"].ToString())
                                    ,
                                    MCRTNum = Convert.ToString(dr["MCRTNum"].ToString())
                                    ,
                                    MCRTDetailNum = Convert.ToInt32(dr["MCRTDetailNum"].ToString())
                                    ,
                                    //AcctCode = Convert.ToString(dr["AcctCode"].ToString())
                                    //,
                                    //AcctDesc = Convert.ToString(dr["AcctDesc"].ToString())
                                    //,
                                    //ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    //,
                                    //MRVNum = Convert.ToString(dr["MRVNum"].ToString())
                                    //,
                                    //GatePassNum = Convert.ToString(dr["GatePassNum"].ToString())
                                    //,
                                    //MRVDate = Convert.ToString(dr["MRVDate"].ToString())
                                    //,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                      ,

                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    

                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,

                                   
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,
                                    UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                        ,
                                  
                                  
                                    //ReceivedBy = Convert.ToString(dr["ReceivedBy"].ToString())
                                    //,
                                    BranchName = Convert.ToString(dr["BranchName"].ToString())
                                       ,
                                    UnitCost = Convert.ToDecimal(dr["UnitCost"].ToString())

                                });
                            }
                        }
                    }

                }
                return MCRTDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }

        }
        public String SavedTransactionClose(String TransType, String Month, String Year)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveTransactionClose";

                    param = cmd.Parameters.Add("@TransType", SqlDbType.VarChar, 50);
                    param.Value = TransType;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String CheckMCRTCheckedMark(String Month, string Year, String BranchName)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckMCRTCheckedMark";

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String DeleteMCRT(String MCRTNum, String Status,String BranchName, String Remarks, String Notes)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_DeleteMCRT";

                    param = cmd.Parameters.Add("@MCRTNum", SqlDbType.VarChar, 20);
                    param.Value = MCRTNum;

                    param = cmd.Parameters.Add("@MCRTStatus", SqlDbType.VarChar, 50);
                    param.Value = Status;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 200);
                    param.Value = Remarks;

                    param = cmd.Parameters.Add("@Notes", SqlDbType.VarChar, 200);
                    param.Value = Notes;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
    }
}
