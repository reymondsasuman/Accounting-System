﻿using anecoacct.WareHouseModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseClass
{
    class CanvassMatrixQueries
    {
        public List<CanvassSheetMatrix> GetCanvassSheetMatrixList(String CanvassSheetNum, String SupplierName, String Flag)
        {
            List<CanvassSheetMatrix> CanvassSheetMatrixtList = new List<CanvassSheetMatrix>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetCanvassMatrix";

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheetNum;

                    param = cmd.Parameters.Add("@SupplierName", SqlDbType.VarChar, 1000);
                    param.Value = SupplierName;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                CanvassSheetMatrixtList.Add(new CanvassSheetMatrix()
                                {
                                    CanvassMatrixNum = Convert.ToInt32(dr["CanvassMatrixNum"].ToString())
                                    ,
                                    CanvassSheetDetailNum = Convert.ToInt32(dr["CanvassSheetDetailNum"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                    ,
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                    ,
                                    ProductDesc = String.IsNullOrEmpty(dr["ProductDesc"].ToString()) ? "" : dr["ProductDesc"].ToString()
                                   ,
                                    Quantity = String.IsNullOrEmpty(dr["Quantity"].ToString()) ? 0 : Convert.ToDecimal(dr["Quantity"].ToString())
                                     ,
                                    Unit = String.IsNullOrEmpty(dr["Unit"].ToString()) ? "" : Convert.ToString(dr["Unit"].ToString())
 ,
                                    SupplierNo = String.IsNullOrEmpty(dr["SupplierNo"].ToString()) ? 0 : Convert.ToInt32(dr["SupplierNo"].ToString())
 ,
                                    UnitCost = String.IsNullOrEmpty(dr["UnitCost"].ToString()) ? 0 : Convert.ToDecimal(dr["UnitCost"].ToString())
 ,
                                    TotalCost = String.IsNullOrEmpty(dr["TotalCost"].ToString()) ? 0 : Convert.ToDecimal(dr["TotalCost"].ToString())

                                     ,
                                    RIVDetailNum = Convert.ToInt32(dr["RIVDetailNum"].ToString())
                                    ,VatType = Convert.ToString(dr["VatType"].ToString())
                                });
                            }
                        }
                    }

                }
                return CanvassSheetMatrixtList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String UpdateCanvassSheetMatrix(CanvassSheetMatrix CanvassSheetMatrix)
        {          
            try
            {
                String Message = "";
                using (SqlCommand cmd = new SqlCommand())
                {
                    
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateCanvassMatrix";

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheetMatrix.CanvassSheetNum;

                    param = cmd.Parameters.Add("@CanvassSheetDetailNum", SqlDbType.Int);
                    param.Value = CanvassSheetMatrix.CanvassSheetDetailNum;

                    param = cmd.Parameters.Add("@RIVDetailNum", SqlDbType.Int);
                    param.Value = CanvassSheetMatrix.RIVDetailNum;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = CanvassSheetMatrix.ProductCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar,500);
                    param.Value = CanvassSheetMatrix.ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar, 500);
                    param.Value = CanvassSheetMatrix.ProductDesc;

                    param = cmd.Parameters.Add("@SupplierNo", SqlDbType.Int);
                    param.Value = CanvassSheetMatrix.SupplierNo;

                    param = cmd.Parameters.Add("@UnitCost", SqlDbType.Decimal);
                    param.Scale =6;
                    param.Precision = 18;
                    param.Value = CanvassSheetMatrix.UnitCost;

                    param = cmd.Parameters.Add("@TotalCost", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = CanvassSheetMatrix.TotalCost;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar,500);
                    param.Direction = ParameterDirection.Output;
                    cmd.ExecuteNonQuery();
                    Message= Convert.ToString(cmd.Parameters["@Message"].Value.ToString());
                }
                return Message;
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<CanvassSheetMatrixListSuppliers> GetCanvassSheetMatrixListSuppliers(String Param, String Flag)
        {
            try
            {
                List<CanvassSheetMatrixListSuppliers> CanvassSheetMatrixListSuppliersList = new List<CanvassSheetMatrixListSuppliers>();
                using (SqlCommand cmd= new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetCanvassMatrixListSuppliers";

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 20);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar,20);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                CanvassSheetMatrixListSuppliersList.Add(new CanvassSheetMatrixListSuppliers
                                {
                                    RIVNum = Convert.ToString(dr["RIVNum"].ToString())
                                    ,
                                    CanvassSheetNum = Convert.ToString(dr["CanvassSheetNum"].ToString())
                                    ,
                                    SupplierName = Convert.ToString(dr["SupplierName"].ToString())
                                    ,
                                    TotalCost = Convert.ToDecimal(dr["TotalCost"].ToString())
                                  
                                });
                            }      
                        }
                    }


                }
                return CanvassSheetMatrixListSuppliersList;
            }
            catch (Exception)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

    }
}
