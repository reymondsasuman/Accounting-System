﻿using anecoacct.WareHouseModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseClass
{
    class JORCanvassMatrixQueries
    {
        public List<JORCanvassSheetMatrix> GetCanvassSheetMatrixList(String CanvassSheetNum, String SupplierName, String Flag)
        {
            List<JORCanvassSheetMatrix> JORCanvassSheetMatrixtList = new List<JORCanvassSheetMatrix>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetJORCanvassMatrix";

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheetNum;

                    param = cmd.Parameters.Add("@SupplierName", SqlDbType.VarChar, 1000);
                    param.Value = SupplierName;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                JORCanvassSheetMatrixtList.Add(new JORCanvassSheetMatrix()
                                {
                                    CanvassMatrixNum = Convert.ToInt32(dr["CanvassMatrixNum"].ToString())
                                    ,
                                    CanvassSheetDetailNum = Convert.ToInt32(dr["CanvassSheetDetailNum"].ToString())
                                    ,
                                    Scope = String.IsNullOrEmpty(dr["Scope"].ToString()) ? "" : dr["Scope"].ToString()
                                   ,
                                    JobOrderDesc = String.IsNullOrEmpty(dr["JobOrderDesc"].ToString()) ? "" : dr["JobOrderDesc"].ToString()
                                   ,
                                    Quantity = String.IsNullOrEmpty(dr["Quantity"].ToString()) ? 0 : Convert.ToDecimal(dr["Quantity"].ToString())
                                     ,
                                    Unit = String.IsNullOrEmpty(dr["Unit"].ToString()) ? "" : Convert.ToString(dr["Unit"].ToString())
 ,
                                    SupplierNo = String.IsNullOrEmpty(dr["SupplierNo"].ToString()) ? 0 : Convert.ToInt32(dr["SupplierNo"].ToString())
 ,
                                    UnitCost = String.IsNullOrEmpty(dr["UnitCost"].ToString()) ? 0 : Convert.ToDecimal(dr["UnitCost"].ToString())
 ,
                                    LaborCost = String.IsNullOrEmpty(dr["LaborCost"].ToString()) ? 0 : Convert.ToDecimal(dr["LaborCost"].ToString())
 ,

                                    TotalCost = String.IsNullOrEmpty(dr["TotalCost"].ToString()) ? 0 : Convert.ToDecimal(dr["TotalCost"].ToString())

                                     ,
                                    JORDetailNum = Convert.ToInt32(dr["JORDetailNum"].ToString())
                                });
                            }
                        }
                    }

                }
                return JORCanvassSheetMatrixtList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String UpdateCanvassSheetMatrix(JORCanvassSheetMatrix JORCanvassSheetMatrix)
        {          
            try
            {
                String Message = "";
                using (SqlCommand cmd = new SqlCommand())
                {
                    
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateJORCanvassMatrix";

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = JORCanvassSheetMatrix.CanvassSheetNum;

                    param = cmd.Parameters.Add("@CanvassSheetDetailNum", SqlDbType.Int);
                    param.Value = JORCanvassSheetMatrix.CanvassSheetDetailNum;

                    param = cmd.Parameters.Add("@JORDetailNum", SqlDbType.Int);
                    param.Value = JORCanvassSheetMatrix.JORDetailNum;

                    param = cmd.Parameters.Add("@JobOrderDesc", SqlDbType.VarChar, 500);
                    param.Value = JORCanvassSheetMatrix.JobOrderDesc;

                    param = cmd.Parameters.Add("@SupplierNo", SqlDbType.Int);
                    param.Value = JORCanvassSheetMatrix.SupplierNo;

                    param = cmd.Parameters.Add("@UnitCost", SqlDbType.Decimal);
                    param.Scale =6;
                    param.Precision = 18;
                    param.Value = JORCanvassSheetMatrix.UnitCost;

                    param = cmd.Parameters.Add("@LaborCost", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = JORCanvassSheetMatrix.LaborCost;

                    param = cmd.Parameters.Add("@TotalCost", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = JORCanvassSheetMatrix.TotalCost;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar,500);
                    param.Direction = ParameterDirection.Output;
                    cmd.ExecuteNonQuery();
                    Message= Convert.ToString(cmd.Parameters["@Message"].Value.ToString());
                }
                return Message;
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<JORCanvassSheetMatrixListSuppliers> GetJORCanvassSheetMatrixListSuppliers(String Param, String Flag)
        {
            try
            {
                List<JORCanvassSheetMatrixListSuppliers> JORCanvassSheetMatrixListSuppliersList = new List<JORCanvassSheetMatrixListSuppliers>();
                using (SqlCommand cmd= new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetJORCanvassMatrixListSuppliers";

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 20);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar,20);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                JORCanvassSheetMatrixListSuppliersList.Add(new JORCanvassSheetMatrixListSuppliers
                                {
                                    JORNum = Convert.ToString(dr["JORNum"].ToString())
                                    ,
                                    CanvassSheetNum = Convert.ToString(dr["CanvassSheetNum"].ToString())
                                    ,
                                    SupplierName = Convert.ToString(dr["SupplierName"].ToString())
                                    ,
                                    TotalCost = Convert.ToDecimal(dr["TotalCost"].ToString())
                                     ,
                                    SupplierNo = Convert.ToInt32(dr["SupplierNo"].ToString())
                                     ,
                                    SupplierAddress = Convert.ToString(dr["Address"].ToString())
                                     ,
                                    SupplierTIN = Convert.ToString(dr["TIN"].ToString())
                                    ,VAT = Convert.ToDecimal(dr["VAT"].ToString())
                                       ,
                                    DeptCode = Convert.ToString(dr["DeptCode"].ToString())
                                });
                            }      
                        }
                    }


                }
                return JORCanvassSheetMatrixListSuppliersList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

    }
}
