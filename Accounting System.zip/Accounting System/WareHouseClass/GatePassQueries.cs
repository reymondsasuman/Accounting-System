﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using anecoacct.WareHouseModel;
using System.Data.SqlClient;
using System.Windows.Forms;
using anecoacct.WareHouseClass;

namespace anecoacct.WareHouseClass
{
    class GatePassQueries
    {
        OtherQueries OtherQueries = new OtherQueries();
        frmWareHouseMRV frmWareHouseMRV = (frmWareHouseMRV)Application.OpenForms["frmWareHouseMRV"];
        public String EditMRVGatePass (String ReferenceNum, String GatePassNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_EditMRVGatePass";

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Value = GatePassNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String EditMTRVGatePass(String ReferenceNum, String GatePassNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_EditMTRVGatePass";

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Value = GatePassNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String SaveMRVStatus(String MRVNum,String Status, String Remarks, String Notes )
        {
            try
            {
                //save MRV Status
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveMRVStatus";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@MRVStatus", SqlDbType.VarChar, 50);
                    param.Value = Status;

                    param = cmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 200);
                    param.Value = Remarks;

                    param = cmd.Parameters.Add("@Notes", SqlDbType.VarChar, 200);
                    param.Value = Notes;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }  

        public String SaveMRVGatePass(MRVGatePass MRVGatePass)
        {
            try
            {
                //save MRV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveMRVGatePass";

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MRVGatePass.ReferenceNum;

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVGatePass.MRVNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar,100);
                    param.Value = MRVGatePass.BranchName;

                    param = cmd.Parameters.Add("@GatePassDate", SqlDbType.DateTime);
                    param.Value = MRVGatePass.GatePassDate;

                    param = cmd.Parameters.Add("@WONo", SqlDbType.VarChar, 20);
                    param.Value = MRVGatePass.WONo;

                    param = cmd.Parameters.Add("@JONo", SqlDbType.VarChar, 20);
                    param.Value = MRVGatePass.JONo;

                    param = cmd.Parameters.Add("@AwardedTo", SqlDbType.VarChar, 100);
                    param.Value = MRVGatePass.AwardedTo;

                    param = cmd.Parameters.Add("@ReceivedBy", SqlDbType.VarChar, 500);
                    param.Value = MRVGatePass.ReceivedBy;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewGatePassNum = Convert.ToString(cmd.Parameters["@GatePassNum"].Value.ToString());
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
                return "";
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String SaveMTRVGatePass(MTRVGatePass MTRVGatePass)
        {
            try
            {
                //save MRV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveMTRVGatePass";

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MTRVGatePass.ReferenceNum;

                    param = cmd.Parameters.Add("@MTRVNum", SqlDbType.VarChar, 20);
                    param.Value = MTRVGatePass.MTRVNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MTRVGatePass.BranchName;

                    param = cmd.Parameters.Add("@GatePassDate", SqlDbType.DateTime);
                    param.Value = MTRVGatePass.GatePassDate;

                    param = cmd.Parameters.Add("@WONo", SqlDbType.VarChar, 20);
                    param.Value = MTRVGatePass.WONo;

                    param = cmd.Parameters.Add("@JONo", SqlDbType.VarChar, 20);
                    param.Value = MTRVGatePass.JONo;

                    param = cmd.Parameters.Add("@AwardedTo", SqlDbType.VarChar, 100);
                    param.Value = MTRVGatePass.AwardedTo;

                    param = cmd.Parameters.Add("@ReceivedBy", SqlDbType.VarChar, 500);
                    param.Value = MTRVGatePass.ReceivedBy;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewGatePassNum = Convert.ToString(cmd.Parameters["@GatePassNum"].Value.ToString());
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
                return "";
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateMRVGatePass(MRVGatePass MRVGatePass)
        {
            try
            {
                //save MRV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateMRVGatePass";

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Value = MRVGatePass.GatePassNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MRVGatePass.ReferenceNum;

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVGatePass.MRVNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MRVGatePass.BranchName;

                    param = cmd.Parameters.Add("@GatePassDate", SqlDbType.DateTime);
                    param.Value = MRVGatePass.GatePassDate;


                    param = cmd.Parameters.Add("@WONo", SqlDbType.VarChar, 20);
                    param.Value = MRVGatePass.WONo;

                    param = cmd.Parameters.Add("@JONo", SqlDbType.VarChar, 20);
                    param.Value = MRVGatePass.JONo;

                    param = cmd.Parameters.Add("@AwardedTo", SqlDbType.VarChar, 100);
                    param.Value = MRVGatePass.AwardedTo;

                    param = cmd.Parameters.Add("@ReceivedBy", SqlDbType.VarChar, 500);
                    param.Value = MRVGatePass.ReceivedBy;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;


                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateMTRVGatePass(MTRVGatePass MTRVGatePass)
        {
            try
            {
                //save MRV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateMTRVGatePass";

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Value = MTRVGatePass.GatePassNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MTRVGatePass.ReferenceNum;

                    param = cmd.Parameters.Add("@MTRVNum", SqlDbType.VarChar, 20);
                    param.Value = MTRVGatePass.MTRVNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MTRVGatePass.BranchName;

                    param = cmd.Parameters.Add("@GatePassDate", SqlDbType.DateTime);
                    param.Value = MTRVGatePass.GatePassDate;

                    param = cmd.Parameters.Add("@WONo", SqlDbType.VarChar, 20);
                    param.Value = MTRVGatePass.WONo;

                    param = cmd.Parameters.Add("@JONo", SqlDbType.VarChar, 20);
                    param.Value = MTRVGatePass.JONo;

                    param = cmd.Parameters.Add("@AwardedTo", SqlDbType.VarChar, 100);
                    param.Value = MTRVGatePass.AwardedTo;

                    param = cmd.Parameters.Add("@ReceivedBy", SqlDbType.VarChar, 500);
                    param.Value = MTRVGatePass.ReceivedBy;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;


                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MRV> GetMRVList(String Param, String Flag)
        {
            List<MRV> MRVList = new List<MRV>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMRV";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MRVList.Add(new MRV()
                                {
                                    MRVNum = Convert.ToString(dr["MRVNum"].ToString())
                                    ,
                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                     ,
                                    GMLevel = String.IsNullOrEmpty(dr["GMLevel"].ToString()) ? "" : dr["GMLevel"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    //Purpose = Convert.ToString(dr["Purpose"].ToString())
                                    //  ,
                                    MRVDate = Convert.ToDateTime(dr["MRVDate"].ToString())
                                      ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    ,
                                    MRVStatus = Convert.ToString(dr["MRVStatus"].ToString())
                                        ,
                                    UserAccount = Convert.ToString(dr["AccountUse"].ToString())
                                });
                            }
                        }
                    }

                }
                return MRVList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MRV> GetMRVList_ByStatus(String Status,String Param, String Flag)
        {
            List<MRV> MRVList = new List<MRV>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMRV_ByStatus";
                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar, 100);
                    param.Value = Status;
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MRVList.Add(new MRV()
                                {
                                    MRVNum = Convert.ToString(dr["MRVNum"].ToString())
                                    ,
                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    //Purpose = Convert.ToString(dr["Purpose"].ToString())
                                    //  ,
                                    MRVDate = Convert.ToDateTime(dr["MRVDate"].ToString())
                                      ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    ,
                                    MRVStatus = Convert.ToString(dr["MRVStatus"].ToString())
                                        ,
                                    UserAccount = Convert.ToString(dr["AccountUse"].ToString())
                                });
                            }
                        }
                    }

                }
                return MRVList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<MRVGatePassDetail> GetMRVGatePassDetailList(String Param, String Flag,String TransType)
        {
            List<MRVGatePassDetail> MRVGatePassDetailList = new List<MRVGatePassDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetGatePassDetail";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    param = cmd.Parameters.Add("@TransType", SqlDbType.VarChar, 100);
                    param.Value = TransType;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MRVGatePassDetailList.Add(new MRVGatePassDetail()
                                {
                                    MRVNum = Convert.ToString(dr["MRVNum"].ToString())
                                    ,
                                    GatePassNum = Convert.ToString(dr["GatePassNum"].ToString())
                                    ,
                                    GatePassDetailNum = Convert.ToInt32(dr["GatePassDetailNum"].ToString())
                                    ,
                                    GatePassDate = Convert.ToDateTime(dr["GatePassDate"].ToString())
                                      ,
                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    BranchName = String.IsNullOrEmpty(dr["BranchName"].ToString()) ? "" : dr["BranchName"].ToString()
                                     ,
                                    BranchName_Source = String.IsNullOrEmpty(dr["BranchName_Source"].ToString()) ? "" : dr["BranchName_Source"].ToString()
                                     ,
                                    BranchName_Destination = String.IsNullOrEmpty(dr["BranchName_Destination"].ToString()) ? "" : dr["BranchName_Destination"].ToString()
                                    ,
                                    GMLevel = String.IsNullOrEmpty(dr["GMLevel"].ToString()) ? "" : dr["GMLevel"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                      ,
                                    MRVDate = Convert.ToString(dr["MRVDate"].ToString())
                                      ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                  
                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    ,
                                    MRVStatus = Convert.ToString(dr["MRVStatus"].ToString())
                                         ,
                                    ItemCode= Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,
                                    UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                        ,
                                    MRVDetailNum = Convert.ToInt32(dr["MRVDetailNum"].ToString())
                                       ,
                                    Available = Convert.ToString(dr["Available"].ToString())
                                       ,
                                     
                                    SubClassID = Convert.ToInt32(dr["SubClassID"].ToString())
                                    ,
                                    ProjectType = Convert.ToString(dr["ProjectType"].ToString())
                                                                        ,
                                    ProjectClass = Convert.ToString(dr["ProjectClass"].ToString())
                                                                        ,
                                    SubClass = Convert.ToString(dr["SubClass"].ToString())
                                                                        ,
                                    SubClassDesc = Convert.ToString(dr["SubClassDesc"].ToString())
                                    ,ReceivedBy = Convert.ToString(dr["ReceivedBy"].ToString())
                                });
                            }
                        }
                    }

                }
                return MRVGatePassDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MTRVGatePassDetail> GetMTRVGatePassDetailList(String Param, String Flag,String TransType)
        {
            List<MTRVGatePassDetail> MTRVGatePassDetailList = new List<MTRVGatePassDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetGatePassDetail";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    param = cmd.Parameters.Add("@TransType", SqlDbType.VarChar, 50);
                    param.Value = TransType;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MTRVGatePassDetailList.Add(new MTRVGatePassDetail()
                                {
                                    MTRVNum = Convert.ToString(dr["MTRVNum"].ToString())
                                    ,
                                    GatePassNum = Convert.ToString(dr["GatePassNum"].ToString())
                                    ,
                                    GatePassDetailNum = Convert.ToInt32(dr["GatePassDetailNum"].ToString())
                                    ,
                                    GatePassDate = Convert.ToDateTime(dr["GatePassDate"].ToString())
                                      ,
                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    BranchName = String.IsNullOrEmpty(dr["BranchName"].ToString()) ? "" : dr["BranchName"].ToString()
                                     ,
                                    BranchName_Source = String.IsNullOrEmpty(dr["BranchName_Source"].ToString()) ? "" : dr["BranchName_Source"].ToString()
                                     ,
                                    BranchName_Destination = String.IsNullOrEmpty(dr["BranchName_Destination"].ToString()) ? "" : dr["BranchName_Destination"].ToString()

                                    ,
                                    GMLevel = String.IsNullOrEmpty(dr["GMLevel"].ToString()) ? "" : dr["GMLevel"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                      ,
                                    MTRVDate = Convert.ToString(dr["MTRVDate"].ToString())
                                      ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,

                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    ,
                                    MTRVStatus = Convert.ToString(dr["MTRVStatus"].ToString())
                                         ,
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,
                                    UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                        ,
                                    MTRVDetailNum = Convert.ToInt32(dr["TransDetailNum"].ToString())
                                       ,
                                    Available = Convert.ToString(dr["Available"].ToString())
                                       ,

                                    SubClassID = Convert.ToInt32(dr["SubClassID"].ToString())
                                    ,
                                    ProjectType = Convert.ToString(dr["ProjectType"].ToString())
                                                                        ,
                                    ProjectClass = Convert.ToString(dr["ProjectClass"].ToString())
                                                                        ,
                                    SubClass = Convert.ToString(dr["SubClass"].ToString())
                                                                        ,
                                    SubClassDesc = Convert.ToString(dr["SubClassDesc"].ToString())
                                    ,
                                    ReceivedBy = Convert.ToString(dr["ReceivedBy"].ToString())
                                });
                            }
                        }
                    }

                }
                return MTRVGatePassDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }


        public List<MRVGatePassDetail> GetMRVGatePassDetailList_Temp(String Param, String Flag,String TransType,String ReferenceNum)
        {
            List<MRVGatePassDetail> MRVGatePassDetailList = new List<MRVGatePassDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetGatePassDetail_Temp";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                   
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    
                    param = cmd.Parameters.Add("@TransType", SqlDbType.VarChar, 100);
                    param.Value = TransType;

                    param = cmd.Parameters.Add("@GatePassReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MRVGatePassDetailList.Add(new MRVGatePassDetail()
                                {
                                    MRVNum = Convert.ToString(dr["MRVNum"].ToString())
                                    ,
                                    //GatePassNum = Convert.ToString(dr["GatePassNum"].ToString())
                                    //,
                                    //GatePassDetailNum = Convert.ToInt32(dr["GatePassDetailNum"].ToString())
                                    //,
                                    //GatePassDate = Convert.ToDateTime(dr["GatePassDate"].ToString())
                                    //  ,
                                    //RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    //,
                                    //DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    //,
                                    //GMLevel = String.IsNullOrEmpty(dr["GMLevel"].ToString()) ? "" : dr["GMLevel"].ToString()
                                    //,
                                    //Month = Convert.ToString(dr["Month"].ToString())
                                    // ,
                                    //Year = Convert.ToString(dr["Year"].ToString())
                                    //  ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                      ,
                                    MRVDate = Convert.ToString(dr["MRVDate"].ToString())
                                      ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,

                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    ,
                                    MRVStatus = Convert.ToString(dr["MRVStatus"].ToString())
                                         ,
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,
                                    UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                        ,
                                    MRVDetailNum = Convert.ToInt32(dr["MRVDetailNum"].ToString())
                                       ,
                                    Available = Convert.ToString(dr["Available"].ToString())
                                       ,

                                    SubClassID = Convert.ToInt32(dr["SubClassID"].ToString())
                                    ,
                                    ProjectType = Convert.ToString(dr["ProjectType"].ToString())
                                                                        ,
                                    ProjectClass = Convert.ToString(dr["ProjectClass"].ToString())
                                                                        ,
                                    SubClass = Convert.ToString(dr["SubClass"].ToString())
                                                                        ,
                                    SubClassDesc = Convert.ToString(dr["SubClassDesc"].ToString())
                                    //,
                                    //ReceivedBy = Convert.ToString(dr["ReceivedBy"].ToString())
                                });
                            }
                        }
                    }

                }
                return MRVGatePassDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MTRVGatePassDetail> GetMTRVGatePassDetailList_Temp(String Param, String Flag, String TransType, String ReferenceNum)
        {
            List<MTRVGatePassDetail> MTRVGatePassDetailList = new List<MTRVGatePassDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetGatePassDetail_Temp";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@TransType", SqlDbType.VarChar, 100);
                    param.Value = TransType;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MTRVGatePassDetailList.Add(new MTRVGatePassDetail()
                                {
                                    MTRVNum = Convert.ToString(dr["MTRVNum"].ToString())
                                    ,
                                    //GatePassNum = Convert.ToString(dr["GatePassNum"].ToString())
                                    //,
                                    //GatePassDetailNum = Convert.ToInt32(dr["GatePassDetailNum"].ToString())
                                    //,
                                    //GatePassDate = Convert.ToDateTime(dr["GatePassDate"].ToString())
                                    //  ,
                                    //RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    //,
                                    //DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    //,
                                    //GMLevel = String.IsNullOrEmpty(dr["GMLevel"].ToString()) ? "" : dr["GMLevel"].ToString()
                                    //,
                                    //Month = Convert.ToString(dr["Month"].ToString())
                                    // ,
                                    //Year = Convert.ToString(dr["Year"].ToString())
                                    //  ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                      ,
                                    MTRVDate = Convert.ToString(dr["MTRVDate"].ToString())
                                      ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,

                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    ,
                                    MTRVStatus = Convert.ToString(dr["MTRVStatus"].ToString())
                                         ,
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,
                                    UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                        ,
                                    MTRVDetailNum = Convert.ToInt32(dr["MTRVDetailNum"].ToString())
                                       ,
                                    Available = Convert.ToString(dr["Available"].ToString())
                                       ,

                                    SubClassID = Convert.ToInt32(dr["SubClassID"].ToString())
                                    ,
                                    ProjectType = Convert.ToString(dr["ProjectType"].ToString())
                                                                        ,
                                    ProjectClass = Convert.ToString(dr["ProjectClass"].ToString())
                                                                        ,
                                    SubClass = Convert.ToString(dr["SubClass"].ToString())
                                                                        ,
                                    SubClassDesc = Convert.ToString(dr["SubClassDesc"].ToString())
                                    //,
                                    //ReceivedBy = Convert.ToString(dr["ReceivedBy"].ToString())
                                });
                            }
                        }
                    }

                }
                return MTRVGatePassDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String GetMRVDetailIntoMRVGatePassDetailTemp(String MRVNum, String ReferenceNum, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMRVDetailIntoMRVGatePassDetailTemp";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@GatePassReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 800);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String GetMTRVDetailIntoMTRVGatePassDetailTemp(String MTRVNum, String ReferenceNum, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMTRVDetailIntoMTRVGatePassDetailTemp";

                    param = cmd.Parameters.Add("@MTRVNum", SqlDbType.VarChar, 20);
                    param.Value = MTRVNum;

                    param = cmd.Parameters.Add("@GatePassReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 800);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        //public List<CanvassSheetDetail> GetCanvassSheetDetailList(String Param, String Flag)
        //{
        //    List<CanvassSheetDetail> CanvassSheetDetailList = new List<CanvassSheetDetail>();
        //    try
        //    {
        //        using (SqlCommand cmd = new SqlCommand())
        //        {
        //            cmd.Connection = DatabaseConnection.cnn;
        //            DatabaseConnection.Connect();
        //            SqlParameter param = new SqlParameter();
        //            cmd.CommandTimeout = 6000;
        //            cmd.CommandType = CommandType.StoredProcedure;
        //            cmd.CommandText = "warehouse.sp_GetMRVDetail";
        //            param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
        //            param.Value = Param;
        //            param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
        //            param.Value = Flag;
        //            using (SqlDataReader dr = cmd.ExecuteReader())
        //            {
        //                if (dr.HasRows)
        //                {
        //                    while (dr.Read())
        //                    {
        //                        CanvassSheetDetailList.Add(new CanvassSheetDetail()
        //                        {
        //                            MRVNum = Convert.ToString(dr["MRVNum"].ToString())
        //                            ,
        //                            RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
        //                            ,
        //                            DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
        //                            ,
        //                            Month = Convert.ToString(dr["Month"].ToString())
        //                             ,
        //                            Year = Convert.ToString(dr["Year"].ToString())
        //                              ,
        //                            Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
        //                              ,
        //                            EmpID = Convert.ToString(dr["EmpID"].ToString())

        //                           ,
        //                            EmpType = Convert.ToString(dr["EmpType"].ToString())
        //                            ,
        //                            WONo = Convert.ToString(dr["WONo"].ToString())
        //                            ,
        //                            JONo = Convert.ToString(dr["JONo"].ToString())
        //                             ,
        //                            Purpose = Convert.ToString(dr["Purpose"].ToString())
        //                              ,
        //                            MRVDate = Convert.ToDateTime(dr["MRVDate"].ToString())
        //                              ,
        //                            AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
        //                            ,
        //                            IsClosed = Convert.ToString(dr["IsClosed"].ToString())
        //                            ,
        //                            MRVStatus = Convert.ToString(dr["MRVStatus"].ToString())
        //                                 ,
        //                            ItemCode = Convert.ToString(dr["ItemCode"].ToString())
        //                            ,
        //                            ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
        //                                 ,
        //                            ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
        //                                 ,
        //                            ProductName = Convert.ToString(dr["ProductName"].ToString())
        //                                 ,
        //                            Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
        //                                ,
        //                            Unit = Convert.ToString(dr["Unit"].ToString())
        //                                ,
        //                            MRVDetailNum = Convert.ToInt32(dr["MRVDetailNum"].ToString())
        //                               ,
        //                            Available = Convert.ToString(dr["Available"].ToString())
        //                               ,
        //                            BiddingRefNum = Convert.ToString(dr["BiddingRefNum"].ToString())
        //                        });
        //                    }
        //                }
        //            }

        //        }
        //        return CanvassSheetDetailList;
        //    }
        //    catch (Exception ex)
        //    {

        //        return null;
        //    }
        //    finally
        //    {
        //        DatabaseConnection.DBClose();
        //    }
        //}
        public String AddMRVGatePassItem(String ReferenceNum,String GatePassNum, String MRVNum,Int32 MRVDetailNum)
        {
            try 
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_AddMRVGatePassItem";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Value = GatePassNum;

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@MRVDetailNum", SqlDbType.Int);
                    param.Value = MRVDetailNum;
                  
                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemoveMRVGatePassItem(String MRVDetailNum, String ReferenceNum)
        {
            try
            { 
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_RemoveGatePassItem";

                    param = cmd.Parameters.Add("@TransDetailNum", SqlDbType.Int);
                    param.Value = Convert.ToInt32(MRVDetailNum);

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;                

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemoveMTRVGatePassItem(String MTRVDetailNum, String ReferenceNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_RemoveGatePassItem";

                    param = cmd.Parameters.Add("@TransDetailNum", SqlDbType.Int);
                    param.Value = Convert.ToInt32(MTRVDetailNum);

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String DeleteMRVGatePass(String GatePassNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_DeleteMRVGatePass";

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Value = GatePassNum;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                    
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String DeleteMTRVGatePass(String GatePassNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_DeleteMTRVGatePass";

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Value = GatePassNum;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String DeleteFullMRV(String MRVNum, String MRVStatus)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_DeleteFullMRV";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@MRVStatus", SqlDbType.VarChar, 50);
                    param.Value = MRVStatus;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CancelMRVGatePass(String ReferenceNum, String GatePassNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CancelMRVGatePass";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Value = GatePassNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CancelMTRVGatePass(String ReferenceNum, String GatePassNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CancelMTRVGatePass";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Value = GatePassNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        //public void DeleteMRVDetail(String MRVNum)
        //{
        //    try
        //    {
        //        using (SqlCommand cmd = new SqlCommand())
        //        {
        //            cmd.Connection = DatabaseConnection.cnn;
        //            DatabaseConnection.Connect();
        //            SqlParameter param = new SqlParameter();
        //            cmd.CommandTimeout = 6000;
        //            cmd.CommandType = CommandType.StoredProcedure;
        //            cmd.CommandText = "warehouse.sp_DeleteMRVDetail";

        //            param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
        //            param.Value = MRVNum;

        //            cmd.ExecuteNonQuery();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return;
        //    }
        //    finally
        //    {
        //        DatabaseConnection.DBClose();
        //    }
        //}


        public String UpdateMRVItem(MRVDetail MRVDetail)
        {
            try
            {
                //update MRV item in temp table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateMRVItem";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = MRVDetail.RefNum;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = MRVDetail.ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar,50);
                    param.Value = MRVDetail.ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 1000);
                    param.Value = MRVDetail.ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar, 1000);
                    param.Value = MRVDetail.ProductDesc;

                    param = cmd.Parameters.Add("@Unit", SqlDbType.VarChar, 50);
                    param.Value = MRVDetail.Unit;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = MRVDetail.Quantity;

                    param = cmd.Parameters.Add("@Purpose", SqlDbType.VarChar, 800);
                    param.Value = MRVDetail.Purpose;

                    param = cmd.Parameters.Add("@SubClassID", SqlDbType.Int);
                    param.Value = MRVDetail.SubClassID;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String CheckMRVGatePassStatus( String GatePassNum)
        {
            try
            {
                //save MRV Status
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckMRVGatePassStatus";

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Value = GatePassNum;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String CheckMTRVGatePassStatus(String GatePassNum)
        {
            try
            {
                //save MRV Status
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckMTRVGatePassStatus";

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Value = GatePassNum;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CheckMRVOwner(String MRVNum, Int32 UserID)
        {
            try
            {
                //save MRV Status
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckMRVOwner";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 200);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<RIVClass> GetRIVClassList(String Param,String DeptCode, String Flag)
        {
            List<RIVClass> MRVClassList = new List<RIVClass>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetRIVClass";

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 100);
                    param.Value = DeptCode;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MRVClassList.Add(new RIVClass()
                                {
                                    SubClassID = Convert.ToInt32(dr["SubClassID"].ToString())
                                    ,
                                    ProjectType = String.IsNullOrEmpty(dr["ProjectType"].ToString()) ? "" : dr["ProjectType"].ToString()
                                    ,
                                    ProjectClass = String.IsNullOrEmpty(dr["ProjectClass"].ToString()) ? "" : dr["ProjectClass"].ToString()
                                    ,
                                    SubClass = String.IsNullOrEmpty(dr["SubClass"].ToString()) ? "" : dr["SubClass"].ToString()
                                     ,
                                    SubClassDesc = String.IsNullOrEmpty(dr["SubClassDesc"].ToString()) ? "" : dr["SubClassDesc"].ToString()

                                });
                            }
                        }
                    }

                }
                return MRVClassList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String GetMRVCurrentStatus(String MRVNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMRVCurrentStatus";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;
     
                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar, 50);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Status"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String ImportMRV(String ReferenceNum, String MRVNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_ImportMRV";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public string CheckMRVGatePassQuantityinTemp(String ReferenceNum,String GatePassNum, String MRVNum, Int32 MRVDetailNum,Int32 ProductCode
                        ,String ItemCode, String ProductName, String ProductDesc, Decimal Quantity, String Unit, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckMRVGatePassQuantity_Temp";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar,50);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Value = GatePassNum;

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@MRVDetailNum", SqlDbType.Int);
                    param.Value = MRVDetailNum;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar,50);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar);
                    param.Value = ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar);
                    param.Value = ProductDesc;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = Quantity;

                    param = cmd.Parameters.Add("@Unit", SqlDbType.VarChar);
                    param.Value = Unit;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar,20);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public string CheckMTRVGatePassQuantityinTemp(String ReferenceNum, String GatePassNum, String MTRVNum, Int32 MTRVDetailNum, Int32 ProductCode
                       , String ItemCode, String ProductName, String ProductDesc, Decimal Quantity, String Unit, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckMTRVGatePassQuantity_Temp";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Value = GatePassNum;

                    param = cmd.Parameters.Add("@MTRVNum", SqlDbType.VarChar, 20);
                    param.Value = MTRVNum;

                    param = cmd.Parameters.Add("@MTRVDetailNum", SqlDbType.Int);
                    param.Value = MTRVDetailNum;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar);
                    param.Value = ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar);
                    param.Value = ProductDesc;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = Quantity;

                    param = cmd.Parameters.Add("@Unit", SqlDbType.VarChar);
                    param.Value = Unit;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MTRVGatePass> GetMTRVGatePassList(String Param, String Flag,String TransType)
        {
            List<MTRVGatePass> MTRVGatePassList = new List<MTRVGatePass>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetGatePass";

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@TransType", SqlDbType.VarChar, 50);
                    param.Value = TransType;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MTRVGatePassList.Add(new MTRVGatePass()
                                {
                                    GatePassNum = Convert.ToString(dr["GatePassNum"].ToString())
                                    ,
                                    GatePassDate = Convert.ToDateTime(dr["GatePassDate"].ToString())
                                    ,
                                    MTRVNum = Convert.ToString(dr["TransNum"].ToString())
                                    ,
                                     DeptCode= String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                     ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                       ,
                                    UserAccount = String.IsNullOrEmpty(dr["AccountUse"].ToString()) ? "" : dr["AccountUse"].ToString()

                                });
                            }
                        }
                    }

                }
                return MTRVGatePassList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<MRVGatePass> GetMRVGatePassList(String Param, String Flag, String TransType)
        {
            List<MRVGatePass> MRVGatePassList = new List<MRVGatePass>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetGatePass";

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@TransType", SqlDbType.VarChar, 50);
                    param.Value = TransType;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MRVGatePassList.Add(new MRVGatePass()
                                {
                                    GatePassNum = Convert.ToString(dr["GatePassNum"].ToString())
                                    ,
                                    GatePassDate = Convert.ToDateTime(dr["GatePassDate"].ToString())
                                    ,
                                    MRVNum = Convert.ToString(dr["TransNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                     ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                       ,
                                    UserAccount = String.IsNullOrEmpty(dr["AccountUse"].ToString()) ? "" : dr["AccountUse"].ToString()

                                });
                            }
                        }
                    }

                }
                return MRVGatePassList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String HasMCT(String GatePassNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckGatePassMCT";

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Value = GatePassNum;

                    param = cmd.Parameters.Add("@MCTNum", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@MCTNum"].Value);
                }
            }
            catch (Exception ex)
            {

                return "";
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String HasMTCT(String GatePassNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.spCheckGatePassMTCT";

                    param = cmd.Parameters.Add("@GatePassNum", SqlDbType.VarChar, 20);
                    param.Value = GatePassNum;

                    param = cmd.Parameters.Add("@MTCTNum", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@MTCTNum"].Value);
                }
            }
            catch (Exception ex)
            {

                return "";
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<GatePass> GetMRVMTRVGatePassList(String Param, String Flag, String TransType)
        {
            List<GatePass>  GatePassList = new List<GatePass>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetGatePass";

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@TransType", SqlDbType.VarChar, 50);
                    param.Value = TransType;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                GatePassList.Add(new GatePass()
                                {
                                    GatePassNum = Convert.ToString(dr["GatePassNum"].ToString())
                                    ,
                                    GatePassDate = Convert.ToDateTime(dr["GatePassDate"].ToString())
                                    ,
                                  
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                     ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                       ,
                                    UserAccount = String.IsNullOrEmpty(dr["AccountUse"].ToString()) ? "" : dr["AccountUse"].ToString()
                                       ,
                                    ReferenceNum = String.IsNullOrEmpty(dr["GatePassReferenceNum"].ToString()) ? "" : dr["GatePassReferenceNum"].ToString()
                                });
                            }
                        }
                    }

                }
                return GatePassList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

    }
}
