﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using anecoacct.WareHouseClass;
using anecoacct.WareHouseModel;
using System.Data;
using System.Data.SqlClient;
namespace anecoacct.WareHouseClass
{
    class ProductQueries
    {
        public List<ProductView> GetProducInfo(String Param, String Flag)
        {
            List<ProductView> ProductViewList = new List<ProductView>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetProduct";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ProductViewList.Add(new ProductView()
                                {
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                    ,
                                    ItemCode = String.IsNullOrEmpty(dr["ItemCode"].ToString()) ? "" : dr["ItemCode"].ToString()
                                    ,
                                    ClassCode = Convert.ToInt32(dr["ClassCode"].ToString())
                                     ,
                                    ProductName = String.IsNullOrEmpty(dr["ProductName"].ToString()) ? "" : dr["ProductName"].ToString()
                                      ,
                                    ProductDesc = String.IsNullOrEmpty(dr["ProductDesc"].ToString()) ? "" : dr["ProductDesc"].ToString()
                                      ,
                                    UnitID = Convert.ToInt32(dr["UnitID"].ToString())
                                    ,
                                    IsReg = String.IsNullOrEmpty(dr["IsReg"].ToString()) ? "" : dr["IsReg"].ToString()
                                   ,
                                    FlagDel = String.IsNullOrEmpty(dr["FlagDel"].ToString()) ? "" : dr["FlagDel"].ToString()
                                   ,
                                    CreatedBy = Convert.ToInt32(dr["CreatedBy"].ToString())
                                     ,
                                    DateCreated = Convert.ToDateTime(dr["DateCreated"].ToString())
                                      ,
                                    ModifiedBy = Convert.ToInt32(dr["ModifiedBy"].ToString())
                                      ,
                                    DateModified = Convert.ToDateTime(dr["DateModified"].ToString())

                                      ,
                                    AccountCode = String.IsNullOrEmpty(dr["AcctCode"].ToString()) ? "" : dr["AcctCode"].ToString()

  ,
                                    AccountDesc = String.IsNullOrEmpty(dr["AcctDesc"].ToString()) ? "" : dr["AcctDesc"].ToString()

                                      ,
                                    Address = String.IsNullOrEmpty(dr["Address"].ToString()) ? "" : dr["Address"].ToString()

  ,
                                    Unit = String.IsNullOrEmpty(dr["Unit"].ToString()) ? "" : dr["Unit"].ToString()
                                      ,
                                    Units = String.IsNullOrEmpty(dr["Units"].ToString()) ? "" : dr["Units"].ToString()
                                });
                            }
                        }
                    }

                }
                return ProductViewList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<ProductView> GetProducInfoNEA(String Param, String Flag)
        {
            List<ProductView> ProductViewList = new List<ProductView>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetProductNEA";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ProductViewList.Add(new ProductView()
                                {
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                    ,
                                    ItemCode = String.IsNullOrEmpty(dr["ItemCode"].ToString()) ? "" : dr["ItemCode"].ToString()
                                    ,
                                   
                                    ProductName = String.IsNullOrEmpty(dr["ProductName"].ToString()) ? "" : dr["ProductName"].ToString()
                                      ,
                                    ProductDesc = String.IsNullOrEmpty(dr["ProductDesc"].ToString()) ? "" : dr["ProductDesc"].ToString()
                                      ,
                                    UnitID = Convert.ToInt32(dr["UnitID"].ToString())
                                    ,
                                    IsReg = String.IsNullOrEmpty(dr["IsReg"].ToString()) ? "" : dr["IsReg"].ToString()
                                   ,
                                    FlagDel = String.IsNullOrEmpty(dr["FlagDel"].ToString()) ? "" : dr["FlagDel"].ToString()
                                   ,
                                    CreatedBy = Convert.ToInt32(dr["CreatedBy"].ToString())
                                     ,
                                    DateCreated = Convert.ToDateTime(dr["DateCreated"].ToString())
                                      ,
                                    ModifiedBy = Convert.ToInt32(dr["ModifiedBy"].ToString())
                                      ,
                                    DateModified = Convert.ToDateTime(dr["DateModified"].ToString())

                                      ,
                                    AccountCode = String.IsNullOrEmpty(dr["AcctCode"].ToString()) ? "" : dr["AcctCode"].ToString()

  ,
                                    AccountDesc = String.IsNullOrEmpty(dr["AcctDesc"].ToString()) ? "" : dr["AcctDesc"].ToString()

                                      ,
                                    Address = String.IsNullOrEmpty(dr["Address"].ToString()) ? "" : dr["Address"].ToString()

  ,
                                    Unit = String.IsNullOrEmpty(dr["Unit"].ToString()) ? "" : dr["Unit"].ToString()
                                      ,
                                    Units = String.IsNullOrEmpty(dr["Units"].ToString()) ? "" : dr["Units"].ToString()

                                       ,
                                    UnitCost = Convert.ToDecimal(dr["UnitPrice"].ToString())
                                       ,
                                    CurrentMonthPrice = String.IsNullOrEmpty(dr["CurrentMonthPrice"].ToString()) ? "" : dr["CurrentMonthPrice"].ToString()
                                       ,
                                    CurrentYearPrice = String.IsNullOrEmpty(dr["CurrentYearPrice"].ToString()) ? "" : dr["CurrentYearPrice"].ToString()
                                     ,
                                    NEABased = String.IsNullOrEmpty(dr["NEABased"].ToString()) ? "" : dr["NEABased"].ToString()
                                     ,
                                    WithSubsidy = String.IsNullOrEmpty(dr["Subsidy"].ToString()) ? "" : dr["Subsidy"].ToString()
                                     ,
                                    WithDetail = String.IsNullOrEmpty(dr["WithDetail"].ToString()) ? "" : dr["WithDetail"].ToString()
                                });
                            }
                        }
                    }

                }
                return ProductViewList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<ProductInventoryView> GetProductInventoryInfo(String Param, String Flag,String BranchName)
        {
            List<ProductInventoryView> ProductInventoryViewList = new List<ProductInventoryView>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetProductInventory";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ProductInventoryViewList.Add(new ProductInventoryView()
                                {
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                    ,
                                    BranchName = String.IsNullOrEmpty(dr["BranchName"].ToString()) ? "" : dr["BranchName"].ToString()
                                    ,
                                    ItemCode = String.IsNullOrEmpty(dr["ItemCode"].ToString()) ? "" : dr["ItemCode"].ToString()
                                    ,
                                    //ClassCode = Convert.ToInt32(dr["ClassCode"].ToString())
                                    // ,
                                    ProductName = String.IsNullOrEmpty(dr["ProductName"].ToString()) ? "" : dr["ProductName"].ToString()
                                      ,
                                    ProductDesc = String.IsNullOrEmpty(dr["ProductDesc"].ToString()) ? "" : dr["ProductDesc"].ToString()
                                      ,
                                    UnitID = Convert.ToInt32(dr["UnitID"].ToString())
                                   
                                   ,
                                    FlagDel = String.IsNullOrEmpty(dr["FlagDel"].ToString()) ? "" : dr["FlagDel"].ToString()
                                   ,
                                    CreatedBy = Convert.ToInt32(dr["CreatedBy"].ToString())
                                     ,
                                    DateCreated = Convert.ToDateTime(dr["DateCreated"].ToString())
                                      ,
                                    ModifiedBy = Convert.ToInt32(dr["ModifiedBy"].ToString())
                                      ,
                                    DateModified = Convert.ToDateTime(dr["DateModified"].ToString())

                                      //,
  //                                  AccountCode = String.IsNullOrEmpty(dr["AccountCode"].ToString()) ? "" : dr["AccountCode"].ToString()

  //,
  //                                  AccountDesc = String.IsNullOrEmpty(dr["AccountDesc"].ToString()) ? "" : dr["AccountDesc"].ToString()

  //                                    ,
  //                                  Address = String.IsNullOrEmpty(dr["Address"].ToString()) ? "" : dr["Address"].ToString()

  ,
                                    Unit = String.IsNullOrEmpty(dr["Unit"].ToString()) ? "" : dr["Unit"].ToString()
                                      ,
                                    Units = String.IsNullOrEmpty(dr["Units"].ToString()) ? "" : dr["Units"].ToString()
                                    ,Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                    ,
                                    Reserve = Convert.ToDecimal(dr["Reserve"].ToString())
                                    ,
                                    OnHand = Convert.ToDecimal(dr["OnHand"].ToString())
                                    ,
                                    Buffer = Convert.ToDecimal(dr["Buffer"].ToString())
                                         ,
                                    UnitCost = Convert.ToDecimal(dr["UnitPrice"].ToString())
                                       ,
                                    CurrentMonthPrice = String.IsNullOrEmpty(dr["CurrentMonthPrice"].ToString()) ? "" : dr["CurrentMonthPrice"].ToString()
                                       ,
                                    CurrentYearPrice = String.IsNullOrEmpty(dr["CurrentYearPrice"].ToString()) ? "" : dr["CurrentYearPrice"].ToString()
                                    ,
                                    ForRepair = Convert.ToDecimal(dr["ForRepair"].ToString())
                                    ,
                                    Busted = Convert.ToDecimal(dr["Busted"].ToString())
                                });
                            }
                        }
                    }

                }
                return ProductInventoryViewList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<ProductUnit> GetProductUnitList(String Param, String Flag)
        {
            List<ProductUnit> ProductUnitList = new List<ProductUnit>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetProductUnit";
                    param = cmd.Parameters.Add("@param", SqlDbType.VarChar, 50);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                     using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ProductUnitList.Add(new ProductUnit()
                                {
                                    UnitID = Convert.ToInt32(dr["UnitID"].ToString())
                                    ,
                                    Unit = String.IsNullOrEmpty(dr["Unit"].ToString()) ? "" : dr["Unit"].ToString()
                                    ,
                                     Units = String.IsNullOrEmpty(dr["Units"].ToString()) ? "" : dr["Units"].ToString()
                                  
                                });
                            }
                        }
                    }

                }
                return ProductUnitList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String SaveProduct(Product Product, String Flag)
        {
            try
            {
                //save Product NEA
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveProduct";

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = Product.ItemCode;
                    
                    param = cmd.Parameters.Add("@AcctCode", SqlDbType.VarChar, 50);
                    param.Value = Product.AcctCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar);
                    param.Value = Product.ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar);
                    param.Value = Product.ProductDesc;

                    param = cmd.Parameters.Add("@Unit", SqlDbType.VarChar);
                    param.Value = Product.UnitDesc;

                    param = cmd.Parameters.Add("@NEABased", SqlDbType.VarChar,1);
                    param.Value = Product.NEABased;

                    param = cmd.Parameters.Add("@Subsidy", SqlDbType.VarChar, 1);
                    param.Value = Product.WithSubsidy;

                    param = cmd.Parameters.Add("@WithDetail", SqlDbType.VarChar, 1);
                    param.Value = Product.WithDetail;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar,1000);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar,20);
                    param.Value =Flag;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewProductCode = Convert.ToInt32(cmd.Parameters["@ProductCode"].Value.ToString());
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateProduct(Product Product, String Flag)
        {
            try
            {
                //update Product NEA
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateProduct";

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = Product.ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = Product.ItemCode;

                    param = cmd.Parameters.Add("@AcctCode", SqlDbType.VarChar, 50);
                    param.Value = Product.AcctCode;


                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar);
                    param.Value = Product.ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar);
                    param.Value = Product.ProductDesc;

                    param = cmd.Parameters.Add("@Unit", SqlDbType.VarChar);
                    param.Value = Product.UnitDesc;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@NEABased", SqlDbType.VarChar, 1);
                    param.Value = Product.NEABased;

                    param = cmd.Parameters.Add("@Subsidy", SqlDbType.VarChar, 1);
                    param.Value = Product.WithSubsidy;

                    param = cmd.Parameters.Add("@WithDetail", SqlDbType.VarChar, 1);
                    param.Value = Product.WithDetail;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<ProductDetail> GetProductStockDetailList_TempTable(String ReferenceNum,String BranchName,String ItemCode,String Param, String Flag)
        {
            List<ProductDetail> ProductDetailList = new List<ProductDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetProductStockDetail_Temp";
                    
                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 100);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar,100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ProductDetailList.Add(new ProductDetail()
                                {

                                    StockDetailID = Convert.ToInt32(dr["StockDetailID"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                   ,
                                    BranchID = Convert.ToInt32(dr["BranchID"].ToString())
                                   ,
                                    StockType = Convert.ToString(dr["StockType"].ToString())
                                   ,
                                    TransNum = Convert.ToString(dr["TransNum"].ToString())
                                   ,

                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,

                                    UnitDesc = Convert.ToString(dr["Unit"].ToString())
                                        ,
                                    Status = Convert.ToString(dr["Status"].ToString())
                                       ,
                                    Withdrawn = Convert.ToString(dr["Withdrawn"].ToString())
                                    ,
                                    Brand = Convert.ToString(dr["Brand"].ToString())
                                    ,
                                    KVA = Convert.ToString(dr["KVA"].ToString())

                                    ,
                                    SerialNo = Convert.ToString(dr["SerialNo"].ToString())
                                    ,
                                    TagNo = Convert.ToString(dr["TagNo"].ToString())

                                    ,
                                    Primary = Convert.ToString(dr["Primary"].ToString())

                                    ,
                                    Secondary = Convert.ToString(dr["Secondary"].ToString())

                                    ,
                                    Polarity = Convert.ToString(dr["Polarity"].ToString())
                                    ,
                                    Bushing = Convert.ToString(dr["Bushing"].ToString())
                                    ,
                                    Impedance = Convert.ToString(dr["Impedance"].ToString())
                                    ,
                                    DateManufacture = Convert.ToDateTime(dr["DateManufacture"].ToString())

                                });

                            }
                        }

                    }
                    return ProductDetailList;
                }
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<ProductDetail> GetMSTProductDetailList_TempTable(String ReferenceNum, String BranchName, String ItemCode, String Param, String Flag)
        {
            List<ProductDetail> ProductDetailList = new List<ProductDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMSTProductDetail_Temp";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 100);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ProductDetailList.Add(new ProductDetail()
                                {

                                    StockDetailID = Convert.ToInt32(dr["ProductDetailID"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                   ,
                                    BranchID = Convert.ToInt32(dr["BranchID"].ToString())
                                   ,
                                  
                                    TransNum = Convert.ToString(dr["TransNum"].ToString())
                                   ,

                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,

                                    UnitDesc = Convert.ToString(dr["Unit"].ToString())
                                        ,
                                    Brand = Convert.ToString(dr["Brand"].ToString())
                                    ,
                                    KVA = Convert.ToString(dr["KVA"].ToString())

                                    ,
                                    SerialNo = Convert.ToString(dr["SerialNo"].ToString())
                                    ,
                                    TagNo = Convert.ToString(dr["TagNo"].ToString())

                                    ,
                                    Primary = Convert.ToString(dr["Primary"].ToString())

                                    ,
                                    Secondary = Convert.ToString(dr["Secondary"].ToString())

                                    ,
                                    Polarity = Convert.ToString(dr["Polarity"].ToString())
                                    ,
                                    Bushing = Convert.ToString(dr["Bushing"].ToString())
                                    ,
                                    Impedance = Convert.ToString(dr["Impedance"].ToString())
                                    ,
                                    Notes = Convert.ToString(dr["Notes"].ToString())

                                });

                            }
                        }

                    }
                    return ProductDetailList;
                }
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String AddProductStockDetailItem(ProductDetail ProductDetail, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_AddProductStockItem";

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 200);
                    param.Value = ProductDetail.BranchName;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ProductDetail.ReferenceNum;

                    param = cmd.Parameters.Add("@StockType", SqlDbType.VarChar, 50);
                    param.Value = ProductDetail.StockType;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = ProductDetail.ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = String.IsNullOrEmpty(ProductDetail.ItemCode) ? "" : ProductDetail.ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 1000);
                    param.Value = ProductDetail.ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar, 1000);
                    param.Value = ProductDetail.ProductDesc;

                    param = cmd.Parameters.Add("@Unit", SqlDbType.VarChar, 50);
                    param.Value = ProductDetail.UnitDesc;

                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar, 100);
                    param.Value = ProductDetail.Status;

                    //param = cmd.Parameters.Add("@Withdrawn", SqlDbType.VarChar, 1);
                    //param.Value = ProductDetail.Withdrawn;

                    param = cmd.Parameters.Add("@Brand", SqlDbType.VarChar, 1000);
                    param.Value = ProductDetail.Brand;

                    param = cmd.Parameters.Add("@KVA", SqlDbType.VarChar, 1000);
                    param.Value = ProductDetail.KVA;

                    param = cmd.Parameters.Add("@SerialNo", SqlDbType.VarChar, 1000);
                    param.Value = ProductDetail.SerialNo;

                    param = cmd.Parameters.Add("@TagNo", SqlDbType.VarChar, 1000);
                    param.Value = ProductDetail.TagNo;

                    param = cmd.Parameters.Add("@Primary", SqlDbType.VarChar, 1000);
                    param.Value = ProductDetail.Primary;

                    param = cmd.Parameters.Add("@Secondary", SqlDbType.VarChar, 1000);
                    param.Value = ProductDetail.Secondary;

                    param = cmd.Parameters.Add("@Polarity", SqlDbType.VarChar, 1000);
                    param.Value = ProductDetail.Polarity;

                    param = cmd.Parameters.Add("@Bushing", SqlDbType.VarChar, 1000);
                    param.Value = ProductDetail.Bushing;

                    param = cmd.Parameters.Add("@Impedance", SqlDbType.VarChar, 1000);
                    param.Value = ProductDetail.Impedance;

                    param = cmd.Parameters.Add("@DateManufacture", SqlDbType.DateTime);
                    param.Value = ProductDetail.DateManufacture;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemoveProductStockDetailItem(Int32 StockDetailID, String ReferenceNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_RemoveProductStockDetalItem";

                    param = cmd.Parameters.Add("@StockDetailID", SqlDbType.Int);
                    param.Value = StockDetailID;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemoveProductStockDetailSelectedItem(Int32 StockDetailID, String ReferenceNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_RemoveProductStockDetalSelectedItem";

                    param = cmd.Parameters.Add("@StockDetailID", SqlDbType.Int);
                    param.Value = StockDetailID;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemoveMSTProductStockDetailSelectedItem(Int32 ProductDetailID, String ReferenceNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_RemoveMSTProductDetalSelectedItem";

                    param = cmd.Parameters.Add("@ProductDetailID", SqlDbType.Int);
                    param.Value = ProductDetailID;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String AddProductStockDetailSelectedItem(String StockDetailID,String ReferenceNum, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_AddProductStockSelectedItem";

                    param = cmd.Parameters.Add("@StockDetailID", SqlDbType.Int);
                    param.Value = Convert.ToInt32(StockDetailID);

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar,20);
                    param.Value = ReferenceNum;


                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String AddMSTProductDetailSelectedItem(String ProductDetailID, String ReferenceNum, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_AddMSTProductSelectedItem";

                    param = cmd.Parameters.Add("@ProductDetailID", SqlDbType.Int);
                    param.Value = Convert.ToInt32(ProductDetailID);

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;


                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String AddMSTProductDetailSelectedItemManual(ProductDetail ProductDetail, String ReferenceNum, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_AddMSTProductSelectedItemManual";
                   
                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ProductDetail.ReferenceNum;
                   
                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 200);
                    param.Value = ProductDetail.BranchName;

                    param = cmd.Parameters.Add("@TransNum", SqlDbType.VarChar, 50);
                    param.Value = "";

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = ProductDetail.ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = String.IsNullOrEmpty(ProductDetail.ItemCode) ? "" : ProductDetail.ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 1000);
                    param.Value = ProductDetail.ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar, 1000);
                    param.Value = ProductDetail.ProductDesc;

                    param = cmd.Parameters.Add("@UnitDesc", SqlDbType.VarChar, 50);
                    param.Value = ProductDetail.UnitDesc;

                    param = cmd.Parameters.Add("@Brand", SqlDbType.VarChar, 1000);
                    param.Value = ProductDetail.Brand;

                    param = cmd.Parameters.Add("@KVA", SqlDbType.VarChar, 1000);
                    param.Value = ProductDetail.KVA;

                    param = cmd.Parameters.Add("@SerialNo", SqlDbType.VarChar, 1000);
                    param.Value = ProductDetail.SerialNo;

                    param = cmd.Parameters.Add("@TagNo", SqlDbType.VarChar, 1000);
                    param.Value = ProductDetail.TagNo;

                    param = cmd.Parameters.Add("@Primary", SqlDbType.VarChar, 1000);
                    param.Value = ProductDetail.Primary;

                    param = cmd.Parameters.Add("@Secondary", SqlDbType.VarChar, 1000);
                    param.Value = ProductDetail.Secondary;

                    param = cmd.Parameters.Add("@Polarity", SqlDbType.VarChar, 1000);
                    param.Value = ProductDetail.Polarity;

                    param = cmd.Parameters.Add("@Bushing", SqlDbType.VarChar, 1000);
                    param.Value = ProductDetail.Bushing;

                    param = cmd.Parameters.Add("@Impedance", SqlDbType.VarChar, 1000);
                    param.Value = ProductDetail.Impedance;

                    param = cmd.Parameters.Add("@Notes", SqlDbType.VarChar,1000);
                    param.Value = "";

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<ProductView> GetProductNEAItemThatHasDetail(String BranchName, String Flag)
        {
            List<ProductView> ProductViewList = new List<ProductView>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetProductNEAItemThatHasDetail";
                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 20);
                    param.Value = BranchName;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ProductViewList.Add(new ProductView()
                                {
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                    ,
                                    ItemCode = String.IsNullOrEmpty(dr["ItemCode"].ToString()) ? "" : dr["ItemCode"].ToString()
                                    ,

                                    ProductName = String.IsNullOrEmpty(dr["ProductName"].ToString()) ? "" : dr["ProductName"].ToString()
                                      ,

                                    Unit = String.IsNullOrEmpty(dr["Unit"].ToString()) ? "" : dr["Unit"].ToString()
                                       ,

                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                });
                            }
                        }
                    }

                }
                return ProductViewList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<ProductDetail> GetProductStockDetailList( String BranchName, String ItemCode,String Param, String Flag)
        {
            List<ProductDetail> ProductDetailList = new List<ProductDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetProductStockDetail";

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 100);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ProductDetailList.Add(new ProductDetail()
                                {

                                    StockDetailID = Convert.ToInt32(dr["StockDetailID"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                   ,
                                    BranchID = Convert.ToInt32(dr["BranchID"].ToString())
                                   ,
                                    StockType = Convert.ToString(dr["StockType"].ToString())
                                   ,
                                    TransNum = Convert.ToString(dr["TransNum"].ToString())
                                   ,

                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,

                                    UnitDesc = Convert.ToString(dr["Unit"].ToString())
                                        ,
                                    Status = Convert.ToString(dr["Status"].ToString())
                                       ,
                                    Withdrawn = Convert.ToString(dr["Withdrawn"].ToString())
                                    ,
                                    Brand = Convert.ToString(dr["Brand"].ToString())
                                    ,
                                    KVA = Convert.ToString(dr["KVA"].ToString())

                                    ,
                                    SerialNo = Convert.ToString(dr["SerialNo"].ToString())
                                    ,
                                    TagNo = Convert.ToString(dr["TagNo"].ToString())

                                    ,
                                    Primary = Convert.ToString(dr["Primary"].ToString())

                                    ,
                                    Secondary = Convert.ToString(dr["Secondary"].ToString())

                                    ,
                                    Polarity = Convert.ToString(dr["Polarity"].ToString())
                                    ,
                                    Bushing = Convert.ToString(dr["Bushing"].ToString())
                                    ,
                                    Impedance = Convert.ToString(dr["Impedance"].ToString())
                                    ,
                                    DateManufacture = Convert.ToDateTime(dr["DateManufacture"].ToString())

                                });

                            }
                        }

                    }
                    return ProductDetailList;
                }
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String UpdateProductDetailStatus(Int32 StockDetailID, String ItemCode, String BranchName, String OldStatus
            , String NewStatus, String Remarks)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateProductDetailStatus";

                    param = cmd.Parameters.Add("@StockDetailID", SqlDbType.Int);
                    param.Value = StockDetailID;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 20);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar,100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@OldStatus", SqlDbType.VarChar, 50);
                    param.Value = OldStatus;

                    param = cmd.Parameters.Add("@NewStatus", SqlDbType.VarChar, 50);
                    param.Value = NewStatus;

                    param = cmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 500);
                    param.Value = Remarks;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }



        public List<ProductDetailHistory> GetProductDetailHistory(String BranchName, String ItemCode, String Brand, String SerialNo, String Param, String Flag)
        {
            List<ProductDetailHistory> ProductDetailHistoryList = new List<ProductDetailHistory>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetProductStockDetailHistory";

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@Brand", SqlDbType.VarChar, 100);
                    param.Value = Brand;

                    param = cmd.Parameters.Add("@SerialNo", SqlDbType.VarChar, 100);
                    param.Value = SerialNo;

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ProductDetailHistoryList.Add(new ProductDetailHistory()
                                {
                                    StockType = Convert.ToString(dr["StockType"].ToString())
                                    ,
                                    TransNum = Convert.ToString(dr["StockType"].ToString()) 
                                    ,
                                    WithDrawnType = String.IsNullOrEmpty(dr["WithDrawType"].ToString()) ? "" : dr["WithDrawType"].ToString()
                                     ,
                                    WithDrawTransNum = String.IsNullOrEmpty(dr["WithDrawTransNum"].ToString()) ? "" : dr["WithDrawTransNum"].ToString()
                                    
                                });
                            }
                        }
                    }

                }
                return ProductDetailHistoryList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateProductStockDetail(ProductDetail prod)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateProductDetail";

                    param = cmd.Parameters.Add("@StockDetailID", SqlDbType.Int);
                    param.Value = prod.StockDetailID;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = prod.BranchName;

                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar, 50);
                    param.Value = prod.Status;

                    param = cmd.Parameters.Add("@DateManufacture", SqlDbType.DateTime);
                    param.Value = prod.DateManufacture;

                    param = cmd.Parameters.Add("@Brand", SqlDbType.VarChar, 1000);
                    param.Value = prod.Brand;

                    param = cmd.Parameters.Add("@KVA", SqlDbType.VarChar, 1000);
                    param.Value = prod.KVA;

                    param = cmd.Parameters.Add("@SerialNo", SqlDbType.VarChar, 1000);
                    param.Value = prod.SerialNo;

                    param = cmd.Parameters.Add("@TagNo", SqlDbType.VarChar, 1000);
                    param.Value = prod.TagNo;

                    param = cmd.Parameters.Add("@Primary", SqlDbType.VarChar, 1000);
                    param.Value = prod.Primary;

                    param = cmd.Parameters.Add("@Secondary", SqlDbType.VarChar, 1000);
                    param.Value = prod.Secondary;

                    param = cmd.Parameters.Add("@Polarity", SqlDbType.VarChar, 1000);
                    param.Value = prod.Polarity;

                    param = cmd.Parameters.Add("@Bushing", SqlDbType.VarChar, 1000);
                    param.Value = prod.Bushing;

                    param = cmd.Parameters.Add("@Impedance", SqlDbType.VarChar, 1000);
                    param.Value = prod.Impedance;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<ProductDetailHistory> GetProductDetailHistoryAll(String BranchName, String Param, String Flag)
        {
            List<ProductDetailHistory> ProductDetailHistoryList = new List<ProductDetailHistory>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetProductStockDetailHistoryAll";

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                   
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ProductDetailHistoryList.Add(new ProductDetailHistory()
                                {
                                    SortID = Convert.ToInt32(dr["SortID"].ToString())
                                    ,
                                    StockType = Convert.ToString(dr["StockType"].ToString())
                                    ,
                                    TransNum = Convert.ToString(dr["TransNum"].ToString())
                                    ,
                                    WithDrawnType = String.IsNullOrEmpty(dr["WithDrawType"].ToString()) ? "" : dr["WithDrawType"].ToString()
                                     ,
                                    WithDrawTransNum = String.IsNullOrEmpty(dr["WithDrawTransNum"].ToString()) ? "" : dr["WithDrawTransNum"].ToString()
                                     ,
                                    SerialNo = Convert.ToString(dr["SerialNo"].ToString())
                                      ,
                                    Brand = Convert.ToString(dr["Brand"].ToString())
                                         ,
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                      ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                       ,
                                    BranchName = Convert.ToString(dr["BranchName"].ToString())
                                     ,
                                    Status = Convert.ToString(dr["Status"].ToString())
                                });
                            }
                        }
                    }

                }
                return ProductDetailHistoryList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
    }
}
