﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using anecoacct.WareHouseModel;
using System.Data.SqlClient;
using System.Data;

namespace anecoacct.WareHouseClass
{
    class CanvassSheetQueries
    {
        OtherQueries OtherQueries = new OtherQueries();

        public String EditCanvassSheet(String ReferenceNum, String RIVNum, String CanvassSheetNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_EditCanvassSheet";

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = RIVNum;

                    param = cmd.Parameters.Add("@CVSReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheetNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String SaveCanvassSheet(CanvassSheet CanvassSheet)
        {
            try
            {
                //save CanvassSheet table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveCanvassSheet";

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@CVSReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheet.RefNum;

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheet.RIVNum;

                    param = cmd.Parameters.Add("@ProcurementMode", SqlDbType.VarChar, 50);
                    param.Value = CanvassSheet.ProcurementMode;

                    param = cmd.Parameters.Add("@BiddingRefNum", SqlDbType.VarChar, 50);
                    param.Value = CanvassSheet.BiddingRefNum;

                    param = cmd.Parameters.Add("@DateProcess", SqlDbType.DateTime);
                    param.Value = CanvassSheet.DateProcess;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewCanvassSheetNum = Convert.ToString(cmd.Parameters["@CanvassSheetNum"].Value.ToString());
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<CanvassSheet> GetCanvassSheetList(String Param, String Flag)
        {
            //note that only the approve status of riv will be populated in the List
            List<CanvassSheet> CanvassSheetList = new List<CanvassSheet>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetCanvassSheet";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                CanvassSheetList.Add(new CanvassSheet()
                                {
                                    CanvassSheetNum= Convert.ToString(dr["CanvassSheetNum"].ToString())
                                    ,
                                    DateProcess= Convert.ToDateTime(dr["DateProcess"].ToString())
                                    ,
                                    RIVNum = Convert.ToString(dr["RIVNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    RefNum = Convert.ToString(dr["CVSReferenceNum"].ToString())
                                      ,
                                    RIVDate = Convert.ToDateTime(dr["RIVDate"].ToString())
                                      ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    ,
                                    RIVStatus = Convert.ToString(dr["RIVStatus"].ToString())

                                });
                            }
                        }
                    }

                }
                return CanvassSheetList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<CanvassSheetDetail> GetCanvassSheetDetailList (String Param, String Flag)
        {
            List<CanvassSheetDetail> CanvassSheetDetailList = new List<CanvassSheetDetail>();
            Decimal temp_qty = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();
                    DatabaseConnection.Connect();
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 60000;
                    cmd.CommandText = "warehouse.sp_GetCanvassSheetDetail";

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 50);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                if (String.IsNullOrEmpty(dr["Quantity"].ToString()))
                                {
                                    temp_qty = 0;
                                }
                                else
                                {
                                    temp_qty = Convert.ToDecimal(dr["Quantity"].ToString());
                                }
                                CanvassSheetDetailList.Add(new CanvassSheetDetail() {
                                        CanvassSheetNum = String.IsNullOrEmpty(dr["CanvassSheetNum"].ToString()) ? "" : dr["CanvassSheetNum"].ToString()
                                        ,CanvassSheetDetailNum = Convert.ToInt32(dr["CanvassSheetDetailNum"].ToString()) 
                                        ,RIVNum = String.IsNullOrEmpty(dr["RIVNum"].ToString()) ? "" : dr["RIVNum"].ToString()
                                        ,RefNum = String.IsNullOrEmpty(dr["CVSReferenceNum"].ToString()) ? "" : dr["CVSReferenceNum"].ToString()
                                        ,DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                        ,Month = String.IsNullOrEmpty(dr["Month"].ToString()) ? "" : dr["Month"].ToString()
                                        ,
                                    Year = String.IsNullOrEmpty(dr["Year"].ToString()) ? "" : dr["Year"].ToString()
                                        ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                        ,
                                    EmpID = String.IsNullOrEmpty(dr["EmpID"].ToString()) ? "" : dr["EmpID"].ToString()
                                        ,
                                    EmpType = String.IsNullOrEmpty(dr["EmpType"].ToString()) ? "" : dr["EmpType"].ToString()
                                        ,
                                    WONo = String.IsNullOrEmpty(dr["WONo"].ToString()) ? "" : dr["WONo"].ToString()
                                        ,
                                    JONo = String.IsNullOrEmpty(dr["JONo"].ToString()) ? "" : dr["JONo"].ToString()
                                        ,
                                    Purpose = String.IsNullOrEmpty(dr["Purpose"].ToString()) ? "" : dr["Purpose"].ToString()
                                        ,
                                    RIVDate = Convert.ToDateTime(dr["RIVDate"].ToString())                                        ,
                                    AwardedTo = String.IsNullOrEmpty(dr["AwardedTo"].ToString()) ? "" : dr["AwardedTo"].ToString()
                                        ,
                                    IsClosed = String.IsNullOrEmpty(dr["IsClosed"].ToString()) ? "" : dr["IsClosed"].ToString()
                                        ,
                                    RIVStatus = String.IsNullOrEmpty(dr["RIVStatus"].ToString()) ? "" : dr["RIVStatus"].ToString()
                                        ,
                                    ProductCode = String.IsNullOrEmpty(dr["ProductCode"].ToString()) ? 0 : Convert.ToInt32(dr["ProductCode"].ToString())
                                        ,
                                    ItemCode = String.IsNullOrEmpty(dr["ItemCode"].ToString()) ? "" : dr["ItemCode"].ToString()
                                        ,
                                    ProductDesc = String.IsNullOrEmpty(dr["ProductDesc"].ToString()) ? "" : dr["ProductDesc"].ToString()
                                        ,
                                    ProductName = String.IsNullOrEmpty(dr["ProductName"].ToString()) ? "" : dr["ProductName"].ToString()
                                        ,
                                    Quantity = String.IsNullOrEmpty(dr["Quantity"].ToString()) ? 0 : Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = String.IsNullOrEmpty(dr["Unit"].ToString()) ? "" : dr["Unit"].ToString()
                                        ,
                                    RIVDetailNum = Convert.ToInt32(dr["RIVDetailNum"].ToString())
                                        ,
                                    Available = String.IsNullOrEmpty(dr["RIVNum"].ToString()) ? "" : dr["RIVNum"].ToString()
                                    ,ProcurementMode = String.IsNullOrEmpty(dr["ProcurementMode"].ToString()) ? "" : dr["ProcurementMode"].ToString()
                                    ,
                                    BiddingRefNum = String.IsNullOrEmpty(dr["BiddingRefNum"].ToString()) ? "" : dr["BiddingRefNum"].ToString()
                                });

                              
                            }//end of while                         
                        }//END OF HAS ROWS
                    }//end of using dr
                }//end of using cmd
                return CanvassSheetDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }

        }
        public List<CanvassSheetSupplier> GetCanvassSheetSupplierList(String Param, String Flag)
        {
            List<CanvassSheetSupplier> CanvassSheetSupplierList = new List<CanvassSheetSupplier>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetCanvassSheetSupplier";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                CanvassSheetSupplierList.Add(new CanvassSheetSupplier()
                                {
                                    CanvassSheetSupplierCode= Convert.ToInt32(dr["CanvassSheetSupplierCode"].ToString())
                                    ,CanvassSheetNum = Convert.ToString(dr["CanvassSheetNum"].ToString())
                                    ,
                                    RIVNum = Convert.ToString(dr["RIVNum"].ToString())
                                    ,
                                    Address = Convert.ToString(dr["Address"].ToString())
                                    ,
                                    Location = Convert.ToString(dr["Location"].ToString())
                                    ,
                                    TIN = String.IsNullOrEmpty(dr["TIN"].ToString()) ? "" : dr["TIN"].ToString()
                                    ,
                                    SupplierNo = Convert.ToInt32(dr["SupplierNo"].ToString())
                                     ,
                                    SupplierName = Convert.ToString(dr["SupplierName"].ToString())
                                    
                                });
                            }
                        }
                    }

                }
                return CanvassSheetSupplierList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        
        public void DeleteCanvassSheetDetail(String CanvassSheetNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_DeleteCanvassSheetDetail";
                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheetNum;
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public void DeleteCanvassSheetSupplier(String CanvassSheetNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_DeleteCanvassSheetSupplier";
                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheetNum;
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<RIVDetail> GetRIVDetailList(String Param, String Flag)
        {
            List<RIVDetail> RIVDetailList = new List<RIVDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetRIVDetail";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                RIVDetailList.Add(new RIVDetail()
                                {
                                    RIVNum = Convert.ToString(dr["RIVNum"].ToString())
                                    ,
                                    RefNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())

                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                    ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                     ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                      ,
                                    RIVDate = Convert.ToDateTime(dr["RIVDate"].ToString())
                                      ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                    ,
                                    IsClosed = Convert.ToString(dr["IsClosed"].ToString())
                                    ,
                                    RIVStatus = Convert.ToString(dr["RIVStatus"].ToString())
                                         ,
                                    ItemCode= Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Unit"].ToString())
                                        ,
                                    RIVDetailNum = Convert.ToInt32(dr["RIVDetailNum"].ToString())
                                       ,
                                    Available = Convert.ToString(dr["Available"].ToString())
                                });
                            }
                        }
                    }

                }
                return RIVDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String CancelCanvassSheet(String ReferenceNum,String RIVNum, String CanvassSheetNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CancelCanvassSheet";

                    param = cmd.Parameters.Add("@CVSReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = RIVNum;

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheetNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CancelCanvassSheetTrans( String RIVNum, String CanvassSheetNum) //CANCEL ALREADY SAVE CANVASS SHEET 
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CancelCanvassSheetTrans";

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = RIVNum;

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheetNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public void DeleteRIVDetail(String RIVNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_DeleteRIVDetail";

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = RIVNum;

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                return;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String AddCanvassSheetSupplier(CanvassSheetSupplier Supplier,String RIVNum,String ReferenceNum,String CanvassSheetNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_AddCanvassSheetSupplier";

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = RIVNum;

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = String.IsNullOrEmpty(CanvassSheetNum)?"":CanvassSheetNum;

                    param = cmd.Parameters.Add("@CVSReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@SupplierNo", SqlDbType.Int);
                    param.Value = Supplier.SupplierNo;

                    param = cmd.Parameters.Add("@SupplierName", SqlDbType.VarChar, 200);
                    param.Value = Supplier.SupplierName;

                    param = cmd.Parameters.Add("@Address", SqlDbType.VarChar, 200);
                    param.Value = Supplier.Address;

                    param = cmd.Parameters.Add("@Location", SqlDbType.VarChar, 20);
                    param.Value = Supplier.Location;

                    param = cmd.Parameters.Add("@TIN", SqlDbType.VarChar, 20);
                    param.Value = Supplier.TIN;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction= ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String GetRIVDetailIntoCanvassSheetDetailTemp(String RIVNum,String ReferenceNum,String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetRIVDetailIntoCanvassSheetDetailTemp";

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = RIVNum;

                    param = cmd.Parameters.Add("@CVSReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 800);
                    param.Direction= ParameterDirection.Output;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateCanvassSheet(CanvassSheet CanvassSheet)
        {
            try
            {
                
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateCanvassSheet";

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheet.CanvassSheetNum;

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheet.RIVNum;

                    param = cmd.Parameters.Add("@CVSReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheet.RefNum;

                    param = cmd.Parameters.Add("@ProcurementMode", SqlDbType.VarChar, 50);
                    param.Value = CanvassSheet.ProcurementMode;

                    param = cmd.Parameters.Add("@BiddingRefNum", SqlDbType.VarChar, 50);
                    param.Value = CanvassSheet.BiddingRefNum;

                    param = cmd.Parameters.Add("@DateProcess", SqlDbType.DateTime);
                    param.Value = CanvassSheet.DateProcess;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemoveCanvassSheetItem(String RIVDetailNum, String ReferenceNum, String CanvassSheetNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_RemoveCanvassSheetItem";

                    param = cmd.Parameters.Add("@RIVDetailNum", SqlDbType.VarChar, 20);
                    param.Value = RIVDetailNum;

                    param = cmd.Parameters.Add("@CVSReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheetNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemoveCanvassSheetSupplier(Int32 SupplierNo, String ReferenceNum, String CanvassSheetNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_RemoveCanvassSheetSupplier";

                    param = cmd.Parameters.Add("@SupplierNo", SqlDbType.Int);
                    param.Value = SupplierNo;

                    param = cmd.Parameters.Add("@CVSReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheetNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<ProcurementMode> GetProcurementModeList(String Param, String Flag)
        {
            //note that only the approve status of riv will be populated in the List
            List<ProcurementMode> ProcurementModeList = new List<ProcurementMode>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetProcurementMode";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                ProcurementModeList.Add(new ProcurementMode()
                                {
                                    ProcurementModeID = Convert.ToInt32(dr["ProcurementModeNum"].ToString())
                                    ,
                                    ProcurementModeDesc = Convert.ToString(dr["ProcurementMode"].ToString())
                               
                                });
                            }
                        }
                    }

                }
                return ProcurementModeList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String GetCanvassSheetPOStatus(String CanvassSheetNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetCanvassSheetPOStatus";

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheetNum;

                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Status"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
    }
}
