﻿using anecoacct.WareHouseModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseClass
{
    class MRVRecipientQueries
    {
        public List<MRVDetailRecipient> GetMRVDetailRecipient_TempTable(String Param, String Flag)
        {
            List<MRVDetailRecipient> MRVDetailRecipientList = new List<MRVDetailRecipient>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetMRVDetailRecipient_Temp";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MRVDetailRecipientList.Add(new MRVDetailRecipient()
                                {

                                    RecipientNum = Convert.ToInt32(dr["RecipientNum"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    MRVNum = Convert.ToString(dr["MRVNum"].ToString())
                                    ,
                                    AcctNum = Convert.ToString(dr["AcctNum"].ToString())
                                    ,
                                    AcctName = Convert.ToString(dr["AcctName"].ToString())
                                    ,
                                    Address = Convert.ToString(dr["Address"].ToString())
                                    ,
                                    Remarks = Convert.ToString(dr["Remarks"].ToString())
                                    ,
                                    ConStatus = Convert.ToString(dr["ConStatus"].ToString())
                                    ,
                                    StockDetailID = Convert.ToInt32(dr["StockDetailID"].ToString())
                                    ,
                                    ProductCodeKWH = Convert.ToInt32(dr["ProductCodeKWH"].ToString())
                                    ,
                                    ItemCodeKWH = Convert.ToString(dr["ItemCodeKWH"].ToString())
                                    ,
                                    ProductNameKWH = Convert.ToString(dr["ProductNameKWH"].ToString())
                                    ,
                                    ProductDescKWH = Convert.ToString(dr["ProductDescKWH"].ToString())
                                    ,
                                    BrandKWH = Convert.ToString(dr["BrandKWH"].ToString())
                                    ,
                                    SerialNoKWH = Convert.ToString(dr["SerialNoKWH"].ToString())
                                    ,
                                    CoopNoKWH = Convert.ToString(dr["CoopNoKWH"].ToString())
                                    ,
                                    ERCSerialNoKWH = Convert.ToString(dr["ERCSerialNoKWH"].ToString())
                                    ,
                                    ReadingKWH = Convert.ToString(dr["ReadingKWH"].ToString())
                                    ,
                                    ZoneNoKWH = Convert.ToString(dr["ZoneNoKWH"].ToString())
                                    ,
                                    CONoKWH = Convert.ToString(dr["CONoKWH"].ToString())
                                    ,
                                    StickerNoKWH = Convert.ToString(dr["StickerNoKWH"].ToString())
                                    ,
                                    ProductCodeSDW = Convert.ToInt32(dr["ProductCodeSDW"].ToString())
                                    ,
                                    ItemCodeSDW = Convert.ToString(dr["ItemCodeSDW"].ToString())
                                    ,
                                    ProductNameSDW = Convert.ToString(dr["ProductNameSDW"].ToString())
                                    ,
                                    ProductDescSDW = Convert.ToString(dr["ProductDescSDW"].ToString())
                                    ,
                                    Length = Convert.ToDecimal(dr["Length"].ToString())
                                    ,
                                    Excess = Convert.ToDecimal(dr["Excess"].ToString())
                                    ,
                                    Amount = Convert.ToDecimal(dr["Amount"].ToString())
                                    ,
                                    ORNo = Convert.ToString(dr["ORNo"].ToString())
                                });
                            }
                        }
                    }

                }
                return MRVDetailRecipientList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String AddMRVDetailRecipientItem(MRVDetailRecipient MRVDetailRecipient, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_AddMRVDetailRecipientItem";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MRVDetailRecipient.ReferenceNum;

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVDetailRecipient.MRVNum;

                    param = cmd.Parameters.Add("@AcctNum", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.AcctNum;

                    param = cmd.Parameters.Add("@AcctName", SqlDbType.VarChar, 200);
                    param.Value = MRVDetailRecipient.AcctName;

                    param = cmd.Parameters.Add("@Address", SqlDbType.VarChar, 500);
                    param.Value = MRVDetailRecipient.Address;

                    param = cmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 200);
                    param.Value = MRVDetailRecipient.Remarks;

                    param = cmd.Parameters.Add("@ConStatus", SqlDbType.VarChar, 20);
                    param.Value = MRVDetailRecipient.ConStatus;

                    param = cmd.Parameters.Add("@StockDetailID", SqlDbType.Int);
                    param.Value = MRVDetailRecipient.StockDetailID;

                    param = cmd.Parameters.Add("@ProductCodeKWH", SqlDbType.Int);
                    param.Value = MRVDetailRecipient.ProductCodeKWH;

                    param = cmd.Parameters.Add("@ItemCodeKWH", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.ItemCodeKWH;

                    param = cmd.Parameters.Add("@ProductNameKWH", SqlDbType.VarChar,1000);
                    param.Value = MRVDetailRecipient.ProductNameKWH;

                    param = cmd.Parameters.Add("@ProductDescKWH", SqlDbType.VarChar, 1000);
                    param.Value = MRVDetailRecipient.ProductDescKWH;

                    param = cmd.Parameters.Add("@BrandKWH", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.BrandKWH;

                    param = cmd.Parameters.Add("@SerialNoKWH", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.SerialNoKWH;

                    param = cmd.Parameters.Add("@CoopNoKWH", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.CoopNoKWH;

                    param = cmd.Parameters.Add("@ERCSerialNoKWH", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.ERCSerialNoKWH;

                    param = cmd.Parameters.Add("@ReadingKWH", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.ReadingKWH;

                    param = cmd.Parameters.Add("@ZoneNoKWH", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.ZoneNoKWH;

                    param = cmd.Parameters.Add("@CONoKWH", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.CONoKWH;

                    param = cmd.Parameters.Add("@StickerNoKWH", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.StickerNoKWH;

                    param = cmd.Parameters.Add("@ProductCodeSDW", SqlDbType.Int);
                    param.Value = MRVDetailRecipient.ProductCodeSDW;

                    param = cmd.Parameters.Add("@ItemCodeSDW", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.ItemCodeSDW;

                    param = cmd.Parameters.Add("@ProductNameSDW", SqlDbType.VarChar, 1000);
                    param.Value = MRVDetailRecipient.ProductNameSDW;

                    param = cmd.Parameters.Add("@ProductDescSDW", SqlDbType.VarChar, 1000);
                    param.Value = MRVDetailRecipient.ProductDescSDW;

                    param = cmd.Parameters.Add("@Length", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = MRVDetailRecipient.Length;

                    param = cmd.Parameters.Add("@Excess", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = MRVDetailRecipient.Excess;

                    param = cmd.Parameters.Add("@Amount", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = MRVDetailRecipient.Amount;

                    param = cmd.Parameters.Add("@ORNo", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.ORNo;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateMRVDetailRecipientItem(MRVDetailRecipient MRVDetailRecipient, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateMRVDetailRecipientItem";

                    param = cmd.Parameters.Add("@RecipientNum", SqlDbType.Int);
                    param.Value = MRVDetailRecipient.RecipientNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MRVDetailRecipient.ReferenceNum;

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVDetailRecipient.MRVNum;

                    param = cmd.Parameters.Add("@AcctNum", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.AcctNum;

                    param = cmd.Parameters.Add("@AcctName", SqlDbType.VarChar, 200);
                    param.Value = MRVDetailRecipient.AcctName;

                    param = cmd.Parameters.Add("@Address", SqlDbType.VarChar, 500);
                    param.Value = MRVDetailRecipient.Address;

                    param = cmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 200);
                    param.Value = MRVDetailRecipient.Remarks;

                    param = cmd.Parameters.Add("@ConStatus", SqlDbType.VarChar, 20);
                    param.Value = MRVDetailRecipient.ConStatus;

                    param = cmd.Parameters.Add("@StockDetailID", SqlDbType.Int);
                    param.Value = MRVDetailRecipient.StockDetailID;

                    param = cmd.Parameters.Add("@ProductCodeKWH", SqlDbType.Int);
                    param.Value = MRVDetailRecipient.ProductCodeKWH;

                    param = cmd.Parameters.Add("@ItemCodeKWH", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.ItemCodeKWH;

                    param = cmd.Parameters.Add("@ProductNameKWH", SqlDbType.VarChar, 1000);
                    param.Value = MRVDetailRecipient.ProductNameKWH;

                    param = cmd.Parameters.Add("@ProductDescKWH", SqlDbType.VarChar, 1000);
                    param.Value = MRVDetailRecipient.ProductDescKWH;

                    param = cmd.Parameters.Add("@BrandKWH", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.BrandKWH;

                    param = cmd.Parameters.Add("@SerialNoKWH", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.SerialNoKWH;

                    param = cmd.Parameters.Add("@CoopNoKWH", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.CoopNoKWH;

                    param = cmd.Parameters.Add("@ERCSerialNoKWH", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.ERCSerialNoKWH;

                    param = cmd.Parameters.Add("@ReadingKWH", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.ReadingKWH;

                    param = cmd.Parameters.Add("@ZoneNoKWH", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.ZoneNoKWH;

                    param = cmd.Parameters.Add("@CONoKWH", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.CONoKWH;

                    param = cmd.Parameters.Add("@StickerNoKWH", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.StickerNoKWH;

                    param = cmd.Parameters.Add("@ProductCodeSDW", SqlDbType.Int);
                    param.Value = MRVDetailRecipient.ProductCodeSDW;

                    param = cmd.Parameters.Add("@ItemCodeSDW", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.ItemCodeSDW;

                    param = cmd.Parameters.Add("@ProductNameSDW", SqlDbType.VarChar, 1000);
                    param.Value = MRVDetailRecipient.ProductNameSDW;

                    param = cmd.Parameters.Add("@ProductDescSDW", SqlDbType.VarChar, 1000);
                    param.Value = MRVDetailRecipient.ProductDescSDW;

                    param = cmd.Parameters.Add("@Length", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = MRVDetailRecipient.Length;

                    param = cmd.Parameters.Add("@Excess", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = MRVDetailRecipient.Excess;

                    param = cmd.Parameters.Add("@Amount", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = MRVDetailRecipient.Amount;

                    param = cmd.Parameters.Add("@ORNo", SqlDbType.VarChar, 50);
                    param.Value = MRVDetailRecipient.ORNo;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String RemoveMRVRecipient(String MRVNum, int RecipientNum, String ReferenceNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_RemoveMRVDetailRecipient";

                    param = cmd.Parameters.Add("@MRVNum", SqlDbType.VarChar, 20);
                    param.Value = MRVNum;

                    param = cmd.Parameters.Add("@RecipientNum", SqlDbType.Int);
                    param.Value = RecipientNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
    }
}
