﻿using anecoacct.WareHouseModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseClass
{
    class PurchaseOrderQueries
    {
        OtherQueries OtherQueries = new OtherQueries();
        public String UpdatePurchaseOrder(PurchaseOrder PurchaseOrder)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdatePurchaseOrder";

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrder.PurchaseOrderNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = PurchaseOrder.ReferenceNum;

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrder.RIVNum;

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrder.CanvassSheetNum;


                    param = cmd.Parameters.Add("@SupplierName", SqlDbType.VarChar, 500);
                    param.Value = PurchaseOrder.SupplierName;

                    param = cmd.Parameters.Add("@Vatable", SqlDbType.VarChar, 1);
                    param.Value = PurchaseOrder.Vatable;

                    param = cmd.Parameters.Add("@Vat", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = PurchaseOrder.Vat;

                    param = cmd.Parameters.Add("@TotalCost", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = PurchaseOrder.TotalCost;

                    param = cmd.Parameters.Add("@Terms", SqlDbType.VarChar, 200);
                    param.Value = PurchaseOrder.Terms;

                    param = cmd.Parameters.Add("@DeliveryPeriod", SqlDbType.VarChar, 200);
                    param.Value = PurchaseOrder.DeliveryPeriod;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String EditPurchaseOrder(String PurchaseOrderNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_EditPurchaseOrder";

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrderNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String SavePurchaseOrderDetail_TempBatch(String CanvassSheetNum, String ReferenceNumber, String SupplierName)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SavePurchaseOrderDetail_TempBatch";

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheetNum.Trim();

                    param = cmd.Parameters.Add("@ReferenceNumber", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNumber.Trim();

                    param = cmd.Parameters.Add("@SupplierName", SqlDbType.VarChar, 500);
                    param.Value = SupplierName.Trim();

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;
                    cmd.ExecuteNonQuery();

                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }


        public List<PurchaseOrderTermsOfPayments> GetTermsOfPaymentList (String Param, String Flag)
        {
            try
            {
                List<PurchaseOrderTermsOfPayments> PurchaseOrderTermsOfPaymentsList = new List<PurchaseOrderTermsOfPayments>();
                using (SqlCommand cmd= new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetPurchaseOrderTermsOfPayments";

                    param = cmd.Parameters.Add("@param", SqlDbType.VarChar, 20);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;
                    using (SqlDataReader dr =cmd.ExecuteReader())
                    {
                        if(dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                PurchaseOrderTermsOfPaymentsList.Add(new PurchaseOrderTermsOfPayments()
                                {
                                    ID = Convert.ToInt32(dr["PurchaseOrderTermsOfPaymentsID"].ToString())
                                    ,Code = Convert.ToString(dr["Code"].ToString())
                                });
                            }
                        }
                    }
                    return PurchaseOrderTermsOfPaymentsList;
                }
            }
            catch (Exception )
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String SavePurchaseOrder(PurchaseOrder PurchaseOrder)
        {
            try
            {
                //save RIV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SavePurchaseOrder";

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrder.ReferenceNum;

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrder.RIVNum;

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrder.CanvassSheetNum;

                    param = cmd.Parameters.Add("@SupplierName", SqlDbType.VarChar, 200);
                    param.Value = PurchaseOrder.SupplierName;

                    param = cmd.Parameters.Add("@Vatable", SqlDbType.VarChar, 1);
                    param.Value = PurchaseOrder.Vatable;

                    param = cmd.Parameters.Add("@Vat", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = PurchaseOrder.Vat;

                    param = cmd.Parameters.Add("@TotalCost", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = PurchaseOrder.TotalCost;

                    param = cmd.Parameters.Add("@Terms", SqlDbType.VarChar, 200);
                    param.Value = PurchaseOrder.Terms;

                    param = cmd.Parameters.Add("@DeliveryPeriod", SqlDbType.VarChar, 200);
                    param.Value = PurchaseOrder.DeliveryPeriod;
                    
                    param = cmd.Parameters.Add("@DateProcess", SqlDbType.DateTime);
                    param.Value = PurchaseOrder.DateProcess;
                    
                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewPurchaseOrderNum = Convert.ToString(cmd.Parameters["@PurchaseOrderNum"].Value.ToString());
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<PurchaseOrder> GetPurchaseOrderList(String Param, String Flag)
        {
            List<PurchaseOrder> PurchaseOrderList = new List<PurchaseOrder>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetPurchaseOrder";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                PurchaseOrderList.Add(new PurchaseOrder()
                                {
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    PurchaseOrderNum = Convert.ToString(dr["PurchaseOrderNum"].ToString())
                                    ,
                                    CanvassSheetNum = Convert.ToString(dr["CanvassSheetNum"].ToString())
                                    ,
                                    DateProcess = Convert.ToDateTime(dr["DateProcess"].ToString())
                                    ,
                                    RIVNum = Convert.ToString(dr["RIVNum"].ToString())                                    
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    SupplierName = Convert.ToString(dr["SupplierName"].ToString())
                                   ,
                                    TotalCost = Convert.ToDecimal(dr["TotalCost"].ToString())
                                    ,
                                    Status = Convert.ToString(dr["Status"].ToString())
                                    ,
                                    DeliveryStatus = Convert.ToString(dr["DeliveryStatus"].ToString())
                                    ,
                                    DeptCode = Convert.ToString(dr["DeptCode"].ToString())
                                         ,
                                    UserAccount = Convert.ToString(dr["AccountUse"].ToString())
                                });
                            }
                        }
                    }

                }
                return PurchaseOrderList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<PurchaseOrderDetail> GetPurchaseOrderDetailList(String Param, String Flag)
        {
            List<PurchaseOrderDetail> PurchaseOrderDetailList = new List<PurchaseOrderDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetPurchaseOrderDetail";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                PurchaseOrderDetailList.Add(new PurchaseOrderDetail()
                                {

                                   DateProcess = Convert.ToDateTime(dr["DateProcess"].ToString())
                                        ,
                                    PurchaseOrderNum = Convert.ToString(dr["PurchaseOrderNum"].ToString())
                                        ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                        ,
                                    RIVNum = Convert.ToString(dr["RIVNum"].ToString())
                                        ,
                                    RIVDate = Convert.ToDateTime(dr["RIVDate"].ToString())
                                        ,
                                    CanvassSheetNum = Convert.ToString(dr["CanvassSheetNum"].ToString())
                                        ,
                                    JONo = Convert.ToString(dr["JONo"].ToString())
                                        ,
                                    WONo = Convert.ToString(dr["wONo"].ToString())
                                        ,
                                    AwardedTo = Convert.ToString(dr["AwardedTo"].ToString())
                                        ,
                                    DeptCode = Convert.ToString(dr["DeptCode"].ToString())
                                        ,
                                    Requestor = Convert.ToString(dr["Requestor"].ToString())
                                        ,
                                    Vatable = Convert.ToString(dr["Vatable"].ToString())
                                        ,
                                    Vat = Convert.ToDecimal(dr["Vat"].ToString())
                                        ,
                                    Terms = Convert.ToString(dr["Terms"].ToString())
                                        ,
                                    DeliveryPeriod = Convert.ToString(dr["DeliveryPeriod"].ToString())
                                        ,
                                    SupplierName = Convert.ToString(dr["SupplierName"].ToString())

                                        ,
                                    Address = Convert.ToString(dr["SupplierAddress"].ToString())

                                        ,

                                    CanvassMatrixNum = Convert.ToInt32(dr["CanvassMatrixNum"].ToString())
                                        ,
                                    SupplierNo = Convert.ToInt32(dr["SupplierNo"].ToString())
                                        ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                        ,
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                        ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                        ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Unit"].ToString())
                                        ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    UnitCost = Convert.ToDecimal(dr["UnitCost"].ToString())
                                        ,
                                    TotalCost = Convert.ToDecimal(dr["TotalCost"].ToString())
                                      ,UnitCostPer = Convert.ToDecimal(dr["UnitCostPer"].ToString())
                                        ,
                                    TotalCostPer = Convert.ToDecimal(dr["TotalCostPer"].ToString())

                                    ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                      ,
                                    Units = Convert.ToString(dr["Units"].ToString())
                                       ,
                                    RIVDetailNum = Convert.ToInt32(dr["RIVDetailNum"].ToString())
                                });
                            }
                        }
                    }

                }
                return PurchaseOrderDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CancelPurchaseOrder(String PurchaseOrderNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CancelPurchaseOrder";

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrderNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String DeletePurchaseOrder(String PurchaseOrderNum,String RIVNum, String Status,String Remarks, String Notes)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_DeletePurchaseOrder";

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrderNum;

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = RIVNum;

                    param = cmd.Parameters.Add("@RIVStatus", SqlDbType.VarChar, 50);
                    param.Value = Status;

                    param = cmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 200);
                    param.Value = Remarks;

                    param = cmd.Parameters.Add("@Notes", SqlDbType.VarChar, 200);
                    param.Value = Notes;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String SavePurchaseOrderStatus(String PurchaseOrderNum, String RIVNum, String Status, String Remarks, String Notes)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SavePurchaseOrderStatus";

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrderNum;

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = RIVNum;

                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar, 50);
                    param.Value = Status;

                    param = cmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 200);
                    param.Value = Remarks;

                    param = cmd.Parameters.Add("@Notes", SqlDbType.VarChar, 200);
                    param.Value = Notes;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String GetPurchaseOrderCurrentStatus(String PurchaseOrderNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetPurchaseOrderCurrentStatus";

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrderNum;

                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Status"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemovePurchaseOrderItem(String ProductCode, String ReferenceNum, String CanvassSheetNum, String RIVNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_RemovePurchaseOrderItem";

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = ProductCode;

                    param = cmd.Parameters.Add("@POReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheetNum;

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = RIVNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<PurchaseOrderPrintType> GetPurchaseOrderPrintTypeList(String Param, String Flag)
        {
            try
            {
                List<PurchaseOrderPrintType> PurchaseOrderPrintTypeList = new List<PurchaseOrderPrintType>();
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetPurchaseOrderPrintType";

                    param = cmd.Parameters.Add("@param", SqlDbType.VarChar, 20);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                PurchaseOrderPrintTypeList.Add(new PurchaseOrderPrintType()
                                {
                                    PurchaseOrderPrintTypeNum = Convert.ToInt32(dr["PurchaseOrderPrintTypeNum"].ToString())
                                    ,
                                    PrintType = Convert.ToString(dr["PrintType"].ToString())
                                    ,Selected = Convert.ToString(dr["Selected"].ToString())
                                });
                            }
                        }
                    }
                    return PurchaseOrderPrintTypeList;
                }
            }
            catch (Exception)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String ChangePurchaseOrderPrintTypeSelected(String PrintType, String Selected)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_ChangePurchaseOrderPrintTypeSelected";

                    param = cmd.Parameters.Add("@PrintType", SqlDbType.VarChar,50);
                    param.Value = PrintType;

                    param = cmd.Parameters.Add("@Selected", SqlDbType.VarChar,1);
                    param.Value = Selected;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String AddPurchaseOrderItem(String ReferenceNumber,String PurchaseOrderNum,Int32 RIVDetailNum,String CanvassSheetNum, String SupplierName)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_AddPurchaseOrderItem";

                    param = cmd.Parameters.Add("@ReferenceNumber", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNumber.Trim();

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrderNum.Trim();

                    param = cmd.Parameters.Add("@RIVDetailNum", SqlDbType.Int);
                    param.Value = RIVDetailNum;

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheetNum.Trim();

                    param = cmd.Parameters.Add("@SupplierName", SqlDbType.VarChar, 500);
                    param.Value = SupplierName.Trim();

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();

                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String  GetPurchaseOrderDetailIntoReceivingReportDetailTemp(String PurchaseOrderNum, String RefNum,String RRType,String Flag)
        {
            try
            {
                using (SqlCommand cmd =new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetPurchaseOrderDetailIntoReceivingReportDetailTemp";

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = PurchaseOrderNum;
                    
                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = RefNum;

                    param = cmd.Parameters.Add("@RRType", SqlDbType.VarChar, 100);
                    param.Value = RRType;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar,500);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar,50);
                    param.Value = Flag;


                    cmd.ExecuteNonQuery();
                    return cmd.Parameters["@Message"].Value.ToString();
                }
                
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<PurchaseOrder> GetPurchaseOrderList_ByStatus(String Status, String Param, String Flag)
        {
            List<PurchaseOrder> PurchaseOrderList = new List<PurchaseOrder>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetPurchaseOrder_ByStatus";
                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar, 100);
                    param.Value = Status;
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                PurchaseOrderList.Add(new PurchaseOrder()
                                {
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    PurchaseOrderNum = Convert.ToString(dr["PurchaseOrderNum"].ToString())
                                    ,
                                    CanvassSheetNum = Convert.ToString(dr["CanvassSheetNum"].ToString())
                                    ,
                                    DateProcess = Convert.ToDateTime(dr["DateProcess"].ToString())
                                    ,
                                    RIVNum = Convert.ToString(dr["RIVNum"].ToString())
                                      ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()
                                      ,
                                    SupplierName = Convert.ToString(dr["SupplierName"].ToString())
                                   ,
                                    TotalCost = Convert.ToDecimal(dr["TotalCost"].ToString())
                                    ,
                                    Status = Convert.ToString(dr["Status"].ToString())
                                    ,
                                    DeliveryStatus = Convert.ToString(dr["DeliveryStatus"].ToString())
                                    ,
                                    DeptCode = Convert.ToString(dr["DeptCode"].ToString())
                                         ,
                                    UserAccount = Convert.ToString(dr["AccountUse"].ToString())
                                });
                            }
                        }
                    }

                }
                return PurchaseOrderList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CheckPurchaseOrderStatus(String PONum, String Action)
        {
            try
            {
                //save RIV Status
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckPOStatus";

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = PONum;

                    param = cmd.Parameters.Add("@Action", SqlDbType.VarChar, 50);
                    param.Value = Action;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }


        public String UpdatePurchaseOrderDetailItem_InTemp(PurchaseOrderDetail item)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdatePurchaseDetailItem_InTemp";

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = item.PurchaseOrderNum;

                    param = cmd.Parameters.Add("@CanvassMatrixNum", SqlDbType.Int);
                    param.Value = item.CanvassMatrixNum;

                    param = cmd.Parameters.Add("@UnitCost", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = item.UnitCost;

                    param = cmd.Parameters.Add("@TotalCost", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = item.TotalCost;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
    }
}
