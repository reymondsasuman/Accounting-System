﻿using anecoacct.WareHouseModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseClass
{
    class JobOrderQueries
    {
        OtherQueries OtherQueries = new OtherQueries();
        public String UpdateJobOrder(JobOrder JobOrder)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateJobOrder";

                    param = cmd.Parameters.Add("@JobOrderNum", SqlDbType.VarChar, 20);
                    param.Value = JobOrder.JobOrderNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = JobOrder.ReferenceNum;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 20);
                    param.Value = JobOrder.DeptCode;

                    param = cmd.Parameters.Add("@JOType", SqlDbType.VarChar, 20);
                    param.Value = JobOrder.JOType;

                    param = cmd.Parameters.Add("@TransNum", SqlDbType.VarChar, 20);
                    param.Value = JobOrder.TransNum;

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = JobOrder.RIVNum;

                    param = cmd.Parameters.Add("@WONo", SqlDbType.VarChar, 50);
                    param.Value = JobOrder.WONo;

                    param = cmd.Parameters.Add("@Purpose", SqlDbType.VarChar, 500);
                    param.Value = JobOrder.Purpose;

                    param = cmd.Parameters.Add("@SupplierName", SqlDbType.VarChar, 500);
                    param.Value = JobOrder.SupplierName;

                    param = cmd.Parameters.Add("@Address", SqlDbType.VarChar, 500);
                    param.Value = JobOrder.Address;

                    param = cmd.Parameters.Add("@TIN", SqlDbType.VarChar, 100);
                    param.Value = JobOrder.TIN;

                    param = cmd.Parameters.Add("@Vatable", SqlDbType.VarChar, 1);
                    param.Value = JobOrder.Vatable;

                    param = cmd.Parameters.Add("@Vat", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = JobOrder.Vat;

                    param = cmd.Parameters.Add("@TotalUnitCost", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = JobOrder.TotalUnitCost;

                    param = cmd.Parameters.Add("@TotalLaborCost", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = JobOrder.TotalLaborCost;

                    param = cmd.Parameters.Add("@OverAllCost", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = JobOrder.OverAllCost;

                    param = cmd.Parameters.Add("@Terms", SqlDbType.VarChar, 200);
                    param.Value = String.IsNullOrEmpty(JobOrder.Terms) ? "" : JobOrder.Terms;

                    param = cmd.Parameters.Add("@DeliveryPeriod", SqlDbType.VarChar, 200);
                    param.Value = String.IsNullOrEmpty(JobOrder.DeliveryPeriod) ? "" : JobOrder.DeliveryPeriod;

                    param = cmd.Parameters.Add("@DateProcess", SqlDbType.DateTime);
                    param.Value = JobOrder.DateProcess;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;
                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String EditJobOrder(String JobOrderNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_EditJobOrder";

                    param = cmd.Parameters.Add("@JobOrderNum", SqlDbType.VarChar, 20);
                    param.Value = JobOrderNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String SaveJobOrderDetail_TempBatch(String CanvassSheetNum, String ReferenceNumber, String SupplierName)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SavePurchaseOrderDetail_TempBatch";

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheetNum.Trim();

                    param = cmd.Parameters.Add("@ReferenceNumber", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNumber.Trim();

                    param = cmd.Parameters.Add("@SupplierName", SqlDbType.VarChar, 500);
                    param.Value = SupplierName.Trim();

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;
                    cmd.ExecuteNonQuery();

                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }


       
        
        public String SaveJobOrder(JobOrder JobOrder)
        {
            try
            {
                //save RIV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveJobOrder";

                    param = cmd.Parameters.Add("@JobOrderNum", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = JobOrder.ReferenceNum;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 20);
                    param.Value = JobOrder.DeptCode;

                    param = cmd.Parameters.Add("@JOType", SqlDbType.VarChar, 20);
                    param.Value = JobOrder.JOType;

                    param = cmd.Parameters.Add("@TransNum", SqlDbType.VarChar, 20);
                    param.Value = JobOrder.TransNum;

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = "";

                    param = cmd.Parameters.Add("@WONo", SqlDbType.VarChar, 50);
                    param.Value = JobOrder.WONo;

                    param = cmd.Parameters.Add("@Purpose", SqlDbType.VarChar, 500);
                    param.Value = JobOrder.Purpose;

                    param = cmd.Parameters.Add("@SupplierName", SqlDbType.VarChar, 500);
                    param.Value = JobOrder.SupplierName;

                    param = cmd.Parameters.Add("@Address", SqlDbType.VarChar, 500);
                    param.Value = JobOrder.Address;

                    param = cmd.Parameters.Add("@TIN", SqlDbType.VarChar, 100);
                    param.Value = JobOrder.TIN;

                    param = cmd.Parameters.Add("@Vatable", SqlDbType.VarChar, 1);
                    param.Value = JobOrder.Vatable;

                    param = cmd.Parameters.Add("@Vat", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = JobOrder.Vat;

                    param = cmd.Parameters.Add("@TotalUnitCost", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = JobOrder.TotalUnitCost;

                    param = cmd.Parameters.Add("@TotalLaborCost", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = JobOrder.TotalLaborCost;

                    param = cmd.Parameters.Add("@OverAllCost", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = JobOrder.OverAllCost;

                    param = cmd.Parameters.Add("@Terms", SqlDbType.VarChar, 200);
                    param.Value = String.IsNullOrEmpty(JobOrder.Terms)? "" : JobOrder.Terms;

                    param = cmd.Parameters.Add("@DeliveryPeriod", SqlDbType.VarChar, 200);
                    param.Value = String.IsNullOrEmpty(JobOrder.DeliveryPeriod) ? "" : JobOrder.DeliveryPeriod;

                    param = cmd.Parameters.Add("@DateProcess", SqlDbType.DateTime);
                    param.Value = JobOrder.DateProcess;
                    
                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewJobOrderNum = Convert.ToString(cmd.Parameters["@JobOrderNum"].Value.ToString());
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<JobOrder> GetJobOrderList(String Param, String Flag)
        {
            List<JobOrder> JobOrderList = new List<JobOrder>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetJobOrder";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                JobOrderList.Add(new JobOrder()
                                {
                                    JobOrderNum = Convert.ToString(dr["JobOrderNum"].ToString())
                                    ,
                                    DateProcess = Convert.ToDateTime(dr["DateProcess"].ToString())
                                    ,
                                    RIVNum = Convert.ToString(dr["RIVNum"].ToString())                                    
                                      ,
                                    SupplierName = Convert.ToString(dr["SupplierName"].ToString())
                                   ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                   ,
                                    TotalCost = Convert.ToDecimal(dr["OverAllCost"].ToString())
                                   ,
                                    JOType = Convert.ToString(dr["JOType"].ToString())
                                     ,
                                    TransNum = Convert.ToString(dr["TransNum"].ToString())
                                        ,
                                    DeptCode = Convert.ToString(dr["DeptCode"].ToString())
                                              ,
                                    Status = Convert.ToString(dr["Status"].ToString())
                                });
                            }
                        }
                    }

                }
                return JobOrderList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<JobOrder> GetJobOrderList_ByStatus(String Status, String Param, String Flag)
        {
            List<JobOrder> JobOrderList = new List<JobOrder>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetJobOrder_ByStatus";
                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar, 100);
                    param.Value = Status;
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                JobOrderList.Add(new JobOrder()
                                {
                                    JobOrderNum = Convert.ToString(dr["JobOrderNum"].ToString())
                                    ,
                                    DateProcess = Convert.ToDateTime(dr["DateProcess"].ToString())
                                    ,
                                    RIVNum = Convert.ToString(dr["RIVNum"].ToString())
                                      ,
                                    SupplierName = Convert.ToString(dr["SupplierName"].ToString())
                                   ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                   ,
                                    TotalCost = Convert.ToDecimal(dr["OverAllCost"].ToString())
                                   ,
                                    JOType = Convert.ToString(dr["JOType"].ToString())
                                     ,
                                    TransNum = Convert.ToString(dr["TransNum"].ToString())
                                        ,
                                    DeptCode = Convert.ToString(dr["DeptCode"].ToString())
                                              ,
                                    Status = Convert.ToString(dr["Status"].ToString())

                                });
                            }
                        }
                    }

                }
                return JobOrderList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<JobOrder> GetJobOrderListByDeptCode(String Param,String DeptCode, String Flag)
        {
            List<JobOrder> JobOrderList = new List<JobOrder>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetJobOrderByDeptCode";
                   
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 100);
                    param.Value = DeptCode;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                JobOrderList.Add(new JobOrder()
                                {
                                    JobOrderNum = Convert.ToString(dr["JobOrderNum"].ToString())
                                    ,
                                    DateProcess = Convert.ToDateTime(dr["DateProcess"].ToString())
                                    ,
                                    RIVNum = Convert.ToString(dr["RIVNum"].ToString())
                                      ,
                                    SupplierName = Convert.ToString(dr["SupplierName"].ToString())
                                   ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                   ,
                                    TotalCost = Convert.ToDecimal(dr["OverAllCost"].ToString())
                                   ,
                                    Status = Convert.ToString(dr["Status"].ToString())
                                   ,
                                    JOType = Convert.ToString(dr["JOType"].ToString())
                                     ,
                                    TransNum = Convert.ToString(dr["TransNum"].ToString())
                                        ,
                                    DeptCode = Convert.ToString(dr["DeptCode"].ToString())
                                });
                            }
                        }
                    }

                }
                return JobOrderList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<JobOrderDetail> GetJobOrderDetailList(String Param, String Flag)
        {
            List<JobOrderDetail> JobOrderDetailList = new List<JobOrderDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetJobOrderDetail";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                JobOrderDetailList.Add(new JobOrderDetail()
                                {
                                    DateProcess= Convert.ToDateTime(dr["DateProcess"].ToString())
                                   
                                    ,
                                    SupplierName = Convert.ToString(dr["SupplierName"].ToString())
                                    ,
                                    Address= Convert.ToString(dr["Address"].ToString())
                                    ,
                                    TIN = Convert.ToString(dr["TIN"].ToString())
                                    ,
                                    Vat= Convert.ToDecimal(dr["VAT"].ToString())
                                    ,
                                    Vatable = Convert.ToString(dr["Vatable"].ToString())
                                    ,
                                    Purpose = Convert.ToString(dr["Purpose"].ToString())
                                    ,
                                    JobOrderDetailNum =Convert.ToInt32(dr["JobOrderDetailNum"].ToString())
                                         ,
                                    JobOrderNum = Convert.ToString(dr["JobOrderNum"].ToString())
                                        ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                        ,
                                  
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                        ,
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                        ,
                                    JobOrderDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    UnitCost = Convert.ToDecimal(dr["UnitCost"].ToString())
                                        ,
                                    TotalCost = Convert.ToDecimal(dr["TotalCost"].ToString())

                                   ,Labor = Convert.ToDecimal(dr["Labor"].ToString())
                                   ,UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                    ,
                                    TransNum = Convert.ToString(dr["TransNum"].ToString())
                                     ,
                                    DeptCode = Convert.ToString(dr["DeptCode"].ToString())
                                      ,
                                    JOType = Convert.ToString(dr["JOType"].ToString())
                                      ,
                                    WONo = Convert.ToString(dr["WONo"].ToString())
                                });
                            }
                        }
                    }

                }
                return JobOrderDetailList;
            }
            catch (Exception ex)
            {
                  
                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CancelJobOrder(String RefNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CancelJobOrder";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = RefNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String DeleteJobOrder(String JobOrderNum,String RIVNum, String Status,String Remarks, String Notes)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_DeletePurchaseOrder";

                    param = cmd.Parameters.Add("@PurchaseOrderNum", SqlDbType.VarChar, 20);
                    param.Value = JobOrderNum;

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = RIVNum;

                    param = cmd.Parameters.Add("@RIVStatus", SqlDbType.VarChar, 50);
                    param.Value = Status;

                    param = cmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 200);
                    param.Value = Remarks;

                    param = cmd.Parameters.Add("@Notes", SqlDbType.VarChar, 200);
                    param.Value = Notes;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemoveJobOrderItem(String ProductCode, String ReferenceNum, String CanvassSheetNum, String RIVNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_RemovePurchaseOrderItem";

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = ProductCode;

                    param = cmd.Parameters.Add("@POReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@CanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = CanvassSheetNum;

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = RIVNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<JobOrderDetail> GetJobOrderDetailList_TempTable(String Param, String Flag)
        {
            List<JobOrderDetail> JobOrderDetailList = new List<JobOrderDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_GetJobOrderDetail_Temp";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                JobOrderDetailList.Add(new JobOrderDetail()
                                {

                                    
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    JobOrderDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                   
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,
                                    JobOrderDetailNum = Convert.ToInt32(dr["JobOrderDetailNum"].ToString())
                                         ,
                                    UnitCost = Convert.ToDecimal(dr["UnitCost"].ToString())
                                           ,
                                    Labor = Convert.ToDecimal(dr["Labor"].ToString())
                                           ,
                                    TotalCost = Convert.ToDecimal(dr["TotalCost"].ToString())
                                    ,
                                    UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                });
                            }
                        }
                    }

                }
                return JobOrderDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String AddJobOrderItem(JobOrderDetail JobOrderDetail, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_AddJobOrderItem";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = JobOrderDetail.ReferenceNum;

                    param = cmd.Parameters.Add("@RIVNum", SqlDbType.VarChar, 20);
                    param.Value = JobOrderDetail.RIVNum;

                    param = cmd.Parameters.Add("@JobOrderNum", SqlDbType.VarChar, 20);
                    param.Value = JobOrderDetail.JobOrderNum;

                    param = cmd.Parameters.Add("@JobOrderDesc", SqlDbType.VarChar, 500);
                    param.Value = JobOrderDetail.JobOrderDesc;

                    param = cmd.Parameters.Add("@UnitDesc", SqlDbType.VarChar, 20);
                    param.Value = JobOrderDetail.Unit;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = JobOrderDetail.Quantity;

                    param = cmd.Parameters.Add("@UnitCost", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = JobOrderDetail.UnitCost;

                    param = cmd.Parameters.Add("@LaborCost", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = JobOrderDetail.Labor;

                    param = cmd.Parameters.Add("@TotalCost", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = JobOrderDetail.TotalCost;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateJobOrderItem(JobOrderDetail JobOrderDetail, String Flag)
        {
            try
             {
                //update RIV item in temp table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_UpdateJobOrderItem";

                    param = cmd.Parameters.Add("@JobOrderDetailNum", SqlDbType.Int);
                    param.Value = JobOrderDetail.JobOrderDetailNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = JobOrderDetail.ReferenceNum;

                    param = cmd.Parameters.Add("@JobOrderDesc", SqlDbType.VarChar, 500);
                    param.Value = JobOrderDetail.JobOrderDesc;

                    param = cmd.Parameters.Add("@UnitDesc", SqlDbType.VarChar, 20);
                    param.Value = JobOrderDetail.Unit;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = JobOrderDetail.Quantity;

                    param = cmd.Parameters.Add("@UnitCost", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = JobOrderDetail.UnitCost;

                    param = cmd.Parameters.Add("@LaborCost", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = JobOrderDetail.Labor;

                    param = cmd.Parameters.Add("@TotalCost", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = JobOrderDetail.TotalCost;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemoveJobOrderItem(String JobOrderDetailNum, String ReferenceNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_RemoveJobOrderItem";

                    param = cmd.Parameters.Add("@JobOrderDetailNum", SqlDbType.VarChar, 20);
                    param.Value = JobOrderDetailNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }


        public String AddJobOrderItem_BatchFromJOR(String RefNum, String JORCanvassSheetNum, Int32 SupplierNo)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_AddJobOrderItem_BatchFromJOR";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = RefNum;

                    param = cmd.Parameters.Add("@JORCanvassSheetNum", SqlDbType.VarChar, 20);
                    param.Value = JORCanvassSheetNum;

                    param = cmd.Parameters.Add("@SupplierNo", SqlDbType.Int);
                    param.Value = SupplierNo;
 
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = "";

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String AddJobOrderItem_BatchFromMLC(String RefNum, String MLCNum, Int32 ContNo)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_AddJobOrderItem_BatchFromMLC";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = RefNum;

                    param = cmd.Parameters.Add("@MLCNum", SqlDbType.VarChar, 20);
                    param.Value = MLCNum;

                    param = cmd.Parameters.Add("@ContNo", SqlDbType.Int);
                    param.Value = ContNo;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = "";

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CheckJobOrderStatus(String JobOrderNum, String Action)
        {
            try
            {
                //save RIV Status
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_CheckJobOrderStatus";

                    param = cmd.Parameters.Add("@JobOrderNum", SqlDbType.VarChar, 20);
                    param.Value = JobOrderNum;

                    param = cmd.Parameters.Add("@Action", SqlDbType.VarChar, 50);
                    param.Value = Action;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String SaveJobOrderStatus(String JoborderNum, String Status, String Remarks, String Notes)
        {
            try
            {
                //save RIV Status
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "warehouse.sp_SaveJobOrderStatus";

                    param = cmd.Parameters.Add("@JoborderNum", SqlDbType.VarChar, 20);
                    param.Value = JoborderNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@JobOrderStatus", SqlDbType.VarChar, 50);
                    param.Value = Status;

                    param = cmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 200);
                    param.Value = Remarks;

                    param = cmd.Parameters.Add("@Notes", SqlDbType.VarChar, 200);
                    param.Value = Notes;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
    }
}
