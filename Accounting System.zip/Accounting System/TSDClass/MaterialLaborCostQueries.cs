﻿using anecoacct.TSDModel;
using anecoacct.WareHouseClass;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace anecoacct.TSDClass
{
    class MaterialLaborCostQueries
    {
        OtherQueries OtherQueries = new OtherQueries();
        public String SaveMaterialLaborCost(MaterialLaborCost MaterialLaborCost)
        {
            try
            {
                
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_SaveMaterialLaborCost";

                    param = cmd.Parameters.Add("@MLCNum", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MaterialLaborCost.ReferenceNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MaterialLaborCost.BranchName;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 20);
                    param.Value = MaterialLaborCost.DeptCode;

                    param = cmd.Parameters.Add("@CustNo", SqlDbType.Int);
                    param.Value = MaterialLaborCost.CustNo;

                    param = cmd.Parameters.Add("@Owner", SqlDbType.VarChar, 500);
                    param.Value = MaterialLaborCost.Owner;

                    param = cmd.Parameters.Add("@ProjType", SqlDbType.VarChar, 50);
                    param.Value = MaterialLaborCost.ProjType;

                    param = cmd.Parameters.Add("@ProjTitle", SqlDbType.VarChar, 1000);
                    param.Value = MaterialLaborCost.ProjTitle;

                    param = cmd.Parameters.Add("@Location", SqlDbType.VarChar, 1000);
                    param.Value = MaterialLaborCost.Location;

                    param = cmd.Parameters.Add("@PoleNum", SqlDbType.VarChar, 50);
                    param.Value = MaterialLaborCost.PoleNum;

                    param = cmd.Parameters.Add("@ContID", SqlDbType.Int);
                    param.Value = MaterialLaborCost.CustNo;

                    param = cmd.Parameters.Add("@ContName", SqlDbType.VarChar,500);
                    param.Value = MaterialLaborCost.ContName;

                    param = cmd.Parameters.Add("@ContAddress", SqlDbType.VarChar, 500);
                    param.Value = MaterialLaborCost.ContAddress;

                    param = cmd.Parameters.Add("@ContTIN", SqlDbType.VarChar, 50);
                    param.Value = MaterialLaborCost.ContTIN;

                    param = cmd.Parameters.Add("@MLCDate", SqlDbType.DateTime);
                    param.Value = MaterialLaborCost.MLCDate;

                    param = cmd.Parameters.Add("@EmpID", SqlDbType.VarChar, 30);
                    param.Value = MaterialLaborCost.EmpID;

                    param = cmd.Parameters.Add("@EmpType", SqlDbType.VarChar, 50);
                    param.Value = MaterialLaborCost.EmpType;

                    param = cmd.Parameters.Add("@CheckedByID", SqlDbType.VarChar, 50);
                    param.Value = MaterialLaborCost.CheckedByID;

                    param = cmd.Parameters.Add("@LaborPer", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = MaterialLaborCost.LaborPer;

                    param = cmd.Parameters.Add("@VAT", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = MaterialLaborCost.VAT;

                    param = cmd.Parameters.Add("@MaterialCost", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = MaterialLaborCost.MaterialCost;

                    param = cmd.Parameters.Add("@AddOnCost", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = MaterialLaborCost.AddOnCost;

                    param = cmd.Parameters.Add("@LaborCost", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = MaterialLaborCost.LaborCost;

                    param = cmd.Parameters.Add("@Evat", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = MaterialLaborCost.Evat;

                    param = cmd.Parameters.Add("@CostOfProj", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = MaterialLaborCost.CostOfProj;

                    param = cmd.Parameters.Add("@Payable", SqlDbType.VarChar, 1);
                    param.Value = MaterialLaborCost.Payable;

                    param = cmd.Parameters.Add("@TobePaidBy", SqlDbType.VarChar,200);
                    param.Value = MaterialLaborCost.ToBePaidBy;

                    param = cmd.Parameters.Add("@Type", SqlDbType.VarChar, 50);
                    param.Value = MaterialLaborCost.Type;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewMLCNum = Convert.ToString(cmd.Parameters["@MLCNum"].Value.ToString());
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateMaterialLaborCost(MaterialLaborCost MaterialLaborCost)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_UpdateMaterialLaborCost";

                    param = cmd.Parameters.Add("@MLCNum", SqlDbType.VarChar, 20);
                    param.Value = MaterialLaborCost.MLCNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MaterialLaborCost.ReferenceNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MaterialLaborCost.BranchName;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 20);
                    param.Value = MaterialLaborCost.DeptCode;

                    param = cmd.Parameters.Add("@CustNo", SqlDbType.Int);
                    param.Value = MaterialLaborCost.CustNo;

                    param = cmd.Parameters.Add("@Owner", SqlDbType.VarChar, 500);
                    param.Value = MaterialLaborCost.Owner;

                    param = cmd.Parameters.Add("@ProjType", SqlDbType.VarChar, 50);
                    param.Value = MaterialLaborCost.ProjType;

                    param = cmd.Parameters.Add("@ProjTitle", SqlDbType.VarChar, 1000);
                    param.Value = MaterialLaborCost.ProjTitle;

                    param = cmd.Parameters.Add("@Location", SqlDbType.VarChar, 1000);
                    param.Value = MaterialLaborCost.Location;

                    param = cmd.Parameters.Add("@PoleNum", SqlDbType.VarChar, 50);
                    param.Value = MaterialLaborCost.PoleNum;

                    param = cmd.Parameters.Add("@ContID", SqlDbType.Int);
                    param.Value = MaterialLaborCost.CustNo;

                    param = cmd.Parameters.Add("@ContName", SqlDbType.VarChar, 500);
                    param.Value = MaterialLaborCost.ContName;

                    param = cmd.Parameters.Add("@ContAddress", SqlDbType.VarChar, 500);
                    param.Value = MaterialLaborCost.ContAddress;

                    param = cmd.Parameters.Add("@ContTIN", SqlDbType.VarChar, 50);
                    param.Value = MaterialLaborCost.ContTIN;

                    param = cmd.Parameters.Add("@MLCDate", SqlDbType.DateTime);
                    param.Value = MaterialLaborCost.MLCDate;

                    param = cmd.Parameters.Add("@EmpID", SqlDbType.VarChar, 30);
                    param.Value = MaterialLaborCost.EmpID;

                    param = cmd.Parameters.Add("@EmpType", SqlDbType.VarChar, 50);
                    param.Value = MaterialLaborCost.EmpType;

                    param = cmd.Parameters.Add("@CheckedByID", SqlDbType.VarChar, 50);
                    param.Value = MaterialLaborCost.CheckedByID;

                    param = cmd.Parameters.Add("@LaborPer", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = MaterialLaborCost.LaborPer;

                    param = cmd.Parameters.Add("@VAT", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = MaterialLaborCost.VAT;

                    param = cmd.Parameters.Add("@MaterialCost", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = MaterialLaborCost.MaterialCost;

                    param = cmd.Parameters.Add("@AddOnCost", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = MaterialLaborCost.AddOnCost;

                    param = cmd.Parameters.Add("@LaborCost", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = MaterialLaborCost.LaborCost;

                    param = cmd.Parameters.Add("@Evat", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = MaterialLaborCost.Evat;

                    param = cmd.Parameters.Add("@CostOfProj", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = MaterialLaborCost.CostOfProj;


                    param = cmd.Parameters.Add("@Payable", SqlDbType.VarChar, 1);
                    param.Value = MaterialLaborCost.Payable;

                    param = cmd.Parameters.Add("@TobePaidBy", SqlDbType.VarChar, 200);
                    param.Value = MaterialLaborCost.ToBePaidBy;

                    param = cmd.Parameters.Add("@Type", SqlDbType.VarChar, 50);
                    param.Value = MaterialLaborCost.Type;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<MaterialLaborCost> GetMaterialLaborCostList(String Param,String DeptCode, String BranchName, String Flag)
        {
            List<MaterialLaborCost> MaterialLaborCostList = new List<MaterialLaborCost>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_GetMaterialLaborCost";
                    
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 20);
                    param.Value = DeptCode;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MaterialLaborCostList.Add(new MaterialLaborCost()
                                {
                                    MLCNum = Convert.ToString(dr["MLCNum"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    BranchName = Convert.ToString(dr["BranchName"].ToString())
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                     ,
                                    CustNo = String.IsNullOrEmpty(dr["CustNo"].ToString()) ? 0 : Convert.ToInt32(dr["CustNo"].ToString())
                                     ,
                                    Owner = String.IsNullOrEmpty(dr["Owner"].ToString()) ? "" : dr["Owner"].ToString()
                                      ,
                                    ProjType = String.IsNullOrEmpty(dr["ProjType"].ToString()) ? "" : dr["ProjType"].ToString()
                                     ,
                                    ProjTitle = String.IsNullOrEmpty(dr["ProjTitle"].ToString()) ? "" : dr["ProjTitle"].ToString()
                                    ,
                                     Location= String.IsNullOrEmpty(dr["Location"].ToString()) ? "" : dr["Location"].ToString()
                                    ,
                                    PoleNum = String.IsNullOrEmpty(dr["PoleNum"].ToString()) ? "" : dr["PoleNum"].ToString()
                                    ,
                                    ContID = String.IsNullOrEmpty(dr["ContID"].ToString()) ? 0 : Convert.ToInt32(dr["ContID"].ToString())
                                     ,
                                    ContName = String.IsNullOrEmpty(dr["ContName"].ToString()) ? "" : dr["ContName"].ToString()
                                    ,
                                    ContAddress = String.IsNullOrEmpty(dr["ContAddress"].ToString()) ? "" : dr["ContAddress"].ToString()
                                    ,
                                    ContTIN = String.IsNullOrEmpty(dr["ContTIN"].ToString()) ? "" : dr["ContTIN"].ToString()
                                    ,
                                    MLCDate =Convert.ToDateTime(dr["MLCDate"].ToString()) 
                                    ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())
                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()

                                    ,
                                     CheckedByID  = Convert.ToString(dr["CheckedByID"].ToString())
                                   ,
                                    CheckedByName = Convert.ToString(dr["CheckedByName"].ToString())
                                 ,
                                    Status = String.IsNullOrEmpty(dr["MLCStatus"].ToString()) ? "" : dr["MLCStatus"].ToString()
                                    ,
                                    LaborPer = Convert.ToDecimal(dr["LaborPer"].ToString())
                                    ,
                                    VAT = Convert.ToDecimal(dr["VAT"].ToString())
                                    ,
                                    MaterialCost = Convert.ToDecimal(dr["MaterialCost"].ToString())
                                    ,
                                    AddOnCost = Convert.ToDecimal(dr["AddOnCost"].ToString())
                                    ,
                                    LaborCost = Convert.ToDecimal(dr["LaborCost"].ToString())
                                    ,
                                    Evat = Convert.ToDecimal(dr["Evat"].ToString())
                                    ,
                                    CostOfProj = Convert.ToDecimal(dr["CostOfProj"].ToString())
                                    ,
                                    UserAccount = Convert.ToString(dr["AccountUse"].ToString())
                                    ,
                                    Payable = Convert.ToString(dr["Payable"].ToString())
                                    ,
                                    ToBePaidBy = Convert.ToString(dr["ToBePaidBy"].ToString())
                                          ,
                                    Paid = Convert.ToString(dr["Paid"].ToString())
                                          ,
                                    Type = Convert.ToString(dr["Type"].ToString())
                                });
                            }
                        }
                    }

                }
                return MaterialLaborCostList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<MaterialLaborCost> GetMaterialLaborCostList_Filter(String Param, String DeptCode, String BranchName, String Status,String Flag)
        {
            List<MaterialLaborCost> MaterialLaborCostList = new List<MaterialLaborCost>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_GetMaterialLaborCost_Filter";

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@DeptCode", SqlDbType.VarChar, 20);
                    param.Value = DeptCode;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;


                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar, 100);
                    param.Value = Status;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MaterialLaborCostList.Add(new MaterialLaborCost()
                                {
                                    MLCNum = Convert.ToString(dr["MLCNum"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    BranchName = Convert.ToString(dr["BranchName"].ToString())
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                     ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                      ,
                                    DeptCode = String.IsNullOrEmpty(dr["DeptCode"].ToString()) ? "" : dr["DeptCode"].ToString()
                                     ,
                                    CustNo = String.IsNullOrEmpty(dr["CustNo"].ToString()) ? 0 : Convert.ToInt32(dr["CustNo"].ToString())
                                     ,
                                    Owner = String.IsNullOrEmpty(dr["Owner"].ToString()) ? "" : dr["Owner"].ToString()
                                      ,
                                    ProjType = String.IsNullOrEmpty(dr["ProjType"].ToString()) ? "" : dr["ProjType"].ToString()
                                     ,
                                    ProjTitle = String.IsNullOrEmpty(dr["ProjTitle"].ToString()) ? "" : dr["ProjTitle"].ToString()
                                    ,
                                    Location = String.IsNullOrEmpty(dr["Location"].ToString()) ? "" : dr["Location"].ToString()
                                    ,
                                    PoleNum = String.IsNullOrEmpty(dr["PoleNum"].ToString()) ? "" : dr["PoleNum"].ToString()
                                    ,
                                    ContID = String.IsNullOrEmpty(dr["ContID"].ToString()) ? 0 : Convert.ToInt32(dr["ContID"].ToString())
                                     ,
                                    ContName = String.IsNullOrEmpty(dr["ContName"].ToString()) ? "" : dr["ContName"].ToString()
                                    ,
                                    ContAddress = String.IsNullOrEmpty(dr["ContAddress"].ToString()) ? "" : dr["ContAddress"].ToString()
                                    ,
                                    ContTIN = String.IsNullOrEmpty(dr["ContTIN"].ToString()) ? "" : dr["ContTIN"].ToString()
                                    ,
                                    MLCDate = Convert.ToDateTime(dr["MLCDate"].ToString())
                                    ,
                                    EmpID = Convert.ToString(dr["EmpID"].ToString())
                                   ,
                                    EmpType = Convert.ToString(dr["EmpType"].ToString())
                                    ,
                                    Requestor = String.IsNullOrEmpty(dr["Requestor"].ToString()) ? "" : dr["Requestor"].ToString()

                                    ,
                                    CheckedByID = Convert.ToString(dr["CheckedByID"].ToString())
                                   ,
                                    CheckedByName = Convert.ToString(dr["CheckedByName"].ToString())
                                 ,
                                    Status = String.IsNullOrEmpty(dr["MLCStatus"].ToString()) ? "" : dr["MLCStatus"].ToString()
                                    ,
                                    LaborPer = Convert.ToDecimal(dr["LaborPer"].ToString())
                                    ,
                                    VAT = Convert.ToDecimal(dr["VAT"].ToString())
                                    ,
                                    MaterialCost = Convert.ToDecimal(dr["MaterialCost"].ToString())
                                    ,
                                    AddOnCost = Convert.ToDecimal(dr["AddOnCost"].ToString())
                                    ,
                                    LaborCost = Convert.ToDecimal(dr["LaborCost"].ToString())
                                    ,
                                    Evat = Convert.ToDecimal(dr["Evat"].ToString())
                                    ,
                                    CostOfProj = Convert.ToDecimal(dr["CostOfProj"].ToString())
                                    ,
                                    UserAccount = Convert.ToString(dr["AccountUse"].ToString())
                                    ,
                                    Payable = Convert.ToString(dr["Payable"].ToString())
                                    ,
                                    ToBePaidBy = Convert.ToString(dr["ToBePaidBy"].ToString())
                                    ,Type = Convert.ToString(dr["Type"].ToString())
                                });
                            }
                        }
                    }

                }
                return MaterialLaborCostList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String EditMaterialLaborCost(String ReferenceNum, String MLCNum)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_EditMaterialLaborCost";

                    param = cmd.Parameters.Add("@MLCNum", SqlDbType.VarChar, 20);
                    param.Value = MLCNum;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String CancelMaterialLaborCost(String ReferenceNum, String MLCNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_CancelMaterialLaborCost";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@MLCNum", SqlDbType.VarChar, 20);
                    param.Value = MLCNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String CheckMLCOwner(String MLCNum, Int32 UserID)
        {
            try
            {
                //save MRV Status
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_CheckMaterialLaborCostOwner";

                    param = cmd.Parameters.Add("@MLCNum", SqlDbType.VarChar, 20);
                    param.Value = MLCNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 200);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String GetMaterialLaborCostCurrentStatus(String MLCNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_GetMaterialLaborCostCurrentStatus";

                    param = cmd.Parameters.Add("@MLCNum", SqlDbType.VarChar, 20);
                    param.Value = MLCNum;

                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar, 50);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Status"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String DeleteMaterialLaborCost(String MLCNum, String MLCStatus, String BranchName)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_DeleteMaterialLaborCost";

                    param = cmd.Parameters.Add("@MLCNum", SqlDbType.VarChar, 20);
                    param.Value = MLCNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String GetMaterialLaborCostItemDetail_IntoMRVSummary_Temp(String MLCNum, String MRVRefNum,DateTime MRVDate, String BranchName
             )
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_GetMaterialLaborCostItemDetail_IntoMRVSummary_Temp";

                    param = cmd.Parameters.Add("@MLCNum", SqlDbType.VarChar, 20);
                    param.Value = MLCNum;

                    param = cmd.Parameters.Add("@MRVRefNum", SqlDbType.VarChar, 20);
                    param.Value = MRVRefNum;

                    param = cmd.Parameters.Add("@MRVDate", SqlDbType.DateTime);
                    param.Value = MRVDate;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@InsertStatus", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.MLC_MRV_InsertStatus = Convert.ToString(cmd.Parameters["@InsertStatus"].Value);
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<MaterialLaborCostItemDetail> GetMaterialLaborCostItemDetail_MRVSummary_Temp(String Param, String Flag)
        {
            try
            {
                int tempSortKey;
                List<MaterialLaborCostItemDetail> MaterialLaborCostItemDetail_MRVSummary_TempList = new List<MaterialLaborCostItemDetail>();
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_GetMaterialLaborCostItemDetail_MRVSummary_Temp";

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 20);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                if (Convert.ToDecimal(dr["ActualAvailable"].ToString())==0)
                                {
                                    tempSortKey = 1;
                                }
                                else if (Convert.ToDecimal(dr["ActualAvailable"].ToString())< Convert.ToDecimal(dr["Quantity"].ToString()))
                                {
                                    tempSortKey = 2;
                                }
                                else
                                {
                                    tempSortKey = 3;
                                }
                                MaterialLaborCostItemDetail_MRVSummary_TempList.Add(new MaterialLaborCostItemDetail()
                                {

                                    MLCNum = Convert.ToString(dr["MLCNum"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Available = Convert.ToDecimal(dr["ActualAvailable"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,                                 
                                    UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                   
                                    ,SortKey = tempSortKey

                                });
                            }
                        }
                    }

                }
                return MaterialLaborCostItemDetail_MRVSummary_TempList;

            
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String AddBatchMRVItemFromMLC(String RefNum,String MLCNum, String BranchName, String Purpose)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_AddMRVItem_BatchFromMLC";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = RefNum;

                    param = cmd.Parameters.Add("@MLCNum", SqlDbType.VarChar, 20);
                    param.Value = MLCNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@Purpose", SqlDbType.VarChar, 800);
                    param.Value = Purpose;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<MaterialLaborCostProjType> GetMaterialLaborCostProjTypeList(String Param, String Flag)
        {
            List<MaterialLaborCostProjType> MaterialLaborCostOwnerTypeList = new List<MaterialLaborCostProjType>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_GetMaterialLaborCostProjType";

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MaterialLaborCostOwnerTypeList.Add(new MaterialLaborCostProjType()
                                {
                                    TypeCode = Convert.ToInt32(dr["TypeCode"].ToString())
                                    ,
                                    TypeName = Convert.ToString(dr["TypeName"].ToString())
                                    ,
                                    TypeDesc = Convert.ToString(dr["TypeDesc"].ToString())
                                      ,
                                    PriceBased = Convert.ToString(dr["PriceBased"].ToString())

                                });
                            }
                        }
                    }

                }
                return MaterialLaborCostOwnerTypeList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String CheckMaterialLaborCostStatus(String MLCNum, String Action)
        {
            try
            {
                //save MRV Status
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_CheckMLCStatus";

                    param = cmd.Parameters.Add("@MLCNum", SqlDbType.VarChar, 20);
                    param.Value = MLCNum;

                    param = cmd.Parameters.Add("@Action", SqlDbType.VarChar, 50);
                    param.Value = Action;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String SaveMLCStatus(String MLCNum, String Status, String Remarks, String Notes)
        {
            try
            {
                //save MRV Status
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_SaveMLCStatus";

                    param = cmd.Parameters.Add("@MLCNum", SqlDbType.VarChar, 20);
                    param.Value = MLCNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@MLCStatus", SqlDbType.VarChar, 50);
                    param.Value = Status;

                    param = cmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 200);
                    param.Value = Remarks;

                    param = cmd.Parameters.Add("@Notes", SqlDbType.VarChar, 200);
                    param.Value = Notes;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String GetMLCCurrentStatus(String MLCNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_GetMLCCurrentStatus";

                    param = cmd.Parameters.Add("@MLCNum", SqlDbType.VarChar, 20);
                    param.Value = MLCNum;

                    param = cmd.Parameters.Add("@Status", SqlDbType.VarChar, 50);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Status"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }


    }
}
