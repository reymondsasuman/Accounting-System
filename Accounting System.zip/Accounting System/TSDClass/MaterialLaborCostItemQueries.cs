﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using anecoacct.TSDModel;
using anecoacct.WareHouseClass;

namespace anecoacct.TSDClass
{
    class MaterialLaborCostItemQueries
    {
        OtherQueries OtherQueries = new OtherQueries();
        modFunctions modFunctions = new modFunctions(); 
        public List<MaterialLaborCostItemDetail> GetMaterialLaborCostItemDetailList_TempTable(String Param, String Flag)
        {
            List<MaterialLaborCostItemDetail> MaterialLaborCostItemDetailList = new List<MaterialLaborCostItemDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_GetMaterialLaborCostItemDetail_Temp";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MaterialLaborCostItemDetailList.Add(new MaterialLaborCostItemDetail()
                                {

                                    MLCNum = Convert.ToString(dr["MLCNum"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())                                 
                                    ,
                                    ItemCode = Convert.ToString(dr["ItemCode"].ToString())
                                    ,
                                    ProductCode = Convert.ToInt32(dr["ProductCode"].ToString())
                                         ,
                                    ProductDesc = Convert.ToString(dr["ProductDesc"].ToString())
                                         ,
                                    ProductName = Convert.ToString(dr["ProductName"].ToString())
                                         ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,
                                    MLCItemDetailCode = Convert.ToInt32(dr["MLCItemDetailCode"].ToString())
                                       ,
                                   NEAPrice = Convert.ToString(dr["NEAPrice"].ToString())
                                        ,
                                    PriceMonth = modFunctions.GetMonthStringUpper(Convert.ToString(dr["PriceMonth"].ToString()))
                                        ,
                                    PriceYear = Convert.ToString(dr["PriceYear"].ToString())
                                        ,
                                    UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                    
                                    ,UnitCost = Convert.ToDecimal(dr["UnitPrice"].ToString())

                                    ,
                                    TotalCost = Convert.ToDecimal(dr["TotalPrice"].ToString())
                                    ,
                                    SubClassID = Convert.ToInt32(dr["SubClassID"].ToString())
                                    ,
                                    ProjectType = Convert.ToString(dr["ProjectType"].ToString())
                                                                        ,
                                    ProjectClass = Convert.ToString(dr["ProjectClass"].ToString())
                                                                        ,
                                    SubClass = Convert.ToString(dr["SubClass"].ToString())
                                                                        ,
                                    SubClassDesc = Convert.ToString(dr["SubClassDesc"].ToString())
                                                                         ,
                                    ExcludeInLabor = Convert.ToString(dr["ExcludeInLabor"].ToString())
                                });
                            }
                        }
                    }

                }
                return MaterialLaborCostItemDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String AddMaterialLaborCostItem(MaterialLaborCostItemDetail MaterialLaborCostItemDetail, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                     cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_AddMaterialLaborCostItem";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MaterialLaborCostItemDetail.ReferenceNum;

                    param = cmd.Parameters.Add("@MLCNum", SqlDbType.VarChar, 20);
                    param.Value = MaterialLaborCostItemDetail.MLCNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MaterialLaborCostItemDetail.BranchName;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = MaterialLaborCostItemDetail.ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = String.IsNullOrEmpty(MaterialLaborCostItemDetail.ItemCode) ? "" : MaterialLaborCostItemDetail.ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 1000);
                    param.Value = MaterialLaborCostItemDetail.ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar, 1000);
                    param.Value = MaterialLaborCostItemDetail.ProductDesc;

                    param = cmd.Parameters.Add("@UnitDesc", SqlDbType.VarChar, 20);
                    param.Value = MaterialLaborCostItemDetail.Unit;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = MaterialLaborCostItemDetail.Quantity;

                    param = cmd.Parameters.Add("@UnitPrice", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = MaterialLaborCostItemDetail.UnitCost;

                    param = cmd.Parameters.Add("@TotalPrice", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = MaterialLaborCostItemDetail.TotalCost;

                    param = cmd.Parameters.Add("@NEAPrice", SqlDbType.VarChar,1);
                    param.Value = MaterialLaborCostItemDetail.NEAPrice;

                    param = cmd.Parameters.Add("@PriceMonth", SqlDbType.VarChar, 2);
                    param.Value = MaterialLaborCostItemDetail.PriceMonth;

                    param = cmd.Parameters.Add("@PriceYear", SqlDbType.VarChar, 4);
                    param.Value = MaterialLaborCostItemDetail.PriceYear;

                    param = cmd.Parameters.Add("@SubClassID", SqlDbType.Int);
                    param.Value = MaterialLaborCostItemDetail.SubClassID;

                    param = cmd.Parameters.Add("@ExcludeInLabor", SqlDbType.VarChar, 1);
                    param.Value = MaterialLaborCostItemDetail.ExcludeInLabor;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateMaterialLaborCostItem(MaterialLaborCostItemDetail MaterialLaborCostItemDetail)
        {
            try
            {
                //update MRV item in temp table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_UpdateMaterialLaborCostItem";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = MaterialLaborCostItemDetail.ReferenceNum;

                    param = cmd.Parameters.Add("@MLCNum", SqlDbType.VarChar, 20);
                    param.Value = MaterialLaborCostItemDetail.MLCNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MaterialLaborCostItemDetail.BranchName;

                    param = cmd.Parameters.Add("@ProductCode", SqlDbType.Int);
                    param.Value = MaterialLaborCostItemDetail.ProductCode;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = String.IsNullOrEmpty(MaterialLaborCostItemDetail.ItemCode) ? "" : MaterialLaborCostItemDetail.ItemCode;

                    param = cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 1000);
                    param.Value = MaterialLaborCostItemDetail.ProductName;

                    param = cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar, 1000);
                    param.Value = MaterialLaborCostItemDetail.ProductDesc;

                    param = cmd.Parameters.Add("@UnitDesc", SqlDbType.VarChar, 20);
                    param.Value = MaterialLaborCostItemDetail.Unit;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = MaterialLaborCostItemDetail.Quantity;

                    param = cmd.Parameters.Add("@UnitPrice", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = MaterialLaborCostItemDetail.UnitCost;

                    param = cmd.Parameters.Add("@TotalPrice", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = MaterialLaborCostItemDetail.TotalCost;

                    param = cmd.Parameters.Add("@NEAPrice", SqlDbType.VarChar, 1);
                    param.Value = MaterialLaborCostItemDetail.NEAPrice;

                    param = cmd.Parameters.Add("@PriceMonth", SqlDbType.VarChar, 2);
                    param.Value = MaterialLaborCostItemDetail.PriceMonth;

                    param = cmd.Parameters.Add("@PriceYear", SqlDbType.VarChar, 4);
                    param.Value = MaterialLaborCostItemDetail.PriceYear;

                    param = cmd.Parameters.Add("@SubClassID", SqlDbType.Int);
                    param.Value = MaterialLaborCostItemDetail.SubClassID;

                    param = cmd.Parameters.Add("@ExcludeInLabor", SqlDbType.VarChar, 1);
                    param.Value = MaterialLaborCostItemDetail.ExcludeInLabor;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String CancelMaterialLaborCost(String ReferenceNum, String MLCNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_CancelMaterialLaborCost";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@MLCNum", SqlDbType.VarChar, 20);
                    param.Value = MLCNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemoveMaterialLaborCostItem(String MLCNum, String ItemCode, String ReferenceNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_RemoveMaterialLaborCostItem";

                    param = cmd.Parameters.Add("@MLCNum", SqlDbType.VarChar, 20);
                    param.Value = MLCNum;

                    param = cmd.Parameters.Add("@ItemCode", SqlDbType.VarChar, 50);
                    param.Value = ItemCode;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }







        /// <summary>
        /// ///////ADD ON CHARGES QUERIES
        /// </summary>
   
        /// <returns></returns>


        public List<MaterialLaborCostAddOnDetail> GetMaterialLaborCostAddOnDetailList_TempTable(String Param, String Flag)
        {
            List<MaterialLaborCostAddOnDetail> MaterialLaborCostAddOnDetailList = new List<MaterialLaborCostAddOnDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_GetMaterialLaborCostAddOnDetail_Temp";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MaterialLaborCostAddOnDetailList.Add(new MaterialLaborCostAddOnDetail()
                                {

                                    MLCNum = Convert.ToString(dr["MLCNum"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,                              
                                    LaborDesc = Convert.ToString(dr["LaborDesc"].ToString())
                                    ,
                                    Quantity = Convert.ToDecimal(dr["Quantity"].ToString())
                                        ,
                                    Unit = Convert.ToString(dr["Units"].ToString())
                                        ,
                                    MLCAddOnDetailCode = Convert.ToInt32(dr["MLCAddOnDetailCode"].ToString())
                                    ,
                                    UnitSingular = Convert.ToString(dr["Unit"].ToString())
                                    ,
                                    UnitCost = Convert.ToDecimal(dr["UnitCost"].ToString())
                                    ,
                                    TotalCost = Convert.ToDecimal(dr["TotalCost"].ToString())
 
                                });
                            }
                        }
                    }

                }
                return MaterialLaborCostAddOnDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String AddMaterialLaborCostAddOn(MaterialLaborCostAddOnDetail MaterialLaborCostAddOnDetail, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_AddMaterialLaborCostAddOn";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MaterialLaborCostAddOnDetail.ReferenceNum;

                    param = cmd.Parameters.Add("@MLCNum", SqlDbType.VarChar, 20);
                    param.Value = MaterialLaborCostAddOnDetail.MLCNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MaterialLaborCostAddOnDetail.BranchName;

                    param = cmd.Parameters.Add("@LaborDesc", SqlDbType.VarChar, 1000);
                    param.Value = MaterialLaborCostAddOnDetail.LaborDesc;

                    param = cmd.Parameters.Add("@UnitDesc", SqlDbType.VarChar, 20);
                    param.Value = MaterialLaborCostAddOnDetail.Unit;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = MaterialLaborCostAddOnDetail.Quantity;

                    param = cmd.Parameters.Add("@UnitPrice", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = MaterialLaborCostAddOnDetail.UnitCost;

                    param = cmd.Parameters.Add("@TotalPrice", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = MaterialLaborCostAddOnDetail.TotalCost;

                   
                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String RemoveMaterialLaborCostAddOn(String MLCNum, Int32 MLCAddOnDetailCode, String ReferenceNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_RemoveMaterialLaborCostAddOn";

                    param = cmd.Parameters.Add("@MLCNum", SqlDbType.VarChar, 20);
                    param.Value = MLCNum;

                    param = cmd.Parameters.Add("@MLCAddOnDetailCode", SqlDbType.Int);
                    param.Value = MLCAddOnDetailCode;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String UpdateMaterialLaborCostAddOn(MaterialLaborCostAddOnDetail MaterialLaborCostAddOnDetail)
        {
            try
            {
                //update MRV item in temp table
                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_UpdateMaterialLaborCostAddOn";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = MaterialLaborCostAddOnDetail.ReferenceNum;

                    param = cmd.Parameters.Add("@MLCNum", SqlDbType.VarChar, 20);
                    param.Value = MaterialLaborCostAddOnDetail.MLCNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 100);
                    param.Value = MaterialLaborCostAddOnDetail.BranchName;

                    param = cmd.Parameters.Add("@MLCAddOnDetailCode", SqlDbType.Int);
                    param.Value = MaterialLaborCostAddOnDetail.MLCAddOnDetailCode;

                    param = cmd.Parameters.Add("@LaborDesc", SqlDbType.VarChar, 1000);
                    param.Value = MaterialLaborCostAddOnDetail.LaborDesc;

                    param = cmd.Parameters.Add("@UnitDesc", SqlDbType.VarChar, 20);
                    param.Value = MaterialLaborCostAddOnDetail.Unit;

                    param = cmd.Parameters.Add("@Quantity", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = MaterialLaborCostAddOnDetail.Quantity;

                    param = cmd.Parameters.Add("@UnitPrice", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = MaterialLaborCostAddOnDetail.UnitCost;

                    param = cmd.Parameters.Add("@TotalPrice", SqlDbType.Decimal);
                    param.Scale = 6;
                    param.Precision = 18;
                    param.Value = MaterialLaborCostAddOnDetail.TotalCost;

                    param = cmd.Parameters.Add("@ComputerName", SqlDbType.VarChar, 25);
                    param.Value = System.Environment.MachineName;

                    param = cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 25);
                    param.Value = Convert.ToString(OtherQueries.LocalIPAddress());

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 1000);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }



        public List<MaterialLaborCostAddOnRegistry> GetMaterialLaborCostAddOnRegistryList(String Param, String Flag)
        {
            List<MaterialLaborCostAddOnRegistry> MaterialLaborCostAddOnRegistryList = new List<MaterialLaborCostAddOnRegistry>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "eng.sp_GetMaterialLaborCostAddOnRegistry";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MaterialLaborCostAddOnRegistryList.Add(new MaterialLaborCostAddOnRegistry()
                                {

                                    ID = Convert.ToInt32(dr["MLCAddOnRegistryCode"].ToString())
                                    ,
                                    AddOnDesc = Convert.ToString(dr["AddOnDesc"].ToString())
                                    ,
                                    UnitID = Convert.ToInt32(dr["UnitID"].ToString())
                                    ,
                                    Unit = Convert.ToString(dr["Unit"].ToString())
                                        ,
                               
                                    ChargeAmount = Convert.ToDecimal(dr["Amount"].ToString())

                                });
                            }
                        }
                    }

                }
                return MaterialLaborCostAddOnRegistryList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

    }
}
