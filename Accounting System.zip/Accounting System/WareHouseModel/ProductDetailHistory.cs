﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class ProductDetailHistory
    {
        public int StockDetailID { get; set; }
        public String ReferenceNum { get; set; }
        public int BranchID { get; set; }
        public String BranchName { get; set; }
        public String StockType { get; set; }
        public String TransNum { get; set; }
 
        public String WithDrawnType { get; set; }
        public String WithDrawTransNum { get; set; }

        public int SortID { get; set; }
        public String Brand { get; set; }
        public String SerialNo { get; set; }
        public String ItemCode { get; set; }
        public String ProductName { get; set; }
        public String Status { get; set; }
    }
}
