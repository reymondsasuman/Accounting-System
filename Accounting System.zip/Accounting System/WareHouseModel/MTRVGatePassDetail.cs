﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class MTRVGatePassDetail
    {
        public String MTRVNum { get; set; }
        public String MTRVDate { get; set; }
        public String GatePassNum { get; set; }
        public Int32 GatePassDetailNum { get; set; }
        public String RefNum { get; set; }
        public String DeptCode { get; set; }
        public String BranchName { get; set; }
        public String BranchName_Source { get; set; }
        public String BranchName_Destination { get; set; }
        public String GMLevel { get; set; }
        public String Month { get; set; }
        public String Year { get; set; }
        public String Requestor { get; set; }
        public String EmpID { get; set; }
        public String EmpType { get; set; }
        public String WONo { get; set; }
        public String JONo { get; set; }
        public String Purpose { get; set; }
        public DateTime GatePassDate { get; set; }
        public String AwardedTo { get; set; }
        public String IsClosed { get; set; }
        public String MTRVStatus { get; set; }
        public Int32 ProductCode { get; set; }
        public String ItemCode { get; set; }
        public String ProductDesc { get; set; }
        public String ProductName { get; set; }
        public Decimal Quantity { get; set; }
        public String Unit { get; set; }
        public String IsReg { get; set; }
        public int SubClassID { get; set; }
        public String ProjectType { get; set; }
        public String ProjectClass { get; set; }
        public String SubClass { get; set; }
        public String SubClassDesc { get; set; }
        public Int32 MTRVDetailNum { get; set; }
        public String Available { get; set; }
        public String UnitSingular { get; set; }
        public String ReceivedBy { get; set; }
    }
}
