﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class MTCT
    {
        public String MTCTNum { get; set; }
        public String MTRVNum { get; set; }
        public String RefNum { get; set; }
        public int BranchID { get; set; }
        public String BranchName { get; set; }
        public String BranchName_Source { get; set; }
        public String BranchName_Destination { get; set; }
        public String GatePassNum { get; set; }
        public String DeptCode { get; set; }
        public String Month { get; set; }
        public String Year { get; set; }
        public String Requestor { get; set; }
        public String EmpID { get; set; }
        public String EmpType { get; set; }
        public String WONo { get; set; }
        public String JONo { get; set; }
        public DateTime MTCTDate { get; set; }
        public String AwardedTo { get; set; }
        public String IsClosed { get; set; }
        public String MTCTStatus { get; set; }
        public String UserAccount { get; set; }
        public Decimal TotalCost { get; set; }
        public String Checked { get; set; }
    }
}
