﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class MTRV
    {
        public String MTRVNum { get; set; }
        public String RefNum { get; set; }
        public String GMLevel { get; set; }
        public String DeptCode { get; set; }
        public String BranchName { get; set; }
        public String BranchName_Source { get; set; }
        public String BranchName_Destination { get; set; }
        public String Month { get; set; }
        public String Year { get; set; }
        public String Requestor { get; set; }
        public String EmpID { get; set; }
        public String EmpType { get; set; }
        public String WONo { get; set; }
        public String JONo { get; set; }
        public DateTime MTRVDate { get; set; }
        public String AwardedTo { get; set; }
        public String IsClosed { get; set; }
        public String MTRVStatus { get; set; }
        public String UserAccount { get; set; }
    }
}
