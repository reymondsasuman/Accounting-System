﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class GatePass
    {
        
        public String GatePassNum { get; set; }
        public String ReferenceNum { get; set; }
        public String BranchName { get; set; }
 
        public DateTime GatePassDate { get; set; }
        public String DeptCode { get; set; }
        public String Requestor { get; set; }
        public String ReceivedBy { get; set; }
        public String UserAccount { get; set; }
        public String WONo { get; set; }
        public String JONo { get; set; }
        
        public String AwardedTo { get; set; }
    }
}
