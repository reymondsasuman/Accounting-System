﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
   public class JORCanvassSheetSupplier
    {
        public Int32 CanvassSheetSupplierCode { get; set; }
        public String CanvassSheetNum { get; set; }
        public String JORNum { get; set; }
        public int SupplierNo { get; set; }
        public String SupplierName { get; set; }
        public String Address { get; set; }
        public String TIN { get; set; }
        public String Location { get; set; }
        public String ZipCode { get; set; }
    }
}
