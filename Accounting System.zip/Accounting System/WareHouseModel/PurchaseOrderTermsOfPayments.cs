﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    public class PurchaseOrderTermsOfPayments
    {
        public int ID { get; set; }
        public String Code { get; set; }
    }
}
