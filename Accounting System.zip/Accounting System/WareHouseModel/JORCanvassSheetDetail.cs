﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
   public class JORCanvassSheetDetail
    {
        public String CanvassSheetNum { get; set; }
        public int CanvassSheetDetailNum { get; set; }
        public String JORNum { get; set; }
        public String RefNum { get; set; }
        public String ProcurementMode { get; set; }
        public String DeptCode { get; set; }
        public String Month { get; set; }
        public String Year { get; set; }
        public String Requestor { get; set; }
        public String EmpID { get; set; }
        public String EmpType { get; set; }
        public String WONo { get; set; }
        public String JONo { get; set; }
        public String Purpose { get; set; }
        public DateTime JORDate { get; set; }
        public String AwardedTo { get; set; }
        public String IsClosed { get; set; }
        public String JORStatus { get; set; }     
        public String JobOrderDesc { get; set; }
        public Decimal Quantity { get; set; }
        public String Unit { get; set; }
        public Int32 JORDetailNum { get; set; }
        public String Available { get; set; }
        public String BiddingRefNum { get; set; }
        public String Scope { get; set; }
        public String BranchName { get; set; }
    }
}
