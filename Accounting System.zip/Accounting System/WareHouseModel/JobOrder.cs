﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class JobOrder
    {
        public int JobOrderCode { get; set; }
        public String JobOrderNum { get; set; }
        public String ReferenceNum { get; set; }
        public String RIVNum { get; set; }
        public String Purpose { get; set; }
        public String SupplierName { get; set; }
        public String Address { get; set; }
        public String TIN { get; set; }
        public String Vatable { get; set; }
        public Decimal Vat { get; set; }
        public Decimal TotalUnitCost { get; set; }
        public Decimal TotalLaborCost { get; set; }
        public Decimal OverAllCost { get; set; }
        public String Terms { get; set; }
        public String DeliveryPeriod { get; set; }
        public String Status { get; set; }
        public Decimal TotalCost { get; set; }
        public String DeptCode { get; set; }
        public DateTime DateProcess { get; set; }

        public String JOType { get; set; }
        public String TransNum { get; set; }
        public String WONo { get; set; }
    }
}
