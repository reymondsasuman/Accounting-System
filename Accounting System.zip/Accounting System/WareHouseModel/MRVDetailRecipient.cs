﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class MRVDetailRecipient
    {
        public int RecipientNum { get; set; }
        public String ReferenceNum { get; set; }
        public String MRVNum { get; set; }
        public String AcctNum { get; set; }
        public String AcctName { get; set; }
        public String Address { get; set; }
        public String Remarks { get; set; }
        public String ConStatus { get; set; }
        public int StockDetailID { get; set; }
        public int ProductCodeKWH { get; set; }
        public String ItemCodeKWH { get; set; }
        public String ProductNameKWH { get; set; }
        public String ProductDescKWH { get; set; }
        public String BrandKWH { get; set; }
        public String SerialNoKWH { get; set; }
        public String CoopNoKWH { get; set; }
        public String ERCSerialNoKWH { get; set; }
        public String ReadingKWH { get; set; }
        public String ZoneNoKWH { get; set; }
        public String CONoKWH { get; set; }
        public String StickerNoKWH { get; set; }
        public int ProductCodeSDW { get; set; }
        public String ItemCodeSDW { get; set; }
        public String ProductNameSDW { get; set; }
        public String ProductDescSDW { get; set; }
        public Decimal Length { get; set; }
        public Decimal Excess { get; set; }
        public Decimal Amount { get; set; }
        public String ORNo { get; set; }
    }
}
