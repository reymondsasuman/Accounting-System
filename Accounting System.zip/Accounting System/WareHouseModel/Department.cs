﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class Department
    {
        public String DeptID { get; set; }
        public String DeptDesc { get; set; }
        public String Gendept { get; set; }
        public Int32 BranchID { get; set; }
    } 
}
