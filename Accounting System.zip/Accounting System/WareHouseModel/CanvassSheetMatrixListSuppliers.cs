﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class CanvassSheetMatrixListSuppliers
    {
        public String RIVNum { get; set; }
        public String CanvassSheetNum { get; set; }
      
        public String SupplierName { get; set; }
        public Decimal TotalCost { get; set; }
     

    }
}
