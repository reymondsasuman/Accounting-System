﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class TransactionStatus
    {
        public int Entry { get; set; }
        public String TransStatus { get; set; }
        public int SortKey { get; set; }
        
    }
}
