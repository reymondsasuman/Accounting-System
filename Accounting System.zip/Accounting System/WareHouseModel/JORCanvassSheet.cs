﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class JORCanvassSheet
    {
        public String CanvassSheetNum { get; set; }
        public String JORNum { get; set; }
        public DateTime DateProcess { get; set; }      
        public String RefNum { get; set; }
        public String ProcurementMode { get; set; }
        public String DeptCode { get; set; }
        public String Month { get; set; }
        public String Year { get; set; }
        public String Requestor { get; set; }
        public String EmpID { get; set; }
        public String EmpType { get; set; }
        public String WONo { get; set; }
        public String JONo { get; set; }
        public String Purpose { get; set; }
        public DateTime JORDate { get; set; }
        public String AwardedTo { get; set; }
        public String IsClosed { get; set; }
        public String JORStatus { get; set; }
        public String BiddingRefNum { get; set; }
        public String BranchName { get; set; }
    }
}
