﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class ReceivingReportType
    {
        public int TypeID { get; set; }
        public String RRType { get; set; }
        public String RRTypeDesc { get; set; }
        
    }
}
