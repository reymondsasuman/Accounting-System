﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class ProcurementMode
    {
        public int ProcurementModeID { get; set; }
        public String ProcurementModeDesc { get; set; }
    }
}
