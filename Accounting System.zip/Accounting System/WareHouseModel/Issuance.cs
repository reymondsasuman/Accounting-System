﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class Issuance
    {
        public String IssuanceNum { get; set; }
        public DateTime IssuanceDate { get; set; }
        public String ReferenceNum { get; set; }
        public String PONum { get; set; }
    }
}
