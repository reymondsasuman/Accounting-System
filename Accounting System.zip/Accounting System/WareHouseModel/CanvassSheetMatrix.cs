﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class CanvassSheetMatrix
    {
        public Int32 CanvassMatrixNum { get; set; }
        public Int32 CanvassSheetDetailNum { get; set; }
        public Int32 RIVDetailNum { get; set; }
        public String CanvassSheetNum { get; set; }
        public Int32 ProductCode { get; set; }
        public String ItemCode { get; set; }
        public String ProductName { get; set; }
        public String ProductDesc { get; set; }
        public Decimal Quantity { get; set; }
        public String Unit { get; set; }        
        public Int32 SupplierNo { get; set; }
        public Decimal UnitCost { get; set; }
        public Decimal TotalCost { get; set; }
        public String VatType { get; set; }

    }
}
