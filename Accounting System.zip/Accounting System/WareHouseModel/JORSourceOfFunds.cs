﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class JORSourceOfFunds
    {
        public int ID { get; set; }
        public String FundSource { get; set; }
        public String SetDefault { get; set; }
    }
}
