﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class MCTGraph
    {
        public String Month { get; set; }
        public String Year { get; set; }
        public String DeptCode { get; set; }
        public String ItemCode { get; set; }
        public String ProductName { get; set; }
        public Decimal Quantity { get; set; }
    }
}
