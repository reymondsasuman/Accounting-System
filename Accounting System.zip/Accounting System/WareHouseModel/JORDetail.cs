﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class JORDetail
    {
        public Int32 JORDetailNum { get; set; }
        public DateTime DateProcess { get; set; }
        public String JORNum { get; set; }
        public String ReferenceNum { get; set; }
        public String Month { get; set; }
        public String Year { get; set; }
        public String EmpID { get; set; }
        public String EmpType { get; set; }
        public String WONo { get; set; }
        public String JONo { get; set; }
        public DateTime JORDate { get; set; }
        public String JORStatus { get; set; }
        public String DeptCode { get; set; }
        public String Requestor { get; set; }
        public String Vatable { get; set; }
        public Decimal Vat { get; set; }        
        public String Terms { get; set; }
        public String SourceOfFund { get; set; }
        public String BiddingRefNum { get; set; }

        public String DeliveryPeriod { get; set; }
        public String SupplierName { get; set; }
        public int SupplierNo { get; set; }
        public String Address { get; set; }
        public String TIN { get; set; }
        public String Available { get; set; }
        public String JobOrderDesc { get; set; }
        public String Unit { get; set; }
        public Decimal Quantity { get; set; }
        public int SubClassID { get; set; }
        public String ProjectType { get; set; }
        public String ProjectClass { get; set; }
        public String SubClass { get; set; }
        public String SubClassDesc { get; set; }
        public Decimal UnitCost { get; set; }
        public Decimal Labor { get; set; }
        public Decimal TotalCost { get; set; }
        public String Purpose { get; set; }
        public String UnitSingular { get; set; }
        public String JOType { get; set; }
        public String JobLocation { get; set; }
        public String PoleNum { get; set; }
        public String Scope { get; set; }
        public String CheckedByID { get; set; }
        public String CheckedByName { get; set; }
    }
}
