﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class ProductUnit
    {
        public int UnitID { get; set; }
        public String Unit { get; set; }
        public String Units { get; set; }

    }
}
