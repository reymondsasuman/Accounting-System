﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class JOR
    {
        public int JORCode { get; set; }
        public String JORNum { get; set; }
        public String ReferenceNum { get; set; }
        
        public String Purpose { get; set; }
        public String SupplierName { get; set; }
        public String Address { get; set; }
        public String TIN { get; set; }
        public String Vatable { get; set; }
        public Decimal Vat { get; set; }
        public Decimal TotalUnitCost { get; set; }
        public Decimal TotalLaborCost { get; set; }
        public Decimal OverAllCost { get; set; }
        public String Terms { get; set; }
        public String DeliveryPeriod { get; set; }
        public String Status { get; set; }
        public Decimal TotalCost { get; set; }
        public String DeptCode { get; set; }
        public DateTime JORDate { get; set; }

        public String Month { get; set; }
        public String Year { get; set; }
        public String Requestor { get; set; }
        public String EmpID { get; set; }
        public String EmpType { get; set; }
        public String WONo { get; set; }
        public String JONo { get; set; }
 
        public String AwardedTo { get; set; }
        public String SourceOfFund { get; set; }
        public String BiddingRefNum { get; set; }
        public String IsClosed { get; set; }
        public String JORStatus { get; set; }
        public String UserAccount { get; set; }
        public String ForWareHouse { get; set; }
        public String JOType { get; set; }
        public String JobLocation { get; set; }
        public String PoleNum { get; set; }
        public String BranchName { get; set; }
        public String CheckedByID { get; set; }
        public String CheckedByName { get; set; }
    }
}
