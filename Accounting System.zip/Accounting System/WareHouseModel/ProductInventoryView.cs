﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class ProductInventoryView
    {
        //product
        public int ProductCode { get; set; }
        public String ItemCode { get; set; }
        public int ClassCode { get; set; }
        public String ProductName { get; set; }
        public String ProductDesc { get; set; }
        public String IsReg { get; set; }
        public int UnitID { get; set; }
        public String FlagDel { get; set; }
        public int CreatedBy { get; set; }
        public DateTime DateCreated { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime DateModified { get; set; }
        
        //productclass
        public String AccountCode { get; set; }
        public String AccountDesc { get; set; }
        public String Address { get; set; }


        //Unit
        public String Unit { get; set; }
        public String Units { get; set; }

        public Decimal Quantity { get; set; }
        public Decimal UnitCost { get; set; }
        public Decimal TotalCost { get; set; }

        public Decimal Reserve { get; set; }
        public Decimal OnHand { get; set; }
        public Decimal Buffer { get; set; }
        public String CurrentMonthPrice { get; set; }
        public String CurrentYearPrice { get; set; }
        public String BranchName { get; set; }
        public Decimal ForRepair { get; set; }
        public Decimal Busted { get; set; }

    }
}
