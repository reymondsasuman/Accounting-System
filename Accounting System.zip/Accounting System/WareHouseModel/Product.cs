﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class Product
    {
        public int ProductCode { get; set; }
        public String ItemCode { get; set; }
        public String AcctCode { get; set; }
        public int ClassCode { get; set; }
        public String ClassName { get; set; }
        public String ProductName { get; set; }
        public String ProductDesc { get; set; }
        public int Unit { get; set; }
        public String UnitDesc { get; set; }
        public String FlagDel { get; set; }
        public int CreatedBy { get; set; }
        public DateTime DateCreated { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime DateModified { get; set; }
        public String NEABased { get; set; }
        public String WithSubsidy { get; set; }
        public String WithDetail { get; set; }
    }
}
