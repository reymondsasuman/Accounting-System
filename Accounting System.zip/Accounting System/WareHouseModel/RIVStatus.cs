﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class RIVStatus
    {
        public int Entry { get; set; }
        public String RIVNum { get; set; }
        public DateTime DateStatus { get; set; }
        public int UserID { get; set; }
        public String Remarks { get; set; }
        public String Status { get; set; }
        public String Notes { get; set; }
        public String ComputerName { get; set; }
        public String IPAddress { get; set; }
    }
}
