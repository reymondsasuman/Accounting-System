﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
   public class RIVDetail
    {
        public String RIVNum { get; set; }
        public String RefNum { get; set; }
        public String DeptCode { get; set; }
        public String Month { get; set; }
        public String Year { get; set; }
        public String Requestor { get; set; }
        public String EmpID { get; set; }
        public String EmpType { get; set; }
        public String WONo { get; set; }
        public String JONo { get; set; }
        public String Purpose { get; set; }
        public DateTime RIVDate { get; set; }
        public String AwardedTo { get; set; }
        public String SourceOfFund { get; set; }
        public String BiddingRefNum { get; set; }
        public String IsClosed { get; set; }
        public String RIVStatus { get; set; }
        public Int32 ProductCode { get; set; }
        public String ItemCode { get; set; }
        public String ProductDesc { get; set; }
        public String ProductName { get; set; }
        public Decimal Quantity { get; set; }
        public String Unit { get; set; }
        public String IsReg { get; set; }
        public int SubClassID { get; set; }
        public String ProjectType { get; set; }
        public String ProjectClass { get; set; }
        public String SubClass { get; set; }
        public String SubClassDesc { get; set; }
        public Int32 RIVDetailNum { get; set; }
        public String Available { get; set; }
        public String UnitSingular { get; set; }
        public String UpdatePurposeAll { get; set; }
        public String CanvassSheetNum { get; set; }
        public String PONum { get; set; }
    }
}
