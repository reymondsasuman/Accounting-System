﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    public class Employee
    {
        public String EmpID { get; set; }
        public String EmpName { get; set; }
        public String DeptID { get; set; }
        public String DeptDesc { get; set; }
        public String JobDesc { get; set; }
        public String EmpType { get; set; }
    }
}
