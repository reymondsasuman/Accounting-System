﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
   public class Supplier
    {
        public int SupplierNo { get; set; }
        public String SupplierName { get; set; }
        public String Address { get; set; }
        public String TIN { get; set; }
        public String Location { get; set; }
        public String ZipCode { get; set; }
    }
}
