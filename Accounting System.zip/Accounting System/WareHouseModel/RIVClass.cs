﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class RIVClass
    {
        public int SubClassID { get; set; }
        public String ProjectType { get; set; }
        public String ProjectClass { get; set; }
        public String SubClass { get; set; }
        public String SubClassDesc { get; set; }
    }
}
