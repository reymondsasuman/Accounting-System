﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class PurchaseOrder
    {
        public int PurchaseOrderCode { get; set; }
        public String PurchaseOrderNum { get; set; }
        public String ReferenceNum { get; set; }
        public String RIVNum { get; set; }
        public String CanvassSheetNum { get; set; }
        public String SupplierName { get; set; }
        public String Vatable { get; set; }
        public Decimal Vat { get; set; }
        public String Terms { get; set; }
        public String Status { get; set; }
        public String DeliveryStatus { get; set; }
        public String DeliveryPeriod { get; set; }
        public DateTime DateProcess { get; set; }
        public Decimal TotalCost { get; set; }
        public String Requestor { get; set; }

        public String DeptCode { get; set; }
        public String UserAccount { get; set; }
    }
}
