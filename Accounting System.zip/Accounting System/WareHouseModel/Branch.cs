﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class Branch
    {
 
        public Int32 BranchID { get; set; }
        public String BranchName { get; set; }
    } 
}
