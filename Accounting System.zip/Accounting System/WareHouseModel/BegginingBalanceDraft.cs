﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class BegginingBalanceDraft
    {
        public Int32 BranchID { get; set; }
        public String BranchName { get; set; }
        public int ProductCode { get; set; }
        public String ItemCode { get; set; }
        
        public String ProductName { get; set; }
        public String ProductDesc { get; set; }
        public Int32 UnitID { get; set; }
        public String Unit { get; set; }
        public String Units { get; set; }
        public String AccountCode { get; set; }
        public String AccountDesc { get; set; }
        public String Address { get; set; }
        public Decimal Quantity { get; set; }
        public Decimal UnitCost { get; set; }
        public Decimal TotalCost { get; set; }
        public String FlagDel { get; set; }
        public int CreatedBy { get; set; }
        public DateTime DateCreated { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime DateModified { get; set; }
    }
}
