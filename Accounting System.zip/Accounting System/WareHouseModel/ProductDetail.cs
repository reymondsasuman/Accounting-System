﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class ProductDetail
    {
        public int StockDetailID { get; set; }
        public String ReferenceNum { get; set; }
        public int BranchID { get; set; }
        public String BranchName { get; set; }
        public String StockType { get; set; }
        public String TransNum { get; set; }
        public int ProductCode { get; set; }
        public String ItemCode { get; set; }
        public String ProductName { get; set; }
        public String ProductDesc { get; set; }
        public int Unit { get; set; }
        public String UnitDesc { get; set; }
        public String Status { get; set; }
        public String Withdrawn { get; set; }
        public String Brand { get; set; }
        public String KVA { get; set; }
        public String SerialNo { get; set; }
        public String TagNo { get; set; }
        public String Primary { get; set; }
        public String Secondary { get; set; }
        public String Polarity { get; set; }
        public String Bushing { get; set; }
        public String Impedance { get; set; }
        public DateTime DateManufacture { get; set; }
        public String FlagDel { get; set; }
        public int CreatedBy { get; set; }
        public DateTime DateCreated { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime DateModified { get; set; }
        public String Notes { get; set; }
    }
}
