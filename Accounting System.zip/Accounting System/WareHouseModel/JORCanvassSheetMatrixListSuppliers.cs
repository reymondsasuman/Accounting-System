﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class JORCanvassSheetMatrixListSuppliers
    {
        public String JORNum { get; set; }
        public String CanvassSheetNum { get; set; }
      
        public String SupplierName { get; set; }
        public Decimal TotalCost { get; set; }
        public int SupplierNo { get; set; }
        public String SupplierAddress { get; set; }
        public String SupplierTIN { get; set; }
        public Decimal VAT { get; set; }
        public String DeptCode { get; set; }
    }
}
