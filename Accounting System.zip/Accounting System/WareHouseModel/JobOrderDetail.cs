﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class JobOrderDetail
    {
        public Int32 JobOrderDetailNum { get; set; }
        public DateTime DateProcess { get; set; }
        public String JobOrderNum { get; set; }
        public String ReferenceNum { get; set; }
        public String RIVNum { get; set; }
        public String JONo { get; set; }
        public String WONo { get; set; }
        public String AwardedTo { get; set; }
        public String DeptCode { get; set; }
        public String Requestor { get; set; }
        public String Vatable { get; set; }
        public Decimal Vat { get; set; }        
        public String Terms { get; set; }
        public String DeliveryPeriod { get; set; }
        public String SupplierName { get; set; }
        public int SupplierNo { get; set; }
        public String Address { get; set; }
        public String TIN { get; set; }
        public int ProductCode { get; set; }
        public String ItemCode { get; set; }
        public String JobOrderDesc { get; set; }       
        public String Unit { get; set; }
        public Decimal Quantity { get; set; }
        public Decimal UnitCost { get; set; }
        public Decimal Labor { get; set; }
        public Decimal TotalCost { get; set; }
        public String Purpose { get; set; }
        public String UnitSingular { get; set; }
        public String JOType { get; set; }
        public String TransNum { get; set; }
    }
}
