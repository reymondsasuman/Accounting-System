﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class ReceivingReport
    {
        public int RRCode { get; set; }
        public String Month { get; set; }
        public String Year { get; set; }
        public String RRNum { get; set; }
        public String ReferenceNum { get; set; }
        public String JONum { get; set; }
        public String WONum { get; set; }
        public String AwardedTo { get; set; }
        public DateTime DateProcess { get; set; }
        public int BranchID { get; set; }
        public String BranchName { get; set; }
        
        public String DeliveryStatus { get; set; }
        public String PurchaseOrderNum { get; set; }
        public DateTime PurchaseOrderDate { get; set; }
        public String RIVNum { get; set; }
        public String InvoiceNum { get; set; }
        public DateTime InvoiceDate { get; set; }
        public String DRNum { get; set; }
        public DateTime DRDate { get; set; }

        public String CVNum { get; set; }
        public String SupplierName { get; set; }

        public String Vatable { get; set; }
        public Decimal Vat { get; set; }
        public String Terms { get; set; }
        public String Status { get; set; }
        public String DeliveryPeriod { get; set; }
        
        public Decimal TotalCost { get; set; }
        public Decimal TotalCostPer { get; set; }
        public String Requestor { get; set; }
        public String DeptCode { get; set; }
        public String RRType { get; set; }
        public String Checked { get; set; }
        public String ReceivedBy { get; set; }
        public String EmpID { get; set; }
        public String EmpType { get; set; }
        public String UserAccount { get; set; }
    
    }
}
