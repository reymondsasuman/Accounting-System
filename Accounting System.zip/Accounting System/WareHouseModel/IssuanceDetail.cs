﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
   public class IssuanceDetail
    {
        public Int32 IssuanceDetailNum { get; set; }
        public String IssuanceNum { get; set; }      
        public String ReferenceNum { get; set; }
        public Int32 ProductCode { get; set; }
        public String ItemCode { get; set; }
        public String ProductDesc { get; set; }
        public String ProductName { get; set; }
        public Decimal Quantity { get; set; }
        public String Unit { get; set; }       
        public String IsReg { get; set; }
        public String TagNum { get; set; }
        public String EmpType { get; set; }
        public String EmpID { get; set; }
        public String EmpName { get; set; }
        public DateTime IssuanceDate { get; set; }
        public String PONum { get; set; }

    }
}
