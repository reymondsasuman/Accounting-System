﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anecoacct.WareHouseModel
{
    class ProductClass
    {
        public int ClassCode { get; set; }
        public String AccountCode { get; set; }
        public String AccountDesc { get; set; }
        public String Address { get; set; }
        public String FlagDel { get; set; }
        public int CreatedBy { get; set; }
        public DateTime DateCreated { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime DateModified { get; set; }
    }
}
