﻿using anecoacct.AccountingModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace anecoacct.AccountingClass
{
   class PayeeQueries
    {
        public    List<Payee> GetPayeeList(String Param, String Flag)
        {
            try
            {
                List<Payee> PayeeList = new List<Payee>();
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();

                    DatabaseConnection.Connect();
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 60000;
                    cmd.CommandText = "sp_GetPayee";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 500);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;
                  
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {

                        if (dr.HasRows)
                        {

                            while (dr.Read())
                            {
                                PayeeList.Add(new Payee
                                {
                                    PayeeNo = Convert.ToInt32(dr["PayeeNo"].ToString())
                                    ,
                                    PayeeName = Convert.ToString(dr["PayeeName"].ToString())
                                    ,
                                    Address = Convert.ToString(dr["Address"].ToString())
                                    ,
                                    PayeeType = Convert.ToString(dr["PayeeType"].ToString())
                                      ,
                                    ZipCode = Convert.ToString(dr["ZipCode"].ToString())

                                      ,
                                    TIN = Convert.ToString(dr["TIN"].ToString())


                                });


                            }//end of while
                        }//END OF HAS ROWS

                    }//end of using dr
                    return PayeeList;
                }//end of using cmd
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();

            }
        }
    }
}
