﻿using anecoacct.AccountingModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace anecoacct.AccountingClass
{
    class JournalVoucherQueries
    {
        public String AddJournalVoucherDetail(JournalVoucherDetail JournalVoucherDetail, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_AddJournalVoucherDetail";

                    param = cmd.Parameters.Add("@Entry", SqlDbType.BigInt);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = JournalVoucherDetail.ReferenceNum;

                    param = cmd.Parameters.Add("@JVNo", SqlDbType.VarChar, 20);
                    param.Value = JournalVoucherDetail.JVNo;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = JournalVoucherDetail.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = JournalVoucherDetail.Year;

                    param = cmd.Parameters.Add("@AcctCode", SqlDbType.VarChar, 20);
                    param.Value = JournalVoucherDetail.AcctCode;

                    param = cmd.Parameters.Add("@GL_Debit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = JournalVoucherDetail.GL_Debit;

                    param = cmd.Parameters.Add("@GL_Credit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = JournalVoucherDetail.GL_Credit;

                    param = cmd.Parameters.Add("@SL_Debit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = JournalVoucherDetail.SL_Debit;

                    param = cmd.Parameters.Add("@SL_Credit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = JournalVoucherDetail.SL_Credit;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewJVDetailEntry = Convert.ToString(cmd.Parameters["@Entry"].Value);
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String UpdateJournalVoucherDetail(JournalVoucherDetail JournalVoucherDetail, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_UpdateJournalVoucherDetail";

                    param = cmd.Parameters.Add("@Entry", SqlDbType.BigInt);
                    param.Value = JournalVoucherDetail.Code;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = JournalVoucherDetail.ReferenceNum;

                    param = cmd.Parameters.Add("@JVNo", SqlDbType.VarChar, 20);
                    param.Value = JournalVoucherDetail.JVNo;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = JournalVoucherDetail.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = JournalVoucherDetail.Year;

                    param = cmd.Parameters.Add("@AcctCode", SqlDbType.VarChar, 20);
                    param.Value = JournalVoucherDetail.AcctCode;

                    param = cmd.Parameters.Add("@GL_Debit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = JournalVoucherDetail.GL_Debit;

                    param = cmd.Parameters.Add("@GL_Credit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = JournalVoucherDetail.GL_Credit;

                    param = cmd.Parameters.Add("@SL_Debit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = JournalVoucherDetail.SL_Debit;

                    param = cmd.Parameters.Add("@SL_Credit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = JournalVoucherDetail.SL_Credit;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();

                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String CancelJournalVoucher(String ReferenceNum, String JVNo)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_CancelJournalVoucher";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@JVNo", SqlDbType.VarChar, 20);
                    param.Value = JVNo;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String SaveJournalVoucher(JournalVoucher JournalVoucher)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_SaveJournalVoucher";

                    param = cmd.Parameters.Add("@JVNo", SqlDbType.VarChar, 20);
                    param.Value = JournalVoucher.JVNo;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = JournalVoucher.ReferenceNum;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = JournalVoucher.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = JournalVoucher.Year;

                    param = cmd.Parameters.Add("@DateTrans", SqlDbType.DateTime);
                    param.Value = JournalVoucher.DateTrans;

                    param = cmd.Parameters.Add("@Particulars", SqlDbType.VarChar, 1000);
                    param.Value = JournalVoucher.Particulars;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
              
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String EditJournalVoucher(String ReferenceNum, String JVNo)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_EditJournalVoucher";

                    param = cmd.Parameters.Add("@JVNo", SqlDbType.VarChar, 20);
                    param.Value = JVNo;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.InputOutput;
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewJVRefNum = Convert.ToString(cmd.Parameters["@ReferenceNum"].Value);
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<JournalVoucherDetail> GetJournalVoucherDetailList(String Param, String Flag, String ReferenceNum)
        {
            List<JournalVoucherDetail> JournalVoucherDetailList = new List<JournalVoucherDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_GetJournalVoucherDetail";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                JournalVoucherDetailList.Add(new JournalVoucherDetail()
                                {

                                    Code = Convert.ToInt64(dr["Code"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                     ,
                                    JVNo = Convert.ToString(dr["JVNo"].ToString())
                                     ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                      ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                       ,
                                    DateTrans = Convert.ToDateTime(dr["DateTrans"].ToString())
                                        ,
                                    Particulars = Convert.ToString(dr["Particulars"].ToString())
                                    ,
                                    AcctCode = Convert.ToString(dr["AcctCode"].ToString())
                                        ,
                                    AcctDesc = Convert.ToString(dr["AcctDesc"].ToString())
                                        ,
                                    GL_Debit = Convert.ToDecimal(dr["GL_Debit"].ToString())
                                        ,
                                    GL_Credit = Convert.ToDecimal(dr["GL_Credit"].ToString())
                                        ,
                                    SL_Debit = Convert.ToDecimal(dr["SL_Debit"].ToString())
                                        ,
                                    SL_Credit = Convert.ToDecimal(dr["SL_Credit"].ToString())


                                });
                            }
                        }
                    }

                }
                return JournalVoucherDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<JournalVoucher> GetJournalVoucherList(String Flag, String Param,String Month, String Year)
        {
            try
            {
                List<JournalVoucher> JournalVoucherList = new List<JournalVoucher>();
                using (SqlCommand cmd = new SqlCommand())
                {
                    int x = 0;
                    SqlParameter param = new SqlParameter();
                    
 
                    DatabaseConnection.Connect();
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 60000;
                    cmd.CommandText = "sp_GetJournalVoucher";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 50);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;
                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;
                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                    
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                JournalVoucherList.Add( new JournalVoucher() { 
                                  JVNo= String.IsNullOrEmpty(dr["JVNo"].ToString()) ? "" : dr["JVNo"].ToString()
                                  ,DateTrans =   Convert.ToDateTime(dr["DateTrans"].ToString())
                                  ,Particulars = String.IsNullOrEmpty(dr["Particulars"].ToString()) ? "" : dr["Particulars"].ToString().Trim()
                                  ,GL_Debit = Convert.ToDecimal(dr["GL_Debit"].ToString())
                                  ,GL_Credit= Convert.ToDecimal(dr["GL_Credit"].ToString())
                                  ,SL_Debit= Convert.ToDecimal(dr["SL_Debit"].ToString())
                                  ,SL_Credit= Convert.ToDecimal(dr["SL_Credit"].ToString())
                                });

                             
                            }//end of while
                        }//END OF HAS ROWS
                        return JournalVoucherList;
                    }//end of using dr
                }//end of using cmd
            }//end of try
            catch (Exception ex)
            {

                return null;

            }
            finally
            {
                DatabaseConnection.DBClose();
           
            }
        }

        public String UpdateJournalVoucher(JournalVoucher JournalVoucher)
        {
            try
            {
                //save MRV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_UpdateJournalVoucher";

                    param = cmd.Parameters.Add("@JVNo", SqlDbType.VarChar, 20);
                    param.Value = JournalVoucher.JVNo;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = JournalVoucher.ReferenceNum;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = JournalVoucher.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = JournalVoucher.Year;

                    param = cmd.Parameters.Add("@DateTrans", SqlDbType.DateTime);
                    param.Value = JournalVoucher.DateTrans;

                    param = cmd.Parameters.Add("@Particulars", SqlDbType.VarChar, 1000);
                    param.Value = JournalVoucher.Particulars;

                  
                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public void GetLastMaxJV( String Year, String Month)
        {

            DatabaseConnection.Connect();
            using (SqlCommand cmd = new SqlCommand())
            {
                SqlParameter param = new SqlParameter();
                cmd.CommandTimeout = 6000;
                cmd.Connection = DatabaseConnection.cnn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "sp_GetLastMaxJv";
                param = cmd.Parameters.Add("@MaxJVNo", SqlDbType.VarChar, 20);
                param.Direction = ParameterDirection.Output;
                param = cmd.Parameters.Add("@LastJVNo", SqlDbType.VarChar, 20);
                param.Direction = ParameterDirection.Output;
                param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                param.Value = Year;
                param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                param.Value =Month;

                cmd.ExecuteNonQuery();
                GlobalVariable.LastJVNum = Convert.ToString(cmd.Parameters["@LastJVNo"].Value);
                GlobalVariable.MaxJVNum = Convert.ToString(cmd.Parameters["@MaxJVNo"].Value);
                DatabaseConnection.DBClose();
            }//end of using cmd
        }
        public String RemoveJournalVoucherDetail(String ReferenceNum, Int64 Code)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_RemoveJournalVoucherDetailItem";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@Code", SqlDbType.Int);
                    param.Value = Code;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();

                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
    }
}
