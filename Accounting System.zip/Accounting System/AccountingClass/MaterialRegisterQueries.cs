﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using anecoacct.AccountingModel;
namespace anecoacct.AccountingClass
{
    class MaterialRegisterQueries
    {
        public List<MaterialRegister> GetMaterialRegisterList(String Param, String Flag, String Month, String Year, String Location, String TicketType)
        {
            try
            {
                List<MaterialRegister> MaterialRegisterList = new List<MaterialRegister>();
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();

                    DatabaseConnection.Connect();
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 60000;
                    cmd.CommandText = "sp_GetMaterialRegister";

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 50);
                    param.Value = Param;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;
                    
                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    if (Month != "") { param.Value = Month.Substring(0, 2) + "%"; }
                    else { param.Value = "%"; }

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    if (Year != "") { param.Value = Year + "%"; }
                    else { param.Value = "%"; }
                    
                    param = cmd.Parameters.Add("@Location", SqlDbType.VarChar, 50);
                    if (Location != "") { param.Value = Location; }
                    else { param.Value = "%"; }
                    
                    param = cmd.Parameters.Add("@TicketType", SqlDbType.VarChar, 10);
                    param.Value = TicketType;  

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {

                        if (dr.HasRows)
                        {

                            while (dr.Read())
                            {
                                MaterialRegisterList.Add(new MaterialRegister
                                {
                                    BranchName = Convert.ToString(dr["BranchName"].ToString())
                                    ,
                                    TicketType = Convert.ToString(dr["TicketType"].ToString())
                                    ,
                                    TicketNo = Convert.ToString(dr["TicketNo"].ToString())
                                    ,
                                    DateTrans = Convert.ToDateTime(dr["DateTrans"].ToString())
                                    ,
                                    Remarks = Convert.ToString(dr["Remarks"].ToString())
                                    ,
                                   
                                    Month = Convert.ToString(dr["Month"].ToString())
                                    ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                     ,
                                    GL_Debit = Convert.ToDecimal(dr["GL_Debit"].ToString())
                                     ,
                                    GL_Credit = Convert.ToDecimal(dr["GL_Credit"].ToString())
                                     ,
                                    SL_Debit = Convert.ToDecimal(dr["SL_Debit"].ToString())
                                     ,
                                    SL_Credit = Convert.ToDecimal(dr["SL_Credit"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    
                                });


                            }//end of while
                        }//END OF HAS ROWS

                    }//end of using dr
                    return MaterialRegisterList;
                }//end of using cmd
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();

            }
        }
        public String CancelMaterialRegister(String ReferenceNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_CancelMaterialRegister";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;
 
                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String EditMaterialRegister(String ReferenceNum,String BranchName, String TicketType, String TicketNo)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_EditMaterialRegister";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.InputOutput;
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 50);
                    param.Value =  BranchName;

                    param = cmd.Parameters.Add("@TicketType", SqlDbType.VarChar, 6);
                    param.Value =  TicketType;

                    param = cmd.Parameters.Add("@TicketNo", SqlDbType.VarChar, 15);
                    param.Value =  TicketNo;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewMRRefNum = Convert.ToString(cmd.Parameters["@ReferenceNum"].Value);
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String SaveMaterialRegister(MaterialRegister MaterialRegister)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_SaveMaterialRegister";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MaterialRegister.ReferenceNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 50);
                    param.Value = MaterialRegister.BranchName;

                    param = cmd.Parameters.Add("@TicketType", SqlDbType.VarChar, 6);
                    param.Value = MaterialRegister.TicketType;

                    param = cmd.Parameters.Add("@TicketNo", SqlDbType.VarChar, 15);
                    param.Value = MaterialRegister.TicketNo;

                    param = cmd.Parameters.Add("@RefNo", SqlDbType.VarChar, 20);
                    param.Value = MaterialRegister.RefNo;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = MaterialRegister.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = MaterialRegister.Year;

                    param = cmd.Parameters.Add("@DateTrans", SqlDbType.DateTime);
                    param.Value = MaterialRegister.DateTrans;

                    param = cmd.Parameters.Add("@Cancel", SqlDbType.VarChar, 4);
                    param.Value = MaterialRegister.Cancel;

                    param = cmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 1000);
                    param.Value = MaterialRegister.Remarks;
                   
                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String UpdateMaterialRegister(MaterialRegister MaterialRegister)
        {
            try
            {
                //save material register table
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_UpdateMaterialRegister";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MaterialRegister.ReferenceNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 50);
                    param.Value = MaterialRegister.BranchName;

                    param = cmd.Parameters.Add("@TicketType", SqlDbType.VarChar, 6);
                    param.Value = MaterialRegister.TicketType;

                    param = cmd.Parameters.Add("@TicketNo", SqlDbType.VarChar, 15);
                    param.Value = MaterialRegister.TicketNo;

                    param = cmd.Parameters.Add("@RefNo", SqlDbType.VarChar, 20);
                    param.Value = MaterialRegister.RefNo;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = MaterialRegister.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = MaterialRegister.Year;

                    param = cmd.Parameters.Add("@DateTrans", SqlDbType.DateTime);
                    param.Value = MaterialRegister.DateTrans;

                    param = cmd.Parameters.Add("@Cancel", SqlDbType.VarChar, 4);
                    param.Value = MaterialRegister.Cancel;

                    param = cmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 1000);
                    param.Value = MaterialRegister.Remarks;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String Check_MRNo(String TicketNo, String Month,String Year)
        {


            String Message;
            using (SqlCommand cmd = new SqlCommand())
            {
                DatabaseConnection.Connect();
                SqlParameter param = new SqlParameter();
                cmd.CommandTimeout = 6000;
                cmd.Connection = DatabaseConnection.cnn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "sp_CheckMaterialRegister";

                param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 30);
                param.Value = TicketNo.Trim();

                param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                if (Month != "")
                {
                    param.Value = Month.Substring(0, 2).ToString();
                }
                else { param.Value = ""; }

                param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                if (Year != "")
                {
                    param.Value = Year.Trim().ToString();
                }
                else { param.Value = ""; }

                param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 50);
                param.Direction = ParameterDirection.Output;

                cmd.ExecuteNonQuery();
                Message = Convert.ToString(cmd.Parameters["@Message"].Value);
            }
            DatabaseConnection.DBClose();
            if (Message != "0" && Message != "")
            {               
                return Message;
            }
            else
            {
                return "";
            }
        }

        public List<MaterialRegisterDetail> GetMaterialRegisterDetailList(String TicketType, String TicketNo, String BranchName,String Param, String Flag)
        {
            List<MaterialRegisterDetail> MaterialRegisterDetailList = new List<MaterialRegisterDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_GetMaterialRegisterDetail";

                    param = cmd.Parameters.Add("@TicketType", SqlDbType.VarChar, 6);
                    param.Value = TicketType;

                    param = cmd.Parameters.Add("@TicketNo", SqlDbType.VarChar, 15);
                    param.Value = TicketNo;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 50);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MaterialRegisterDetailList.Add(new MaterialRegisterDetail()
                                {

                                    Code = Convert.ToInt64(dr["MRCode"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                     ,
                                    RefNo = Convert.ToString(dr["RefNo"].ToString())
                                     ,
                                    BranchID = Convert.ToInt32(dr["BranchID"].ToString())
                                     ,
                                    BranchName = Convert.ToString(dr["BranchName"].ToString())
                                     ,
                                    TicketType = Convert.ToString(dr["TicketType"].ToString())
                                     ,
                                    TicketNo = Convert.ToString(dr["TicketNo"].ToString())
                                     ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                      ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                       ,
                                    DateTrans = Convert.ToDateTime(dr["DateTrans"].ToString())
                                       ,
                                    Remarks = Convert.ToString(dr["Remarks"].ToString())
                                       ,
                                    Cancel = Convert.ToString(dr["Cancel"].ToString())
                                       ,
                                    AcctCode = Convert.ToString(dr["AcctCode"].ToString())
                                        ,
                                    AcctDesc = Convert.ToString(dr["AcctDesc"].ToString())
                                        ,
                                    GL_Debit = Convert.ToDecimal(dr["GL_Debit"].ToString())
                                        ,
                                    GL_Credit = Convert.ToDecimal(dr["GL_Credit"].ToString())
                                        ,
                                    SL_Debit = Convert.ToDecimal(dr["SL_Debit"].ToString())
                                        ,
                                    SL_Credit = Convert.ToDecimal(dr["SL_Credit"].ToString())


                                });
                            }
                        }
                    }

                }
                return MaterialRegisterDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String AddMaterialRegisterRef(MaterialRegisterRef MaterialRegisterRef, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_AddMaterialRegisterRef";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MaterialRegisterRef.ReferenceNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 200);
                    param.Value = MaterialRegisterRef.BranchName;

                    param = cmd.Parameters.Add("@TicketType", SqlDbType.VarChar, 50);
                    param.Value = MaterialRegisterRef.TicketType;

                    param = cmd.Parameters.Add("@TicketNo", SqlDbType.VarChar, 50);
                    param.Value = MaterialRegisterRef.TicketNo;

                    param = cmd.Parameters.Add("@RefType", SqlDbType.VarChar, 50);
                    param.Value = MaterialRegisterRef.RefType;

                    param = cmd.Parameters.Add("@RefNo", SqlDbType.VarChar, 50);
                    param.Value = MaterialRegisterRef.RefNo;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<MaterialRegisterRef> GetMaterialRegisterRefList_TempTable(String ReferenceNum, String TicketType, String TicketNo, String Flag)
        {
            List<MaterialRegisterRef> MaterialRegisterRefList = new List<MaterialRegisterRef>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_GetMaterialRegisterRef_Temp";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@TicketType", SqlDbType.VarChar, 50);
                    param.Value = TicketType;

                    param = cmd.Parameters.Add("@TicketNo", SqlDbType.VarChar, 50);
                    param.Value = TicketNo;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                MaterialRegisterRefList.Add(new MaterialRegisterRef()
                                {

                                    Code = Convert.ToInt64(dr["Entry"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    TicketType = Convert.ToString(dr["TicketType"].ToString())
                                      ,
                                    TicketNo = Convert.ToString(dr["TicketNo"].ToString())
                                      ,
                                    RecNo = Convert.ToInt32(dr["RecNo"].ToString())
                                    ,
                                    RefType = Convert.ToString(dr["RefDesc"].ToString())
                                         ,
                                    RefNo = Convert.ToString(dr["RefNo"].ToString())

                                });
                            }
                        }
                    }

                }
                return MaterialRegisterRefList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String AddMaterialRegisterDetail(MaterialRegisterDetail MaterialRegisterDetail, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_AddMaterialRegisterDetail";

                    param = cmd.Parameters.Add("@Entry", SqlDbType.BigInt);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MaterialRegisterDetail.ReferenceNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 50);
                    param.Value = MaterialRegisterDetail.BranchName;

                    param = cmd.Parameters.Add("@TicketType", SqlDbType.VarChar, 50);
                    param.Value = MaterialRegisterDetail.TicketType;

                    param = cmd.Parameters.Add("@TicketNo", SqlDbType.VarChar, 50);
                    param.Value = MaterialRegisterDetail.TicketNo;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = MaterialRegisterDetail.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = MaterialRegisterDetail.Year;

                    param = cmd.Parameters.Add("@AcctCode", SqlDbType.VarChar, 20);
                    param.Value = MaterialRegisterDetail.AcctCode;

                    param = cmd.Parameters.Add("@GL_Debit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = MaterialRegisterDetail.GL_Debit;

                    param = cmd.Parameters.Add("@GL_Credit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = MaterialRegisterDetail.GL_Credit;

                    param = cmd.Parameters.Add("@SL_Debit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = MaterialRegisterDetail.SL_Debit;

                    param = cmd.Parameters.Add("@SL_Credit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = MaterialRegisterDetail.SL_Credit;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewMRDetailEntry = Convert.ToString(cmd.Parameters["@Entry"].Value);
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemoveMaterialRegisterDetail(String ReferenceNum, Int64 Code)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_RemoveMaterialRegisterDetailItem";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@Code", SqlDbType.Int);
                    param.Value = Code;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();

                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateMaterialRegisterDetail(MaterialRegisterDetail MaterialRegisterDetail, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_UpdateMaterialRegisterDetail";

                    param = cmd.Parameters.Add("@Entry", SqlDbType.BigInt);
                    param.Value = MaterialRegisterDetail.Code;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = MaterialRegisterDetail.ReferenceNum;

                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 50);
                    param.Value = MaterialRegisterDetail.BranchName;

                    param = cmd.Parameters.Add("@TicketType", SqlDbType.VarChar, 50);
                    param.Value = MaterialRegisterDetail.TicketType;

                    param = cmd.Parameters.Add("@TicketNo", SqlDbType.VarChar, 50);
                    param.Value = MaterialRegisterDetail.TicketNo;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = MaterialRegisterDetail.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = MaterialRegisterDetail.Year;

                    param = cmd.Parameters.Add("@AcctCode", SqlDbType.VarChar, 20);
                    param.Value = MaterialRegisterDetail.AcctCode;

                    param = cmd.Parameters.Add("@GL_Debit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = MaterialRegisterDetail.GL_Debit;

                    param = cmd.Parameters.Add("@GL_Credit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = MaterialRegisterDetail.GL_Credit;

                    param = cmd.Parameters.Add("@SL_Debit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = MaterialRegisterDetail.SL_Debit;

                    param = cmd.Parameters.Add("@SL_Credit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = MaterialRegisterDetail.SL_Credit;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();

                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public string DeleteMaterialRegister(String TicketType, String Month,String Year, String TicketNo, String BranchName)

        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();
                    int x;
                    DatabaseConnection.Connect();
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 60000;
                    cmd.CommandText = "sp_DeleteMaterialRegister";
                    
                    param = cmd.Parameters.Add("@TicketType", SqlDbType.VarChar, 6);
                    param.Value = TicketType;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    param = cmd.Parameters.Add("@TicketNo", SqlDbType.VarChar, 15);
                    param.Value = TicketNo;
                    
                    param = cmd.Parameters.Add("@BranchName", SqlDbType.VarChar, 50);
                    param.Value = BranchName;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;
                    
                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using statement cmd
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
    }
}
