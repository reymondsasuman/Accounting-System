﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using anecoacct.AccountingModel;
namespace anecoacct.AccountingClass
{
    class CheckVoucherQueries
    {

        public String AddCheckVoucherTax(CheckVoucherTax CheckVoucherTax, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_AddCheckVoucherTax";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = CheckVoucherTax.ReferenceNum;

                    param = cmd.Parameters.Add("@DateTrans", SqlDbType.DateTime);
                    param.Value = CheckVoucherTax.DateTrans;

                    param = cmd.Parameters.Add("@PayeeNo", SqlDbType.Int);
                    param.Value = CheckVoucherTax.PayeeNo;

                    param = cmd.Parameters.Add("@PayeeType", SqlDbType.VarChar, 50);
                    param.Value = CheckVoucherTax.PayeeType;
                     
                    param = cmd.Parameters.Add("@PayeeName", SqlDbType.VarChar, 200);
                    param.Value = CheckVoucherTax.PayeeName;

                    param = cmd.Parameters.Add("@PayTo", SqlDbType.VarChar, 200);
                    param.Value = CheckVoucherTax.PayTo;

                    param = cmd.Parameters.Add("@PayToAddress", SqlDbType.VarChar, 200);
                    param.Value = CheckVoucherTax.PayToAddress;

                    param = cmd.Parameters.Add("@PayToZipCode", SqlDbType.VarChar, 5);
                    param.Value = CheckVoucherTax.PayToZipCode;

                    param = cmd.Parameters.Add("@TIN", SqlDbType.VarChar, 50);
                    param.Value = CheckVoucherTax.TIN;

                    param = cmd.Parameters.Add("@CVNo", SqlDbType.VarChar, 20);
                    param.Value = CheckVoucherTax.CVNo;

                    param = cmd.Parameters.Add("@CheckVoucherType", SqlDbType.VarChar, 50);
                    param.Value = CheckVoucherTax.CVType;

                    param = cmd.Parameters.Add("@VatableType", SqlDbType.VarChar, 50);
                    param.Value = CheckVoucherTax.VatableType;

                    param = cmd.Parameters.Add("@NetVAT", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherTax.NetVAT;

                    param = cmd.Parameters.Add("@EVAT", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherTax.EVAT;

                    param = cmd.Parameters.Add("@TotalAmount", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherTax.TotalAmount;

                    param = cmd.Parameters.Add("@AmountPaid", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherTax.AmountPaid;

                    param = cmd.Parameters.Add("@Percentage", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherTax.Percentage;

                    param = cmd.Parameters.Add("@ATCNo", SqlDbType.VarChar, 50);
                    param.Value = CheckVoucherTax.ATCNo;

                    param = cmd.Parameters.Add("@AmountWithHeld", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherTax.AmountWithHeld;

                    param = cmd.Parameters.Add("@LocalTax", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherTax.LocalTax;

                    param = cmd.Parameters.Add("@OverrideEVAT", SqlDbType.VarChar, 1);
                    param.Value = CheckVoucherTax.OverrideEVAT;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String RemoveCheckVoucherTax(String CVNo, String Entry, String ReferenceNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_RemoveCheckVoucherTax";

                    param = cmd.Parameters.Add("@CVNo", SqlDbType.VarChar, 20);
                    param.Value = CVNo;

                    param = cmd.Parameters.Add("@Entry", SqlDbType.BigInt);
                    param.Value = Convert.ToInt64(Entry);

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemoveCheckVoucherBreakDown(String CVNo,Int32 PayeeNo, String PayeeType, String ReferenceNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_RemoveCheckVoucherBreakDown";

                    param = cmd.Parameters.Add("@CVNo", SqlDbType.VarChar, 20);
                    param.Value = CVNo;

                    param = cmd.Parameters.Add("@PayeeNo", SqlDbType.Int);
                    param.Value = PayeeNo;

                    param = cmd.Parameters.Add("@PayeeType", SqlDbType.VarChar,50);
                    param.Value = PayeeType;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<CheckVoucherTax> GetCheckVoucherTaxList_TempTable(String ReferenceNum, String CVNo, String Flag)
        {
            List<CheckVoucherTax> CheckVoucherTaxList = new List<CheckVoucherTax>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_GetCheckVoucherTax_Temp";
                    
                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;
                    
                    param = cmd.Parameters.Add("@CVNo", SqlDbType.VarChar, 20);
                    param.Value = CVNo;
                    
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                CheckVoucherTaxList.Add(new CheckVoucherTax()
                                {

                                    Code = Convert.ToInt64(dr["Entry"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    
                                    ,DateTrans = Convert.ToDateTime(dr["DateTrans"].ToString())
                                    ,
                                    PayeeNo = Convert.ToInt32(dr["PayeeNo"].ToString())
                                    ,
                                    PayeeType = Convert.ToString(dr["PayeeType"].ToString())
                                    ,
                                    PayeeName = Convert.ToString(dr["PayeeName"].ToString())
                                    ,
                                    PayTo = Convert.ToString(dr["PayTo"].ToString())
                                    ,
                                    PayToAddress = Convert.ToString(dr["PayToAddress"].ToString())
                                    ,
                                    PayToZipCode = Convert.ToString(dr["PayToZipCode"].ToString())
                                    ,
                                    TIN = Convert.ToString(dr["TIN"].ToString())
                                    ,
                                    CVNo = Convert.ToString(dr["CVNo"].ToString())
                                      ,  
                                    CVType = Convert.ToString(dr["CheckVoucherType"].ToString())
                                    ,
                                    VatableType = Convert.ToString(dr["VatableType"].ToString())
                                         ,
                                    NetVAT = Convert.ToDecimal(dr["NetVAT"].ToString())
                                         ,
                                    EVAT = Convert.ToDecimal(dr["EVAT"].ToString())
                                         ,
                                    TotalAmount = Convert.ToDecimal(dr["TotalAmount"].ToString())
                                        ,
                                    AmountPaid = Convert.ToDecimal(dr["AmountPaid"].ToString())
                                        ,
                                    CustCode = Convert.ToInt32(dr["CustCode"].ToString())
                                       ,
                                    Percentage = Convert.ToDecimal(dr["Percentage"].ToString())
                                    ,
                                    ATCNo = Convert.ToString(dr["ATCNo"].ToString())
                                    ,
                                    AmountWithHeld = Convert.ToDecimal(dr["AmountWithHeld"].ToString())
                                    ,
                                    LocalTax = Convert.ToDecimal(dr["LocalTax"].ToString())
                                 
                                });
                            }
                        }
                    }

                }
                return CheckVoucherTaxList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }


        public String AddCheckVoucherBreakDown(CheckVoucherBreakDown CheckVoucherBreakDown, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_AddCheckVoucherBreakDown";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = CheckVoucherBreakDown.ReferenceNum;

                    param = cmd.Parameters.Add("@CVNo", SqlDbType.VarChar, 20);
                    param.Value = CheckVoucherBreakDown.CVNo;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = CheckVoucherBreakDown.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = CheckVoucherBreakDown.Year;

                    param = cmd.Parameters.Add("@DateTrans", SqlDbType.DateTime);
                    param.Value = CheckVoucherBreakDown.DateTrans;

                    param = cmd.Parameters.Add("@PayeeNo", SqlDbType.Int);
                    param.Value = CheckVoucherBreakDown.PayeeNo;

                    param = cmd.Parameters.Add("@PayeeType", SqlDbType.VarChar,50);
                    param.Value = CheckVoucherBreakDown.PayeeType;

                    param = cmd.Parameters.Add("@CustCode", SqlDbType.Int);
                    param.Value = CheckVoucherBreakDown.CustCode;

                    param = cmd.Parameters.Add("@CustType", SqlDbType.VarChar,200);
                    param.Value = CheckVoucherBreakDown.CustType;

                    param = cmd.Parameters.Add("@PayeeName", SqlDbType.VarChar, 200);
                    param.Value = CheckVoucherBreakDown.PayeeName;

                    param = cmd.Parameters.Add("@PayTo", SqlDbType.VarChar, 200);
                    param.Value = CheckVoucherBreakDown.PayTo;

                    param = cmd.Parameters.Add("@PayToAddress", SqlDbType.VarChar, 200);
                    param.Value = CheckVoucherBreakDown.PayToAddress;

                    param = cmd.Parameters.Add("@PayToZipCode", SqlDbType.VarChar, 5);
                    param.Value = CheckVoucherBreakDown.PayToZipCode;

                    param = cmd.Parameters.Add("@TIN", SqlDbType.VarChar, 50);
                    param.Value = CheckVoucherBreakDown.TIN;

                    param = cmd.Parameters.Add("@GL_Debit", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = 0;

                    param = cmd.Parameters.Add("@GL_Credit", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = 0;

                    param = cmd.Parameters.Add("@SL_Debit", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherBreakDown.SL_Debit;

                    param = cmd.Parameters.Add("@SL_Credit", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherBreakDown.SL_Credit;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<CheckVoucherBreakDown> GetCheckVoucherBreakDownList_TempTable(String ReferenceNum, String CVNo, String Flag)
        {
            List<CheckVoucherBreakDown>CheckVoucherBreakDownList = new List<CheckVoucherBreakDown>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_GetCheckVoucherBreakDown_Temp";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@CVNo", SqlDbType.VarChar, 20);
                    param.Value = CVNo;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                CheckVoucherBreakDownList.Add(new CheckVoucherBreakDown()
                                {

                                    Code = Convert.ToInt64(dr["Entry"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    CVNo = Convert.ToString(dr["CVNo"].ToString())
                                      ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                    ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                         ,
                                    DateTrans = Convert.ToDateTime(dr["DateTrans"].ToString())
                                         ,
                                    PayeeNo = Convert.ToInt32(dr["PayeeNo"].ToString())
                                         ,
                                    PayeeType = Convert.ToString(dr["PayeeType"].ToString())
                                        ,
                                    CustCode = Convert.ToInt32(dr["CustCode"].ToString())
                                        ,
                                    CustType = Convert.ToString(dr["CustType"].ToString())
                                       ,
                                    PayeeName = Convert.ToString(dr["PayeeName"].ToString())
                                    ,
                                    PayTo = Convert.ToString(dr["PayTo"].ToString())
                                    ,
                                    PayToAddress = Convert.ToString(dr["PayToAddress"].ToString())
                                    ,
                                    PayToZipCode = Convert.ToString(dr["PayToZipCode"].ToString())
                                    ,
                                    TIN = Convert.ToString(dr["TIN"].ToString())
                                    ,
                                    GL_Debit = Convert.ToDecimal(dr["GL_Debit"].ToString())
                                    ,
                                    GL_Credit = Convert.ToDecimal(dr["GL_Credit"].ToString())
                                    ,
                                    SL_Debit = Convert.ToDecimal(dr["SL_Debit"].ToString())
                                    ,
                                    SL_Credit = Convert.ToDecimal(dr["SL_Credit"].ToString())

                                });
                            }
                        }
                    }

                }
                return CheckVoucherBreakDownList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

       
        public List<CheckVoucher> GetCheckVoucherList(String Month, String Year, String Flag, String Param)
        {
            try
            {
                List<CheckVoucher> CheckVoucherList = new List<CheckVoucher>();
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();
                    
                    DatabaseConnection.Connect();
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 60000;
                    cmd.CommandText = "sp_GetCheckVoucher";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 500);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;
                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;
                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                   
                        if (dr.HasRows)
                        {
                           
                            while (dr.Read())
                            {
                                CheckVoucherList.Add(new CheckVoucher{
                                    CVNo = Convert.ToString(dr["CVNo"].ToString())
                                    ,
                                    DateTrans = Convert.ToDateTime(dr["DateTrans"].ToString())
                                    ,
                                  
                                    PayTo = Convert.ToString(dr["PayTo"].ToString())
                                    ,
                                    TIN = Convert.ToString(dr["TIN"].ToString())
                                    ,
                                    PayToAddress = Convert.ToString(dr["PayToAddress"].ToString())
                                    ,
                                    PayToZipCode = Convert.ToString(dr["PayToZipCode"].ToString())
                                    ,
                                    Particulars = Convert.ToString(dr["Particulars"].ToString())
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                    ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                     ,
                                    GL_Debit = Convert.ToDecimal(dr["GL_Debit"].ToString())
                                     ,
                                    GL_Credit = Convert.ToDecimal(dr["GL_Credit"].ToString())
                                     ,
                                    SL_Debit = Convert.ToDecimal(dr["SL_Debit"].ToString())
                                     ,
                                    SL_Credit = Convert.ToDecimal(dr["SL_Credit"].ToString())
                                    ,
                                     ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                     ,
                                    TaxCount = Convert.ToInt32(dr["TaxCount"].ToString())
                                      ,
                                    IsTaxable = Convert.ToString(dr["Istaxable"].ToString())
                                });

                             
                            }//end of while
                        }//END OF HAS ROWS
                     
                    }//end of using dr
                    return CheckVoucherList;
                }//end of using cmd
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
           
            }
        }
        public List<CheckVoucher> GetCheckVoucherParticularsList(String Month, String Year, String Flag, String Param)
        {
            try
            {
                List<CheckVoucher> CheckVoucherList = new List<CheckVoucher>();
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();

                    DatabaseConnection.Connect();
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 60000;
                    cmd.CommandText = "sp_GetCheckVoucher";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 500);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;
                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;
                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {

                        if (dr.HasRows)
                        {

                            while (dr.Read())
                            {
                                CheckVoucherList.Add(new CheckVoucher
                                {
                                    Particulars = Convert.ToString(dr["Particulars"].ToString())
                                   
                                });


                            }//end of while
                        }//END OF HAS ROWS

                    }//end of using dr
                    return CheckVoucherList;
                }//end of using cmd
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();

            }
        }
        public List<CheckVoucher> GetCheckVoucherPayeeList(String Month, String Year, String Flag, String Param)
        {
            try
            {
                List<CheckVoucher> CheckVoucherList = new List<CheckVoucher>();
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();

                    DatabaseConnection.Connect();
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 60000;
                    cmd.CommandText = "sp_GetCheckVoucher";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 500);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;
                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;
                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {

                        if (dr.HasRows)
                        {

                            while (dr.Read())
                            {
                                CheckVoucherList.Add(new CheckVoucher
                                {
                                    PayTo = Convert.ToString(dr["PayTo"].ToString())
                                    ,
                                    TIN = Convert.ToString(dr["TIN"].ToString())
                                    ,
                                    PayToAddress = Convert.ToString(dr["PayToAddress"].ToString())
                                    ,
                                    PayToZipCode = Convert.ToString(dr["PayToZipCode"].ToString())

                                });


                            }//end of while
                        }//END OF HAS ROWS

                    }//end of using dr
                    return CheckVoucherList;
                }//end of using cmd
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();

            }
        }
        public String AddCheckVoucherRef(CheckVoucherRef CheckVoucherRef, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_AddCheckVoucherRef";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = CheckVoucherRef.ReferenceNum;

                    param = cmd.Parameters.Add("@CVNo", SqlDbType.VarChar, 20);
                    param.Value = CheckVoucherRef.CVNo;

                    param = cmd.Parameters.Add("@RefType", SqlDbType.VarChar, 50);
                    param.Value = CheckVoucherRef.RefType;

                    param = cmd.Parameters.Add("@RefNo", SqlDbType.VarChar, 50);
                    param.Value = CheckVoucherRef.RefNo;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }



        public List<CheckVoucherRef> GetCheckVoucherRefList_TempTable(String ReferenceNum, String CVNo, String Flag)
        {
            List<CheckVoucherRef> CheckVoucherRefList = new List<CheckVoucherRef>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_GetCheckVoucherRef_Temp";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@CVNo", SqlDbType.VarChar, 20);
                    param.Value = CVNo;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                CheckVoucherRefList.Add(new CheckVoucherRef()
                                {

                                    Code = Convert.ToInt64(dr["Entry"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    CVNo = Convert.ToString(dr["CVNo"].ToString())
                                      ,
                                    RecNo = Convert.ToInt32(dr["RecNo"].ToString())
                                    ,
                                    RefType = Convert.ToString(dr["RefType"].ToString())
                                         ,
                                    RefNo = Convert.ToString(dr["RefNo"].ToString())
                                   
                                });
                            }
                        }
                    }

                }
                return CheckVoucherRefList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemoveCheckVoucherRef(String CVNo, String RefType,String RefNo, String ReferenceNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_RemoveCheckVoucherRef";

                    param = cmd.Parameters.Add("@CVNo", SqlDbType.VarChar, 20);
                    param.Value = CVNo;

                    param = cmd.Parameters.Add("@RefType", SqlDbType.VarChar, 50);
                    param.Value = RefType;

                    param = cmd.Parameters.Add("@RefNo", SqlDbType.VarChar, 50);
                    param.Value = RefNo;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String AddCheckVoucherDetail(CheckVoucherDetail CheckVoucherDetail, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_AddCheckVoucheDetail";

                    param = cmd.Parameters.Add("@Entry", SqlDbType.BigInt);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = CheckVoucherDetail.ReferenceNum;

                    param = cmd.Parameters.Add("@CVNo", SqlDbType.VarChar, 20);
                    param.Value = CheckVoucherDetail.CVNo;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = CheckVoucherDetail.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar,4);
                    param.Value = CheckVoucherDetail.Year;

                    param = cmd.Parameters.Add("@AcctCode", SqlDbType.VarChar, 20);
                    param.Value = CheckVoucherDetail.AcctCode;

                    param = cmd.Parameters.Add("@GL_Debit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = CheckVoucherDetail.GL_Debit;

                    param = cmd.Parameters.Add("@GL_Credit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = CheckVoucherDetail.GL_Credit;

                    param = cmd.Parameters.Add("@SL_Debit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = CheckVoucherDetail.SL_Debit;

                    param = cmd.Parameters.Add("@SL_Credit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = CheckVoucherDetail.SL_Credit;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewCVDetailEntry= Convert.ToString(cmd.Parameters["@Entry"].Value);
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemoveCheckVoucherDetail( String ReferenceNum,Int64 Code)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_RemoveCheckVoucherDetailItem";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@Code", SqlDbType.Int);
                    param.Value = Code;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateCheckVoucherDetail(CheckVoucherDetail CheckVoucherDetail, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_UpdateCheckVoucheDetail";

                    param = cmd.Parameters.Add("@Entry", SqlDbType.BigInt);
                    param.Value = CheckVoucherDetail.Code;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = CheckVoucherDetail.ReferenceNum;

                    param = cmd.Parameters.Add("@CVNo", SqlDbType.VarChar, 20);
                    param.Value = CheckVoucherDetail.CVNo;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = CheckVoucherDetail.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = CheckVoucherDetail.Year;

                    param = cmd.Parameters.Add("@AcctCode", SqlDbType.VarChar, 20);
                    param.Value = CheckVoucherDetail.AcctCode;

                    param = cmd.Parameters.Add("@GL_Debit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = CheckVoucherDetail.GL_Debit;

                    param = cmd.Parameters.Add("@GL_Credit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = CheckVoucherDetail.GL_Credit;

                    param = cmd.Parameters.Add("@SL_Debit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = CheckVoucherDetail.SL_Debit;

                    param = cmd.Parameters.Add("@SL_Credit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = CheckVoucherDetail.SL_Credit;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String CancelCheckVoucher(String ReferenceNum, String CVNo)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_CancelCheckVoucher";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@CVNo", SqlDbType.VarChar, 20);
                    param.Value = CVNo;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String SaveCheckVoucher(CheckVoucher CheckVoucher)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_SaveCheckVoucher";

                    param = cmd.Parameters.Add("@CVNo", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = CheckVoucher.ReferenceNum;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = CheckVoucher.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = CheckVoucher.Year;

                    param = cmd.Parameters.Add("@DateTrans", SqlDbType.DateTime);
                    param.Value = CheckVoucher.DateTrans;

                    param = cmd.Parameters.Add("@Particulars", SqlDbType.VarChar, 1000);
                    param.Value = CheckVoucher.Particulars;

                    param = cmd.Parameters.Add("@PayeeNo", SqlDbType.Int);
                    param.Value = CheckVoucher.PayeeNo;

                    param = cmd.Parameters.Add("@PayeeType", SqlDbType.VarChar,50);
                    param.Value = CheckVoucher.PayeeType;

                    param = cmd.Parameters.Add("@PayeeName", SqlDbType.VarChar, 1000);
                    param.Value = CheckVoucher.PayeeName;

                    param = cmd.Parameters.Add("@PayTo", SqlDbType.VarChar, 1000);
                    param.Value = CheckVoucher.PayTo;

                    param = cmd.Parameters.Add("@PayToAddress", SqlDbType.VarChar, 1000);
                    param.Value = CheckVoucher.PayToAddress;

                    param = cmd.Parameters.Add("@PayToZipCode", SqlDbType.VarChar,5);
                    param.Value = CheckVoucher.PayToZipCode;

                    param = cmd.Parameters.Add("@TIN", SqlDbType.VarChar, 50);
                    param.Value = CheckVoucher.TIN;

                    param = cmd.Parameters.Add("@CustCode", SqlDbType.Int);
                    param.Value = CheckVoucher.CustCode;

                    param = cmd.Parameters.Add("@CheckNo", SqlDbType.VarChar, 50);
                    param.Value = CheckVoucher.CheckNo;

                    param = cmd.Parameters.Add("@CheckDate", SqlDbType.DateTime);
                    param.Value = CheckVoucher.CheckDate;

                    param = cmd.Parameters.Add("@Amount", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = CheckVoucher.Amount;


                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewCVNum = Convert.ToString(cmd.Parameters["@CVNo"].Value);
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                   
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }


        public String EditCheckVoucher(String ReferenceNum, String CVNo)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_EditCheckVoucher";

                    param = cmd.Parameters.Add("@CVNo", SqlDbType.VarChar, 20);
                    param.Value = CVNo;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.InputOutput;
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewCVRefNum = Convert.ToString(cmd.Parameters["@ReferenceNum"].Value);
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<CheckVoucherDetail> GetCheckVoucherDetailList(String Param, String Flag, String ReferenceNum)
        {
            List<CheckVoucherDetail> CheckVoucherDetailList = new List<CheckVoucherDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_GetCheckVoucherDetail";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
       
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                CheckVoucherDetailList.Add(new CheckVoucherDetail()
                                {

                                    Code = Convert.ToInt64(dr["Code"].ToString())
                                    ,ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                     ,
                                    CVNo = Convert.ToString(dr["CVNo"].ToString())
                                     ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                      ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                       ,
                                    DateTrans = Convert.ToDateTime(dr["DateTrans"].ToString())
                                        ,
                                    Particulars = Convert.ToString(dr["Particulars"].ToString())
                                        ,
                                    PayeeNo = String.IsNullOrEmpty(dr["PayeeNo"].ToString()) ? 0 : Convert.ToInt32(dr["PayeeNo"].ToString())
                                        ,
                                    PayeeType = Convert.ToString(dr["PayeeType"].ToString())
                                        ,
                                    PayeeName = Convert.ToString(dr["PayeeName"].ToString())
                                        ,
                                    PayTo = Convert.ToString(dr["PayTo"].ToString())
                                        ,
                                    PayToAddress = Convert.ToString(dr["PayToAddress"].ToString())
                                        ,
                                    PayToZipCode = Convert.ToString(dr["PayToZipCode"].ToString())
                                        ,
                                    TIN = Convert.ToString(dr["TIN"].ToString())
                                        ,
                                    CustCode = String.IsNullOrEmpty(dr["CustCode"].ToString())?0:Convert.ToInt32(dr["CustCode"].ToString())
                                        ,
                                    CheckNo = Convert.ToString(dr["CheckNo"].ToString())
                                        ,
                                    CheckDate = Convert.ToDateTime(dr["CheckDate"].ToString())
                                        ,
                                    Amount = Convert.ToDecimal(dr["Amount"].ToString())

                                        ,
                                    AcctCode = Convert.ToString(dr["AcctCode"].ToString())
                                        ,
                                    AcctDesc = Convert.ToString(dr["AcctDesc"].ToString())
                                        ,
                                    GL_Debit = Convert.ToDecimal(dr["GL_Debit"].ToString())
                                        ,
                                    GL_Credit = Convert.ToDecimal(dr["GL_Credit"].ToString())
                                        ,
                                    SL_Debit = Convert.ToDecimal(dr["SL_Debit"].ToString())
                                        ,
                                    SL_Credit = Convert.ToDecimal(dr["SL_Credit"].ToString())
     

                                });
                            }
                        }
                    }

                }
                return CheckVoucherDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String UpdateCheckVoucher(CheckVoucher CheckVoucher)
        {
            try
            {
                //save MRV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_UpdateCheckVoucher";

                    param = cmd.Parameters.Add("@CVNo", SqlDbType.VarChar, 20);
                    param.Value = CheckVoucher.CVNo;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = CheckVoucher.ReferenceNum;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = CheckVoucher.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = CheckVoucher.Year;

                    param = cmd.Parameters.Add("@DateTrans", SqlDbType.DateTime);
                    param.Value = CheckVoucher.DateTrans;

                    param = cmd.Parameters.Add("@Particulars", SqlDbType.VarChar,1000);
                    param.Value = CheckVoucher.Particulars;

                    param = cmd.Parameters.Add("@PayeeNo", SqlDbType.Int);
                    param.Value = CheckVoucher.PayeeNo;

                    param = cmd.Parameters.Add("@PayeeType", SqlDbType.VarChar, 50);
                    param.Value = CheckVoucher.PayeeType;

                    param = cmd.Parameters.Add("@PayeeName", SqlDbType.VarChar, 1000);
                    param.Value = CheckVoucher.PayeeName;

                    param = cmd.Parameters.Add("@PayTo", SqlDbType.VarChar, 1000);
                    param.Value = CheckVoucher.PayTo;

                    param = cmd.Parameters.Add("@PayToAddress", SqlDbType.VarChar, 1000);
                    param.Value = CheckVoucher.PayToAddress;

                    param = cmd.Parameters.Add("@PayToZipCode", SqlDbType.VarChar, 5);
                    param.Value = CheckVoucher.PayToZipCode;

                    param = cmd.Parameters.Add("@TIN", SqlDbType.VarChar, 50);
                    param.Value = CheckVoucher.TIN;

                    param = cmd.Parameters.Add("@CustCode", SqlDbType.Int);
                    param.Value = CheckVoucher.CustCode;

                    param = cmd.Parameters.Add("@CheckNo", SqlDbType.VarChar, 50);
                    param.Value = CheckVoucher.CheckNo;

                    param = cmd.Parameters.Add("@CheckDate", SqlDbType.DateTime);
                    param.Value = CheckVoucher.CheckDate;

                    param = cmd.Parameters.Add("@Amount", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = CheckVoucher.Amount;


                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }


        public String Add2307Dummy(CheckVoucherTax CheckVoucherTax, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_Add2307Dummy";

                    param = cmd.Parameters.Add("@DateTrans", SqlDbType.DateTime);
                    param.Value = CheckVoucherTax.DateTrans;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = CheckVoucherTax.ReferenceNum;

                    param = cmd.Parameters.Add("@PayeeNo", SqlDbType.Int);
                    param.Value = CheckVoucherTax.PayeeNo;

                    param = cmd.Parameters.Add("@PayeeType", SqlDbType.VarChar, 50);
                    param.Value = CheckVoucherTax.PayeeType;

                    param = cmd.Parameters.Add("@PayeeName", SqlDbType.VarChar, 200);
                    param.Value = CheckVoucherTax.PayeeName;

                    param = cmd.Parameters.Add("@PayTo", SqlDbType.VarChar, 200);
                    param.Value = CheckVoucherTax.PayTo;

                    param = cmd.Parameters.Add("@PayToAddress", SqlDbType.VarChar, 200);
                    param.Value = CheckVoucherTax.PayToAddress;

                    param = cmd.Parameters.Add("@PayToZipCode", SqlDbType.VarChar, 5);
                    param.Value = CheckVoucherTax.PayToZipCode;

                    param = cmd.Parameters.Add("@TIN", SqlDbType.VarChar, 50);
                    param.Value = CheckVoucherTax.TIN;

                    param = cmd.Parameters.Add("@VatableType", SqlDbType.VarChar, 50);
                    param.Value = CheckVoucherTax.VatableType;

                    param = cmd.Parameters.Add("@NetVAT", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherTax.NetVAT;

                    param = cmd.Parameters.Add("@EVAT", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherTax.EVAT;

                    param = cmd.Parameters.Add("@TotalAmount", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherTax.TotalAmount;

                    param = cmd.Parameters.Add("@AmountPaid", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherTax.AmountPaid;

                    param = cmd.Parameters.Add("@Percentage", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherTax.Percentage;

                    param = cmd.Parameters.Add("@ATCNo", SqlDbType.VarChar, 50);
                    param.Value = CheckVoucherTax.ATCNo;

                    param = cmd.Parameters.Add("@AmountWithHeld", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherTax.AmountWithHeld;

                    param = cmd.Parameters.Add("@LocalTax", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherTax.LocalTax;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<CheckVoucherTax> GetCheckVoucherTaxList(String ReferenceNum, String CVNo, String Flag)
        {
            List<CheckVoucherTax> CheckVoucherTaxList = new List<CheckVoucherTax>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_GetCheckVoucherTax";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@CVNo", SqlDbType.VarChar, 20);
                    param.Value = CVNo;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                CheckVoucherTaxList.Add(new CheckVoucherTax()
                                {

                                    Code = Convert.ToInt64(dr["Entry"].ToString())
                                    ,
                                    DateTrans=Convert.ToDateTime(dr["DateTrans"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    PayeeNo = Convert.ToInt32(dr["PayeeNo"].ToString())
                                    ,
                                    PayeeType = Convert.ToString(dr["PayeeType"].ToString())
                                    ,
                                    PayeeName = Convert.ToString(dr["PayeeName"].ToString())
                                    ,
                                    PayTo = Convert.ToString(dr["PayTo"].ToString())
                                    ,
                                    PayToAddress = Convert.ToString(dr["PayToAddress"].ToString())
                                    ,
                                    PayToZipCode = Convert.ToString(dr["PayToZipCode"].ToString())
                                    ,
                                    TIN = Convert.ToString(dr["TIN"].ToString())
                                    ,
                                    CVNo = Convert.ToString(dr["CVNo"].ToString())
                                      ,
                                    CVType = Convert.ToString(dr["CheckVoucherType"].ToString())
                                    ,
                                    VatableType = Convert.ToString(dr["VatableType"].ToString())
                                         ,
                                    NetVAT = Convert.ToDecimal(dr["NetVAT"].ToString())
                                         ,
                                    EVAT = Convert.ToDecimal(dr["EVAT"].ToString())
                                         ,
                                    TotalAmount = Convert.ToDecimal(dr["TotalAmount"].ToString())
                                        ,
                                    AmountPaid = Convert.ToDecimal(dr["AmountPaid"].ToString())
                                        ,
                                    CustCode = Convert.ToInt32(dr["CustCode"].ToString())
                                       ,
                                    Percentage = Convert.ToDecimal(dr["Percentage"].ToString())
                                    ,
                                    ATCNo = Convert.ToString(dr["ATCNo"].ToString())
                                    ,
                                    AmountWithHeld = Convert.ToDecimal(dr["AmountWithHeld"].ToString())
                                    ,
                                    LocalTax = Convert.ToDecimal(dr["LocalTax"].ToString())

                                });
                            }
                        }
                    }

                }
                return CheckVoucherTaxList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

    }
}
