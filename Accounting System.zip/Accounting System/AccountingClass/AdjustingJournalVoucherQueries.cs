﻿using anecoacct.AccountingModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace anecoacct.AccountingClass
{
    class AdjustingJournalVoucherQueries
    {
        public String AddAdjustingJournalVoucherDetail(AdjustingJournalVoucherDetail AdjustingJournalVoucherDetail, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_AddAdjustingJournalVoucherDetail";

                    param = cmd.Parameters.Add("@Entry", SqlDbType.BigInt);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = AdjustingJournalVoucherDetail.ReferenceNum;

                    param = cmd.Parameters.Add("@AJVNo", SqlDbType.VarChar, 20);
                    param.Value = AdjustingJournalVoucherDetail.AJVNo;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = AdjustingJournalVoucherDetail.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = AdjustingJournalVoucherDetail.Year;

                    param = cmd.Parameters.Add("@AcctCode", SqlDbType.VarChar, 20);
                    param.Value = AdjustingJournalVoucherDetail.AcctCode;

                    param = cmd.Parameters.Add("@GL_Debit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = AdjustingJournalVoucherDetail.GL_Debit;

                    param = cmd.Parameters.Add("@GL_Credit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = AdjustingJournalVoucherDetail.GL_Credit;

                    param = cmd.Parameters.Add("@SL_Debit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = AdjustingJournalVoucherDetail.SL_Debit;

                    param = cmd.Parameters.Add("@SL_Credit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = AdjustingJournalVoucherDetail.SL_Credit;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewAJVDetailEntry = Convert.ToString(cmd.Parameters["@Entry"].Value);
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String UpdateAdjustingJournalVoucherDetail(AdjustingJournalVoucherDetail AdjustingJournalVoucherDetail, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_UpdateAdjustingJournalVoucherDetail";

                    param = cmd.Parameters.Add("@Entry", SqlDbType.BigInt);
                    param.Value = AdjustingJournalVoucherDetail.Code;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = AdjustingJournalVoucherDetail.ReferenceNum;

                    param = cmd.Parameters.Add("@AJVNo", SqlDbType.VarChar, 20);
                    param.Value = AdjustingJournalVoucherDetail.AJVNo;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = AdjustingJournalVoucherDetail.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = AdjustingJournalVoucherDetail.Year;

                    param = cmd.Parameters.Add("@AcctCode", SqlDbType.VarChar, 20);
                    param.Value = AdjustingJournalVoucherDetail.AcctCode;

                    param = cmd.Parameters.Add("@GL_Debit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = AdjustingJournalVoucherDetail.GL_Debit;

                    param = cmd.Parameters.Add("@GL_Credit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = AdjustingJournalVoucherDetail.GL_Credit;

                    param = cmd.Parameters.Add("@SL_Debit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = AdjustingJournalVoucherDetail.SL_Debit;

                    param = cmd.Parameters.Add("@SL_Credit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = AdjustingJournalVoucherDetail.SL_Credit;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();

                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String CancelAdjustingJournalVoucher(String ReferenceNum, String AJVNo)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_CancelAdjustingJournalVoucher";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@AJVNo", SqlDbType.VarChar, 20);
                    param.Value = AJVNo;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String SaveAdjustingJournalVoucher(AdjustingJournalVoucher AdjustingJournalVoucher)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_SaveAdjustingJournalVoucher";

                    param = cmd.Parameters.Add("@AJVNo", SqlDbType.VarChar, 20);
                    param.Value = AdjustingJournalVoucher.AJVNo;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = AdjustingJournalVoucher.ReferenceNum;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = AdjustingJournalVoucher.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = AdjustingJournalVoucher.Year;

                    param = cmd.Parameters.Add("@DateTrans", SqlDbType.DateTime);
                    param.Value = AdjustingJournalVoucher.DateTrans;

                    param = cmd.Parameters.Add("@Particulars", SqlDbType.VarChar, 1000);
                    param.Value = AdjustingJournalVoucher.Particulars;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
              
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String EditAdjustingJournalVoucher(String ReferenceNum, String AJVNo)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_EditAdjustingJournalVoucher";

                    param = cmd.Parameters.Add("@AJVNo", SqlDbType.VarChar, 20);
                    param.Value = AJVNo;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.InputOutput;
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewAJVRefNum = Convert.ToString(cmd.Parameters["@ReferenceNum"].Value);
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<AdjustingJournalVoucherDetail> GetAdjustingJournalVoucherDetailList(String Param, String Flag, String ReferenceNum)
        {
            List<AdjustingJournalVoucherDetail> AdjustingJournalVoucherDetailList = new List<AdjustingJournalVoucherDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_GetAdjustingJournalVoucherDetail";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                AdjustingJournalVoucherDetailList.Add(new AdjustingJournalVoucherDetail()
                                {

                                    Code = Convert.ToInt64(dr["Code"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                     ,
                                    AJVNo = Convert.ToString(dr["AJVNo"].ToString())
                                     ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                      ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                       ,
                                    DateTrans = Convert.ToDateTime(dr["DateTrans"].ToString())
                                        ,
                                    Particulars = Convert.ToString(dr["Particulars"].ToString())
                                    ,
                                    AcctCode = Convert.ToString(dr["AcctCode"].ToString())
                                        ,
                                    AcctDesc = Convert.ToString(dr["AcctDesc"].ToString())
                                        ,
                                    GL_Debit = Convert.ToDecimal(dr["GL_Debit"].ToString())
                                        ,
                                    GL_Credit = Convert.ToDecimal(dr["GL_Credit"].ToString())
                                        ,
                                    SL_Debit = Convert.ToDecimal(dr["SL_Debit"].ToString())
                                        ,
                                    SL_Credit = Convert.ToDecimal(dr["SL_Credit"].ToString())


                                });
                            }
                        }
                    }

                }
                return AdjustingJournalVoucherDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<AdjustingJournalVoucher> GetAdjustingJournalVoucherList(String Flag, String Param,String Month, String Year)
        {
            try
            {
                List<AdjustingJournalVoucher> AdjustingJournalVoucherList = new List<AdjustingJournalVoucher>();
                using (SqlCommand cmd = new SqlCommand())
                {
                    int x = 0;
                    SqlParameter param = new SqlParameter();
                    
 
                    DatabaseConnection.Connect();
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 60000;
                    cmd.CommandText = "sp_GetAdjustingJournalVoucher";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 50);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;
                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;
                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                    
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                AdjustingJournalVoucherList.Add( new AdjustingJournalVoucher() { 
                                  AJVNo= String.IsNullOrEmpty(dr["AJVNo"].ToString()) ? "" : dr["AJVNo"].ToString()
                                  ,DateTrans =   Convert.ToDateTime(dr["DateTrans"].ToString())
                                  ,Particulars = String.IsNullOrEmpty(dr["Particulars"].ToString()) ? "" : dr["Particulars"].ToString().Trim()
                                  ,GL_Debit = Convert.ToDecimal(dr["GL_Debit"].ToString())
                                  ,GL_Credit= Convert.ToDecimal(dr["GL_Credit"].ToString())
                                  ,SL_Debit= Convert.ToDecimal(dr["SL_Debit"].ToString())
                                  ,SL_Credit= Convert.ToDecimal(dr["SL_Credit"].ToString())
                                });

                             
                            }//end of while
                        }//END OF HAS ROWS
                        return AdjustingJournalVoucherList;
                    }//end of using dr
                }//end of using cmd
            }//end of try
            catch (Exception ex)
            {

                return null;

            }
            finally
            {
                DatabaseConnection.DBClose();
           
            }
        }

        public String UpdateAdjustingJournalVoucher(AdjustingJournalVoucher AdjustingJournalVoucher)
        {
            try
            {
                //save MRV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_UpdateAdjustingJournalVoucher";

                    param = cmd.Parameters.Add("@AJVNo", SqlDbType.VarChar, 20);
                    param.Value = AdjustingJournalVoucher.AJVNo;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = AdjustingJournalVoucher.ReferenceNum;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = AdjustingJournalVoucher.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = AdjustingJournalVoucher.Year;

                    param = cmd.Parameters.Add("@DateTrans", SqlDbType.DateTime);
                    param.Value = AdjustingJournalVoucher.DateTrans;

                    param = cmd.Parameters.Add("@Particulars", SqlDbType.VarChar, 1000);
                    param.Value = AdjustingJournalVoucher.Particulars;

                  
                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        //public void GetLastMaxJV( String Year, String Month)
        //{

        //    DatabaseConnection.Connect();
        //    using (SqlCommand cmd = new SqlCommand())
        //    {
        //        SqlParameter param = new SqlParameter();
        //        cmd.CommandTimeout = 6000;
        //        cmd.Connection = DatabaseConnection.cnn;
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.CommandText = "sp_GetLastMaxJv";
        //        param = cmd.Parameters.Add("@MaxJVNo", SqlDbType.VarChar, 20);
        //        param.Direction = ParameterDirection.Output;
        //        param = cmd.Parameters.Add("@LastJVNo", SqlDbType.VarChar, 20);
        //        param.Direction = ParameterDirection.Output;
        //        param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
        //        param.Value = Year;
        //        param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
        //        param.Value =Month;

        //        cmd.ExecuteNonQuery();
        //        GlobalVariable.LastJVNum = Convert.ToString(cmd.Parameters["@LastJVNo"].Value);
        //        GlobalVariable.MaxJVNum = Convert.ToString(cmd.Parameters["@MaxJVNo"].Value);
        //        DatabaseConnection.DBClose();
        //    }//end of using cmd
        //}
        public String RemoveAdjustingJournalVoucherDetail(String ReferenceNum, Int64 Code)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_RemoveAdjustingJournalVoucherDetailItem";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@Code", SqlDbType.Int);
                    param.Value = Code;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();

                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
    }
}
