﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using anecoacct.AccountingModel;
namespace anecoacct.AccountingClass
{
    class AccountsPayableVoucherQueries
    {

        public String AddAccountsPayableVoucherTax(AccountsPayableVoucherTax AccountsPayableVoucherTax, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_AddAccountsPayableVoucherTax";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = AccountsPayableVoucherTax.ReferenceNum;

                    param = cmd.Parameters.Add("@PayeeNo", SqlDbType.Int);
                    param.Value = AccountsPayableVoucherTax.PayeeNo;

                    param = cmd.Parameters.Add("@PayeeType", SqlDbType.VarChar, 50);
                    param.Value = AccountsPayableVoucherTax.PayeeType;

                    param = cmd.Parameters.Add("@PayeeName", SqlDbType.VarChar, 200);
                    param.Value = AccountsPayableVoucherTax.PayeeName;

                    param = cmd.Parameters.Add("@PayTo", SqlDbType.VarChar, 200);
                    param.Value = AccountsPayableVoucherTax.PayTo;

                    param = cmd.Parameters.Add("@PayToAddress", SqlDbType.VarChar, 200);
                    param.Value = AccountsPayableVoucherTax.PayToAddress;

                    param = cmd.Parameters.Add("@PayToZipCode", SqlDbType.VarChar, 5);
                    param.Value = AccountsPayableVoucherTax.PayToZipCode;

                    param = cmd.Parameters.Add("@TIN", SqlDbType.VarChar, 50);
                    param.Value = AccountsPayableVoucherTax.TIN;

                    param = cmd.Parameters.Add("@APVNo", SqlDbType.VarChar, 20);
                    param.Value = AccountsPayableVoucherTax.APVNo;

                    param = cmd.Parameters.Add("@APVType", SqlDbType.VarChar, 50);
                    param.Value = AccountsPayableVoucherTax.APVType;

                    param = cmd.Parameters.Add("@VatableType", SqlDbType.VarChar, 50);
                    param.Value = AccountsPayableVoucherTax.VatableType;

                    param = cmd.Parameters.Add("@NetVAT", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = AccountsPayableVoucherTax.NetVAT;

                    param = cmd.Parameters.Add("@EVAT", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = AccountsPayableVoucherTax.EVAT;

                    param = cmd.Parameters.Add("@TotalAmount", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = AccountsPayableVoucherTax.TotalAmount;

                    param = cmd.Parameters.Add("@AmountPaid", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = AccountsPayableVoucherTax.AmountPaid;

                    param = cmd.Parameters.Add("@Percentage", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = AccountsPayableVoucherTax.Percentage;

                    param = cmd.Parameters.Add("@ATCNo", SqlDbType.VarChar, 50);
                    param.Value = AccountsPayableVoucherTax.ATCNo;

                    param = cmd.Parameters.Add("@AmountWithHeld", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = AccountsPayableVoucherTax.AmountWithHeld;

                    param = cmd.Parameters.Add("@LocalTax", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = AccountsPayableVoucherTax.LocalTax;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String RemoveAccountsPayableVoucherTax(String APVNo, String Entry, String ReferenceNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_RemoveAccountsPayableVoucherTax";

                    param = cmd.Parameters.Add("@APVNo", SqlDbType.VarChar, 20);
                    param.Value = APVNo;

                    param = cmd.Parameters.Add("@Entry", SqlDbType.BigInt);
                    param.Value = Convert.ToInt64(Entry);

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemoveCheckVoucherBreakDown(String CVNo,Int32 PayeeNo, String PayeeType, String ReferenceNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_RemoveCheckVoucherBreakDown";

                    param = cmd.Parameters.Add("@CVNo", SqlDbType.VarChar, 20);
                    param.Value = CVNo;

                    param = cmd.Parameters.Add("@PayeeNo", SqlDbType.Int);
                    param.Value = PayeeNo;

                    param = cmd.Parameters.Add("@PayeeType", SqlDbType.VarChar,50);
                    param.Value = PayeeType;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<AccountsPayableVoucherTax> GetAccountsPayableVoucherTaxList_TempTable(String ReferenceNum, String APVNo, String Flag)
        {
            List<AccountsPayableVoucherTax> AccountsPayableVoucherTaxList = new List<AccountsPayableVoucherTax>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_GetAccountsPayableVoucherTax_Temp";
                    
                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;
                    
                    param = cmd.Parameters.Add("@APVNo", SqlDbType.VarChar, 20);
                    param.Value = APVNo;
                    
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
                    
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                AccountsPayableVoucherTaxList.Add(new AccountsPayableVoucherTax()
                                {

                                    Code = Convert.ToInt64(dr["Entry"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    PayeeNo = Convert.ToInt32(dr["PayeeNo"].ToString())
                                    ,
                                    PayeeType = Convert.ToString(dr["PayeeType"].ToString())
                                    ,
                                    PayeeName = Convert.ToString(dr["PayeeName"].ToString())
                                    ,
                                    PayTo = Convert.ToString(dr["PayTo"].ToString())
                                    ,
                                    PayToAddress = Convert.ToString(dr["PayToAddress"].ToString())
                                    ,
                                    PayToZipCode = Convert.ToString(dr["PayToZipCode"].ToString())
                                    ,
                                    TIN = Convert.ToString(dr["TIN"].ToString())
                                    ,
                                    APVNo = Convert.ToString(dr["APVNo"].ToString())
                                      ,  
                                    APVType = Convert.ToString(dr["APVType"].ToString())
                                    ,
                                    VatableType = Convert.ToString(dr["VatableType"].ToString())
                                         ,
                                    NetVAT = Convert.ToDecimal(dr["NetVAT"].ToString())
                                         ,
                                    EVAT = Convert.ToDecimal(dr["EVAT"].ToString())
                                         ,
                                    TotalAmount = Convert.ToDecimal(dr["TotalAmount"].ToString())
                                        ,
                                    AmountPaid = Convert.ToDecimal(dr["AmountPaid"].ToString())
                                        ,
                                    CustCode = Convert.ToInt32(dr["CustCode"].ToString())
                                       ,
                                    Percentage = Convert.ToDecimal(dr["Percentage"].ToString())
                                    ,
                                    ATCNo = Convert.ToString(dr["ATCNo"].ToString())
                                    ,
                                    AmountWithHeld = Convert.ToDecimal(dr["AmountWithHeld"].ToString())
                                    ,
                                    LocalTax = Convert.ToDecimal(dr["LocalTax"].ToString())
                                 
                                });
                            }
                        }
                    }

                }
                return AccountsPayableVoucherTaxList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }


        public String AddCheckVoucherBreakDown(CheckVoucherBreakDown CheckVoucherBreakDown, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_AddCheckVoucherBreakDown";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = CheckVoucherBreakDown.ReferenceNum;

                    param = cmd.Parameters.Add("@CVNo", SqlDbType.VarChar, 20);
                    param.Value = CheckVoucherBreakDown.CVNo;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = CheckVoucherBreakDown.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = CheckVoucherBreakDown.Year;

                    param = cmd.Parameters.Add("@DateTrans", SqlDbType.DateTime);
                    param.Value = CheckVoucherBreakDown.DateTrans;

                    param = cmd.Parameters.Add("@PayeeNo", SqlDbType.Int);
                    param.Value = CheckVoucherBreakDown.PayeeNo;

                    param = cmd.Parameters.Add("@PayeeType", SqlDbType.VarChar,50);
                    param.Value = CheckVoucherBreakDown.PayeeType;

                    param = cmd.Parameters.Add("@CustCode", SqlDbType.Int);
                    param.Value = CheckVoucherBreakDown.CustCode;

                    param = cmd.Parameters.Add("@CustType", SqlDbType.VarChar,200);
                    param.Value = CheckVoucherBreakDown.CustType;

                    param = cmd.Parameters.Add("@PayeeName", SqlDbType.VarChar, 200);
                    param.Value = CheckVoucherBreakDown.PayeeName;

                    param = cmd.Parameters.Add("@PayTo", SqlDbType.VarChar, 200);
                    param.Value = CheckVoucherBreakDown.PayTo;

                    param = cmd.Parameters.Add("@PayToAddress", SqlDbType.VarChar, 200);
                    param.Value = CheckVoucherBreakDown.PayToAddress;

                    param = cmd.Parameters.Add("@PayToZipCode", SqlDbType.VarChar, 5);
                    param.Value = CheckVoucherBreakDown.PayToZipCode;

                    param = cmd.Parameters.Add("@TIN", SqlDbType.VarChar, 50);
                    param.Value = CheckVoucherBreakDown.TIN;

                    param = cmd.Parameters.Add("@GL_Debit", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = 0;

                    param = cmd.Parameters.Add("@GL_Credit", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = 0;

                    param = cmd.Parameters.Add("@SL_Debit", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherBreakDown.SL_Debit;

                    param = cmd.Parameters.Add("@SL_Credit", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherBreakDown.SL_Credit;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<CheckVoucherBreakDown> GetCheckVoucherBreakDownList_TempTable(String ReferenceNum, String CVNo, String Flag)
        {
            List<CheckVoucherBreakDown>CheckVoucherBreakDownList = new List<CheckVoucherBreakDown>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_GetCheckVoucherBreakDown_Temp";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@CVNo", SqlDbType.VarChar, 20);
                    param.Value = CVNo;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                CheckVoucherBreakDownList.Add(new CheckVoucherBreakDown()
                                {

                                    Code = Convert.ToInt64(dr["Entry"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    CVNo = Convert.ToString(dr["CVNo"].ToString())
                                      ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                    ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                         ,
                                    DateTrans = Convert.ToDateTime(dr["DateTrans"].ToString())
                                         ,
                                    PayeeNo = Convert.ToInt32(dr["PayeeNo"].ToString())
                                         ,
                                    PayeeType = Convert.ToString(dr["PayeeType"].ToString())
                                        ,
                                    CustCode = Convert.ToInt32(dr["CustCode"].ToString())
                                        ,
                                    CustType = Convert.ToString(dr["CustType"].ToString())
                                       ,
                                    PayeeName = Convert.ToString(dr["PayeeName"].ToString())
                                    ,
                                    PayTo = Convert.ToString(dr["PayTo"].ToString())
                                    ,
                                    PayToAddress = Convert.ToString(dr["PayToAddress"].ToString())
                                    ,
                                    PayToZipCode = Convert.ToString(dr["PayToZipCode"].ToString())
                                    ,
                                    TIN = Convert.ToString(dr["TIN"].ToString())
                                    ,
                                    GL_Debit = Convert.ToDecimal(dr["GL_Debit"].ToString())
                                    ,
                                    GL_Credit = Convert.ToDecimal(dr["GL_Credit"].ToString())
                                    ,
                                    SL_Debit = Convert.ToDecimal(dr["SL_Debit"].ToString())
                                    ,
                                    SL_Credit = Convert.ToDecimal(dr["SL_Credit"].ToString())

                                });
                            }
                        }
                    }

                }
                return CheckVoucherBreakDownList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

       
        public List<CheckVoucher> GetCheckVoucherList(String Month, String Year, String Flag, String Param)
        {
            try
            {
                List<CheckVoucher> CheckVoucherList = new List<CheckVoucher>();
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();
                    
                    DatabaseConnection.Connect();
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 60000;
                    cmd.CommandText = "sp_GetCheckVoucher";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 500);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;
                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;
                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                   
                        if (dr.HasRows)
                        {
                           
                            while (dr.Read())
                            {
                                CheckVoucherList.Add(new CheckVoucher{
                                    CVNo = Convert.ToString(dr["CVNo"].ToString())
                                    ,
                                    DateTrans = Convert.ToDateTime(dr["DateTrans"].ToString())
                                    ,
                                  
                                    PayTo = Convert.ToString(dr["PayTo"].ToString())
                                    ,
                                    TIN = Convert.ToString(dr["TIN"].ToString())
                                    ,
                                    PayToAddress = Convert.ToString(dr["PayToAddress"].ToString())
                                    ,
                                    PayToZipCode = Convert.ToString(dr["PayToZipCode"].ToString())
                                    ,
                                    Particulars = Convert.ToString(dr["Particulars"].ToString())
                                    ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                    ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                     ,
                                    GL_Debit = Convert.ToDecimal(dr["GL_Debit"].ToString())
                                     ,
                                    GL_Credit = Convert.ToDecimal(dr["GL_Credit"].ToString())
                                     ,
                                    SL_Debit = Convert.ToDecimal(dr["SL_Debit"].ToString())
                                     ,
                                    SL_Credit = Convert.ToDecimal(dr["SL_Credit"].ToString())
                                    ,
                                     ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    
                                });

                             
                            }//end of while
                        }//END OF HAS ROWS
                     
                    }//end of using dr
                    return CheckVoucherList;
                }//end of using cmd
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
           
            }
        }
        public List<CheckVoucher> GetCheckVoucherParticularsList(String Month, String Year, String Flag, String Param)
        {
            try
            {
                List<CheckVoucher> CheckVoucherList = new List<CheckVoucher>();
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();

                    DatabaseConnection.Connect();
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 60000;
                    cmd.CommandText = "sp_GetCheckVoucher";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 500);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;
                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;
                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {

                        if (dr.HasRows)
                        {

                            while (dr.Read())
                            {
                                CheckVoucherList.Add(new CheckVoucher
                                {
                                    Particulars = Convert.ToString(dr["Particulars"].ToString())
                                   
                                });


                            }//end of while
                        }//END OF HAS ROWS

                    }//end of using dr
                    return CheckVoucherList;
                }//end of using cmd
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();

            }
        }
        public List<AccountsPayableVoucher> GetAccountsPayableVoucherPayeeList(String Month, String Year, String Flag, String Param)
        {
            try
            {
                List<AccountsPayableVoucher> AccountsPayableVoucherList = new List<AccountsPayableVoucher>();
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();

                    DatabaseConnection.Connect();
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 60000;
                    cmd.CommandText = "sp_GetCheckVoucher";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 500);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;
                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = Month;
                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = Year;
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {

                        if (dr.HasRows)
                        {

                            while (dr.Read())
                            {
                                AccountsPayableVoucherList.Add(new AccountsPayableVoucher
                                {
                                    PayTo = Convert.ToString(dr["PayTo"].ToString())
                                    ,
                                    TIN = Convert.ToString(dr["TIN"].ToString())
                                    ,
                                    PayToAddress = Convert.ToString(dr["PayToAddress"].ToString())
                                    ,
                                    PayToZipCode = Convert.ToString(dr["PayToZipCode"].ToString())

                                });


                            }//end of while
                        }//END OF HAS ROWS

                    }//end of using dr
                    return AccountsPayableVoucherList;
                }//end of using cmd
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();

            }
        }
        public String AddAccountsPayableVoucherRef(AccountsPayableVoucherRef AccountsPayableVoucherRef, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_AddAccountsPayableVoucherRef";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = AccountsPayableVoucherRef.ReferenceNum;

                    param = cmd.Parameters.Add("@APVNo", SqlDbType.VarChar, 20);
                    param.Value = AccountsPayableVoucherRef.APVNo;

                    param = cmd.Parameters.Add("@RefType", SqlDbType.VarChar, 50);
                    param.Value = AccountsPayableVoucherRef.RefType;

                    param = cmd.Parameters.Add("@RefNo", SqlDbType.VarChar, 50);
                    param.Value = AccountsPayableVoucherRef.RefNo;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }



        public List<AccountsPayableVoucherRef> GetAccountsPayableVoucherRefList_TempTable(String ReferenceNum, String APVNo, String Flag)
        {
            List<AccountsPayableVoucherRef> AccountsPayableVoucherRefList = new List<AccountsPayableVoucherRef>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_GetAccountsPayableVoucherRef_Temp";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 50);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@APVNo", SqlDbType.VarChar, 20);
                    param.Value = APVNo;

                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                AccountsPayableVoucherRefList.Add(new AccountsPayableVoucherRef()
                                {

                                    Code = Convert.ToInt64(dr["Entry"].ToString())
                                    ,
                                    ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                    ,
                                    APVNo = Convert.ToString(dr["APVNo"].ToString())
                                      ,
                                    RecNo = Convert.ToInt32(dr["RecNo"].ToString())
                                    ,
                                    RefType = Convert.ToString(dr["RefType"].ToString())
                                         ,
                                    RefNo = Convert.ToString(dr["RefNo"].ToString())
                                   
                                });
                            }
                        }
                    }

                }
                return AccountsPayableVoucherRefList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemoveAccountsPayableVoucherRef(String APVNo, String RefType,String RefNo, String ReferenceNum)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_RemoveAccountsPayableVoucherRef";

                    param = cmd.Parameters.Add("@APVNo", SqlDbType.VarChar, 20);
                    param.Value = APVNo;

                    param = cmd.Parameters.Add("@RefType", SqlDbType.VarChar, 50);
                    param.Value = RefType;

                    param = cmd.Parameters.Add("@RefNo", SqlDbType.VarChar, 50);
                    param.Value = RefNo;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String AddAccountsPayableVoucherDetail(AccountsPayableVoucherDetail AccountsPayableVoucherDetail, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_AddAccountsPayableVoucherDetail";

                    param = cmd.Parameters.Add("@Entry", SqlDbType.BigInt);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = AccountsPayableVoucherDetail.ReferenceNum;

                    param = cmd.Parameters.Add("@APVNo", SqlDbType.VarChar, 20);
                    param.Value = AccountsPayableVoucherDetail.APVNo;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = AccountsPayableVoucherDetail.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar,4);
                    param.Value = AccountsPayableVoucherDetail.Year;

                    param = cmd.Parameters.Add("@AcctCode", SqlDbType.VarChar, 20);
                    param.Value = AccountsPayableVoucherDetail.AcctCode;

                    param = cmd.Parameters.Add("@GL_Debit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = AccountsPayableVoucherDetail.GL_Debit;

                    param = cmd.Parameters.Add("@GL_Credit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = AccountsPayableVoucherDetail.GL_Credit;

                    param = cmd.Parameters.Add("@SL_Debit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = AccountsPayableVoucherDetail.SL_Debit;

                    param = cmd.Parameters.Add("@SL_Credit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = AccountsPayableVoucherDetail.SL_Credit;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewAPVDetailEntry= Convert.ToString(cmd.Parameters["@Entry"].Value);
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String RemoveAccountsPayableVoucherDetail( String ReferenceNum,Int64 Code)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_RemoveAccountsPayableVoucherDetailItem";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@Code", SqlDbType.Int);
                    param.Value = Code;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public String UpdateAccountsPayableVoucherDetail(AccountsPayableVoucherDetail AccountsPayableVoucherDetail, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_UpdateAccountsPayableVoucherDetail";

                    param = cmd.Parameters.Add("@Entry", SqlDbType.BigInt);
                    param.Value = AccountsPayableVoucherDetail.Code;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = AccountsPayableVoucherDetail.ReferenceNum;

                    param = cmd.Parameters.Add("@APVNo", SqlDbType.VarChar, 20);
                    param.Value = AccountsPayableVoucherDetail.APVNo;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = AccountsPayableVoucherDetail.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = AccountsPayableVoucherDetail.Year;

                    param = cmd.Parameters.Add("@AcctCode", SqlDbType.VarChar, 20);
                    param.Value = AccountsPayableVoucherDetail.AcctCode;

                    param = cmd.Parameters.Add("@GL_Debit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = AccountsPayableVoucherDetail.GL_Debit;

                    param = cmd.Parameters.Add("@GL_Credit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = AccountsPayableVoucherDetail.GL_Credit;

                    param = cmd.Parameters.Add("@SL_Debit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = AccountsPayableVoucherDetail.SL_Debit;

                    param = cmd.Parameters.Add("@SL_Credit", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = AccountsPayableVoucherDetail.SL_Credit;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String CancelAccountsPayableVoucher(String ReferenceNum, String APVNo)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_CancelAccountsPayableVoucher";

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@APVNo", SqlDbType.VarChar, 20);
                    param.Value = APVNo;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 100);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String SaveAccountsPayableVoucher(AccountsPayableVoucher AccountsPayableVoucher)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_SaveAccountsPayableVoucher";

                    param = cmd.Parameters.Add("@APVNo", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.Output;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = AccountsPayableVoucher.ReferenceNum;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = AccountsPayableVoucher.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = AccountsPayableVoucher.Year;

                    param = cmd.Parameters.Add("@DateTrans", SqlDbType.DateTime);
                    param.Value = AccountsPayableVoucher.DateTrans;

                    param = cmd.Parameters.Add("@Particulars", SqlDbType.VarChar, 5000);
                    param.Value = AccountsPayableVoucher.Particulars;

                    param = cmd.Parameters.Add("@PayeeNo", SqlDbType.Int);
                    param.Value = AccountsPayableVoucher.PayeeNo;

                    param = cmd.Parameters.Add("@PayeeType", SqlDbType.VarChar,50);
                    param.Value = AccountsPayableVoucher.PayeeType;

                    param = cmd.Parameters.Add("@PayeeName", SqlDbType.VarChar, 1000);
                    param.Value = AccountsPayableVoucher.PayeeName;

                    param = cmd.Parameters.Add("@PayTo", SqlDbType.VarChar, 1000);
                    param.Value = AccountsPayableVoucher.PayTo;

                    param = cmd.Parameters.Add("@PayToAddress", SqlDbType.VarChar, 1000);
                    param.Value = AccountsPayableVoucher.PayToAddress;

                    param = cmd.Parameters.Add("@PayToZipCode", SqlDbType.VarChar,5);
                    param.Value = AccountsPayableVoucher.PayToZipCode;

                    param = cmd.Parameters.Add("@TIN", SqlDbType.VarChar, 50);
                    param.Value = AccountsPayableVoucher.TIN;

                    param = cmd.Parameters.Add("@CustCode", SqlDbType.Int);
                    param.Value = AccountsPayableVoucher.CustCode;

                 
                    param = cmd.Parameters.Add("@Amount", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = AccountsPayableVoucher.Amount;


                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewAPVNum = Convert.ToString(cmd.Parameters["@APVNo"].Value);
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                   
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }


        public String EditAccountsPayableVoucher(String ReferenceNum, String APVNo)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand())
                {
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_EditAccountsPayableVoucher";

                    param = cmd.Parameters.Add("@APVNo", SqlDbType.VarChar, 20);
                    param.Value = APVNo;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Direction = ParameterDirection.InputOutput;
                    param.Value = ReferenceNum;

                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;//GlobalVariable Class for global variable

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 300);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    GlobalVariable.NewAPVRefNum = Convert.ToString(cmd.Parameters["@ReferenceNum"].Value);
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public List<AccountsPayableVoucherDetail> GetAccountsPayableVoucherDetailList(String Param, String Flag, String ReferenceNum)
        {
            List<AccountsPayableVoucherDetail> AccountsPayableVoucherDetailList = new List<AccountsPayableVoucherDetail>();
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_GetAccountsPayableVoucherDetail";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 100);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 50);
                    param.Value = Flag;
       
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                AccountsPayableVoucherDetailList.Add(new AccountsPayableVoucherDetail()
                                {

                                    Code = Convert.ToInt64(dr["Code"].ToString())
                                    ,ReferenceNum = Convert.ToString(dr["ReferenceNum"].ToString())
                                     ,
                                    APVNo = Convert.ToString(dr["APVNo"].ToString())
                                     ,
                                    Month = Convert.ToString(dr["Month"].ToString())
                                      ,
                                    Year = Convert.ToString(dr["Year"].ToString())
                                       ,
                                    DateTrans = Convert.ToDateTime(dr["DateTrans"].ToString())
                                        ,
                                    Particulars = Convert.ToString(dr["Particulars"].ToString())
                                        ,
                                    PayeeNo = String.IsNullOrEmpty(dr["SupplierNo"].ToString()) ? 0 : Convert.ToInt32(dr["SupplierNo"].ToString())
                                        ,
                                 
                                    PayeeName = Convert.ToString(dr["PayeeName"].ToString())
                                        ,
                                    PayTo = Convert.ToString(dr["PayTo"].ToString())
                                        ,
                                    PayToAddress = Convert.ToString(dr["PayToAddress"].ToString())
                                        ,
                                    PayToZipCode = Convert.ToString(dr["PayToZipCode"].ToString())
                                        ,
                                    TIN = Convert.ToString(dr["TIN"].ToString())
                                        ,
                                  
                                  
                                    //Amount = Convert.ToDecimal(dr["Amount"].ToString())

                                    //    ,
                                    AcctCode = Convert.ToString(dr["AcctCode"].ToString())
                                        ,
                                    AcctDesc = Convert.ToString(dr["AcctDesc"].ToString())
                                        ,
                                    GL_Debit = Convert.ToDecimal(dr["GL_Debit"].ToString())
                                        ,
                                    GL_Credit = Convert.ToDecimal(dr["GL_Credit"].ToString())
                                        ,
                                    SL_Debit = Convert.ToDecimal(dr["SL_Debit"].ToString())
                                        ,
                                    SL_Credit = Convert.ToDecimal(dr["SL_Credit"].ToString())
     

                                });
                            }
                        }
                    }

                }
                return AccountsPayableVoucherDetailList;
            }
            catch (Exception ex)
            {

                return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }

        public String UpdateAccountsPayableVoucher(AccountsPayableVoucher AccountsPayableVoucher)
        {
            try
            {
                //save MRV table
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_UpdateAccountsPayableVoucher";

                    param = cmd.Parameters.Add("@APVNo", SqlDbType.VarChar, 20);
                    param.Value = AccountsPayableVoucher.APVNo;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = AccountsPayableVoucher.ReferenceNum;

                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    param.Value = AccountsPayableVoucher.Month;

                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    param.Value = AccountsPayableVoucher.Year;

                    param = cmd.Parameters.Add("@DateTrans", SqlDbType.DateTime);
                    param.Value = AccountsPayableVoucher.DateTrans;

                    param = cmd.Parameters.Add("@Particulars", SqlDbType.VarChar,5000);
                    param.Value = AccountsPayableVoucher.Particulars;

                    param = cmd.Parameters.Add("@PayeeNo", SqlDbType.Int);
                    param.Value = AccountsPayableVoucher.PayeeNo;

                    param = cmd.Parameters.Add("@PayeeType", SqlDbType.VarChar, 50);
                    param.Value = AccountsPayableVoucher.PayeeType;

                    param = cmd.Parameters.Add("@PayeeName", SqlDbType.VarChar, 1000);
                    param.Value = AccountsPayableVoucher.PayeeName;

                    param = cmd.Parameters.Add("@PayTo", SqlDbType.VarChar, 1000);
                    param.Value = AccountsPayableVoucher.PayTo;

                    param = cmd.Parameters.Add("@PayToAddress", SqlDbType.VarChar, 1000);
                    param.Value = AccountsPayableVoucher.PayToAddress;

                    param = cmd.Parameters.Add("@PayToZipCode", SqlDbType.VarChar, 5);
                    param.Value = AccountsPayableVoucher.PayToZipCode;

                    param = cmd.Parameters.Add("@TIN", SqlDbType.VarChar, 50);
                    param.Value = AccountsPayableVoucher.TIN;

                   
                    param = cmd.Parameters.Add("@Amount", SqlDbType.Decimal);
                    param.Precision = 18;
                    param.Scale = 2;
                    param.Value = AccountsPayableVoucher.Amount;


                    param = cmd.Parameters.Add("@UserID", SqlDbType.Int);
                    param.Value = GlobalVariable.UserID;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);
                }//end of using cmd
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }


        public String Add2307Dummy(CheckVoucherTax CheckVoucherTax, String Flag)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DatabaseConnection.cnn;
                    DatabaseConnection.Connect();
                    SqlParameter param = new SqlParameter();
                    cmd.CommandTimeout = 6000;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.sp_Add2307Dummy";

                    param = cmd.Parameters.Add("@DateTrans", SqlDbType.DateTime);
                    param.Value = CheckVoucherTax.DateTrans;

                    param = cmd.Parameters.Add("@ReferenceNum", SqlDbType.VarChar, 20);
                    param.Value = CheckVoucherTax.ReferenceNum;

                    param = cmd.Parameters.Add("@PayeeNo", SqlDbType.Int);
                    param.Value = CheckVoucherTax.PayeeNo;

                    param = cmd.Parameters.Add("@PayeeType", SqlDbType.VarChar, 50);
                    param.Value = CheckVoucherTax.PayeeType;

                    param = cmd.Parameters.Add("@PayeeName", SqlDbType.VarChar, 200);
                    param.Value = CheckVoucherTax.PayeeName;

                    param = cmd.Parameters.Add("@PayTo", SqlDbType.VarChar, 200);
                    param.Value = CheckVoucherTax.PayTo;

                    param = cmd.Parameters.Add("@PayToAddress", SqlDbType.VarChar, 200);
                    param.Value = CheckVoucherTax.PayToAddress;

                    param = cmd.Parameters.Add("@PayToZipCode", SqlDbType.VarChar, 5);
                    param.Value = CheckVoucherTax.PayToZipCode;

                    param = cmd.Parameters.Add("@TIN", SqlDbType.VarChar, 50);
                    param.Value = CheckVoucherTax.TIN;

                    param = cmd.Parameters.Add("@VatableType", SqlDbType.VarChar, 50);
                    param.Value = CheckVoucherTax.VatableType;

                    param = cmd.Parameters.Add("@NetVAT", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherTax.NetVAT;

                    param = cmd.Parameters.Add("@EVAT", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherTax.EVAT;

                    param = cmd.Parameters.Add("@TotalAmount", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherTax.TotalAmount;

                    param = cmd.Parameters.Add("@AmountPaid", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherTax.AmountPaid;

                    param = cmd.Parameters.Add("@Percentage", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherTax.Percentage;

                    param = cmd.Parameters.Add("@ATCNo", SqlDbType.VarChar, 50);
                    param.Value = CheckVoucherTax.ATCNo;

                    param = cmd.Parameters.Add("@AmountWithHeld", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherTax.AmountWithHeld;

                    param = cmd.Parameters.Add("@LocalTax", SqlDbType.Decimal);
                    param.Scale = 2;
                    param.Precision = 18;
                    param.Value = CheckVoucherTax.LocalTax;

                    param = cmd.Parameters.Add("@Message", SqlDbType.VarChar, 500);
                    param.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();
                    return Convert.ToString(cmd.Parameters["@Message"].Value);

                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DatabaseConnection.DBClose();
            }
        }
        public List<AccountsPayableVoucher> GetAccountsPayableVoucherList( String Flag, String Param, String Month, String Year)
        {

            try
            {
                List<AccountsPayableVoucher> AccountsPayableVoucherList = new List<AccountsPayableVoucher>();
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlParameter param = new SqlParameter();
                    DatabaseConnection.Connect();
                    cmd.Connection = DatabaseConnection.cnn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 60000;
                    cmd.CommandText = "sp_GetAccountsPayableVoucher";
                    param = cmd.Parameters.Add("@Param", SqlDbType.VarChar, 50);
                    param.Value = Param;
                    param = cmd.Parameters.Add("@Flag", SqlDbType.VarChar, 20);
                    param.Value = Flag;
                    param = cmd.Parameters.Add("@Month", SqlDbType.VarChar, 2);
                    if (Month != "") { param.Value =Month.Substring(0, 2) + "%"; }
                    else { param.Value = "%"; }
                    param = cmd.Parameters.Add("@Year", SqlDbType.VarChar, 4);
                    if (Year != "") { param.Value = Year + "%"; }
                    else { param.Value = "%"; }
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                AccountsPayableVoucherList.Add(new AccountsPayableVoucher()
                                {
                                    APVNo= String.IsNullOrEmpty(dr["APVNo"].ToString()) ? "" : dr["APVNo"].ToString()
                                    ,DateTrans=  Convert.ToDateTime((dr["DateTrans"]))
                                    ,PayeeName = String.IsNullOrEmpty(dr["PayeeName"].ToString()) ? "" : dr["PayeeName"].ToString()
                                      ,
                                    Month = String.IsNullOrEmpty(dr["Month"].ToString()) ? "" : dr["Month"].ToString()
                                      ,
                                    Year = String.IsNullOrEmpty(dr["Year"].ToString()) ? "" : dr["Year"].ToString()
                                    ,
                                    Particulars= String.IsNullOrEmpty(dr["Particulars"].ToString()) ? "" : dr["Particulars"].ToString()
                                    ,GL_Debit= Convert.ToDecimal(dr["GL_Debit"].ToString())
                                    ,GL_Credit= Convert.ToDecimal(dr["GL_Credit"].ToString())
                                    ,SL_Debit= Convert.ToDecimal(dr["SL_Debit"].ToString())
                                    ,SL_Credit= Convert.ToDecimal(dr["SL_Credit"].ToString())
                                    ,TaxCount = Convert.ToInt32(dr["TaxCount"].ToString())
                                });
                            }
                        }
                                                       
                    }//end of using dr
                    return AccountsPayableVoucherList;
                }//end of using cmd
            }//end of try
            catch (Exception ex)
            {
               return null;
            }
            finally
            {
                DatabaseConnection.DBClose();
 
            }
        }
    }
}
